from __future__ import annotations
from typing import Any, Dict, List
import time
import statistics
import math

try:
    import requests
except Exception:
    requests = None

BYBIT = "https://api.bybit.com"
_CACHE: Dict[str, Any] = {}
_CACHE_T: Dict[str, float] = {}

def _cached(key: str, ttl: int = 15):
    if key in _CACHE and time.time() - _CACHE_T.get(key, 0) < ttl:
        return _CACHE[key]
    return None

def _set(key: str, value: Any):
    _CACHE[key] = value
    _CACHE_T[key] = time.time()
    return value

def _get(path: str, params: Dict[str, Any] | None = None, ttl: int = 15):
    if requests is None:
        return None
    key = path + str(params or {})
    c = _cached(key, ttl)
    if c is not None:
        return c
    try:
        r = requests.get(BYBIT + path, params=params or {}, timeout=7)
        js = r.json()
        if js.get("retCode") == 0:
            return _set(key, js.get("result"))
    except Exception as e:
        print("[orderflow] request error", path, type(e).__name__, e)
    return None

def _sf(v, default=0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default

def _percentile(values: List[float], p: float) -> float:
    if not values:
        return 0.0
    vals = sorted(values)
    k = (len(vals) - 1) * p
    f = int(k)
    c = min(f + 1, len(vals) - 1)
    if f == c:
        return vals[f]
    return vals[f] * (c - k) + vals[c] * (k - f)

def _safe_div(a, b, default=0.0):
    return a / b if b else default

def cvd_proxy(candles: List[Dict[str, Any]]) -> List[Dict[str, float]]:
    total = 0.0
    out = []
    for c in candles:
        body = float(c.get("close", 0)) - float(c.get("open", 0))
        rng = max(float(c.get("high", 0)) - float(c.get("low", 0)), 1e-12)
        signed = (body / rng) * float(c.get("volume", 0.0))
        total += signed
        out.append({"time": c.get("time"), "value": total})
    return out

def cvd_slope(cvd: List[Dict[str, float]], lookback: int = 20) -> str:
    if len(cvd) < lookback + 1:
        return "NEUTRAL"
    diff = cvd[-1]["value"] - cvd[-lookback]["value"]
    if diff > 0:
        return "LONG"
    if diff < 0:
        return "SHORT"
    return "NEUTRAL"

def classify_orderbook(imbalance: float, threshold: float = 0.08) -> str:
    if imbalance > threshold:
        return "LONG"
    if imbalance < -threshold:
        return "SHORT"
    return "NEUTRAL"

def _time_weight(index: int, total: int) -> float:
    # Recent trades have more influence. index 0 is newest in Bybit list.
    if total <= 1:
        return 1.0
    freshness = 1.0 - (index / max(1, total - 1))
    return 0.55 + 0.45 * freshness

def trade_flow(symbol: str, limit: int = 200) -> Dict[str, Any]:
    """
    Hedge-fund style tape/orderflow approximation:
    - adaptive large trade threshold by distribution
    - time-weighted aggressive delta
    - large-trade delta and bias
    - cluster detection in the latest tape
    - absorption detection: aggressive buying/selling with weak price progress
    - iceberg/proxy detection: repeated large prints near same price
    - spoof-risk proxy from book imbalance vs tape pressure divergence
    """
    res = _get("/v5/market/recent-trade", {"category": "linear", "symbol": symbol, "limit": limit}, ttl=8)
    rows = (res or {}).get("list") or []

    trades = []
    buy_notional = sell_notional = 0.0
    weighted_buy = weighted_sell = 0.0

    for i, t in enumerate(rows):
        size = _sf(t.get("size"))
        price = _sf(t.get("price"))
        notional = size * price
        if notional <= 0:
            continue
        raw_side = str(t.get("side", "")).lower()
        side = "BUY" if raw_side == "buy" else "SELL" if raw_side == "sell" else "UNKNOWN"
        w = _time_weight(i, len(rows))
        if side == "BUY":
            buy_notional += notional
            weighted_buy += notional * w
        elif side == "SELL":
            sell_notional += notional
            weighted_sell += notional * w
        trades.append({
            "side": side,
            "notional": notional,
            "weighted_notional": notional * w,
            "price": price,
            "size": size,
            "weight": w,
            "time": int(_sf(t.get("time") or t.get("execTime") or 0, 0)),
        })

    total = buy_notional + sell_notional
    weighted_total = weighted_buy + weighted_sell

    if not trades or total <= 0:
        return {
            "buy_notional": 0, "sell_notional": 0,
            "buy_pressure": 0, "sell_pressure": 0,
            "pressure": "NEUTRAL", "tape_delta": 0, "weighted_delta": 0,
            "large_trades": 0, "large_threshold": 0,
            "large_buy_count": 0, "large_sell_count": 0,
            "large_buy_notional": 0, "large_sell_notional": 0,
            "large_delta": 0, "large_bias": "NEUTRAL",
            "cluster_count": 0, "cluster_bias": "NEUTRAL",
            "absorption": "NONE", "iceberg_risk": "LOW",
            "spoof_risk": "LOW", "institutional_score": 0,
        }

    notionals = [x["notional"] for x in trades]
    avg = sum(notionals) / len(notionals)
    med = statistics.median(notionals)
    p90 = _percentile(notionals, 0.90)
    p95 = _percentile(notionals, 0.95)

    threshold = max(avg * 4, med * 6, p90)
    extreme_threshold = max(avg * 7, p95)

    large = [x for x in trades if x["notional"] >= threshold]
    extreme = [x for x in trades if x["notional"] >= extreme_threshold]
    large_buy = [x for x in large if x["side"] == "BUY"]
    large_sell = [x for x in large if x["side"] == "SELL"]

    large_buy_notional = sum(x["notional"] for x in large_buy)
    large_sell_notional = sum(x["notional"] for x in large_sell)
    large_delta = large_buy_notional - large_sell_notional

    buy_pressure = round(_safe_div(buy_notional, total) * 100, 2)
    sell_pressure = round(_safe_div(sell_notional, total) * 100, 2)
    pressure = "LONG" if buy_pressure > sell_pressure else "SHORT" if sell_pressure > buy_pressure else "NEUTRAL"

    weighted_delta = weighted_buy - weighted_sell
    tape_delta = buy_notional - sell_notional

    if large_delta > 0:
        large_bias = "LONG"
    elif large_delta < 0:
        large_bias = "SHORT"
    else:
        large_bias = "NEUTRAL"

    recent = trades[:30]
    recent_large = [x for x in recent if x["notional"] >= threshold]
    rb = len([x for x in recent_large if x["side"] == "BUY"])
    rs = len([x for x in recent_large if x["side"] == "SELL"])
    cluster_count = len(recent_large)
    cluster_notional = sum(x["notional"] for x in recent_large)
    cluster_bias = "LONG" if rb >= 3 and rb > rs else "SHORT" if rs >= 3 and rs > rb else "NEUTRAL"

    # Absorption: strong one-sided tape but price has not moved much.
    prices = [x["price"] for x in trades if x["price"]]
    price_move_pct = 0.0
    if len(prices) >= 2 and prices[-1]:
        # Bybit usually newest first: compare newest to oldest
        price_move_pct = (prices[0] - prices[-1]) / prices[-1] * 100

    absorption = "NONE"
    if buy_pressure >= 62 and price_move_pct < 0.05:
        absorption = "BUY_ABSORBED"
    elif sell_pressure >= 62 and price_move_pct > -0.05:
        absorption = "SELL_ABSORBED"

    # Iceberg proxy: multiple large prints near same rounded price.
    price_buckets = {}
    for x in large:
        if not x["price"]:
            continue
        bucket = round(x["price"], 2 if x["price"] > 10 else 5)
        price_buckets[bucket] = price_buckets.get(bucket, 0) + 1
    iceberg_hits = max(price_buckets.values()) if price_buckets else 0
    iceberg_risk = "HIGH" if iceberg_hits >= 4 else "MEDIUM" if iceberg_hits >= 2 else "LOW"

    # Institutional score 0-100
    pressure_edge = abs(buy_pressure - sell_pressure)
    large_ratio = min(35, _safe_div(sum(x["notional"] for x in large), total) * 100)
    extreme_bonus = min(15, len(extreme) * 5)
    cluster_bonus = 15 if cluster_bias != "NEUTRAL" else 0
    absorption_penalty = -12 if absorption != "NONE" else 0
    inst_score = max(0, min(100, round(pressure_edge * 0.65 + large_ratio + extreme_bonus + cluster_bonus + absorption_penalty, 2)))

    return {
        "buy_notional": round(buy_notional, 2),
        "sell_notional": round(sell_notional, 2),
        "buy_pressure": buy_pressure,
        "sell_pressure": sell_pressure,
        "pressure": pressure,
        "tape_delta": round(tape_delta, 2),
        "weighted_delta": round(weighted_delta, 2),

        "large_trades": len(large),
        "extreme_trades": len(extreme),
        "large_threshold": round(threshold, 2),
        "extreme_threshold": round(extreme_threshold, 2),
        "large_buy_count": len(large_buy),
        "large_sell_count": len(large_sell),
        "large_buy_notional": round(large_buy_notional, 2),
        "large_sell_notional": round(large_sell_notional, 2),
        "large_delta": round(large_delta, 2),
        "large_bias": large_bias,

        "cluster_count": cluster_count,
        "cluster_notional": round(cluster_notional, 2),
        "cluster_bias": cluster_bias,

        "absorption": absorption,
        "iceberg_risk": iceberg_risk,
        "institutional_score": inst_score,
    }

def open_interest(symbol: str, interval: str = "5min") -> Dict[str, Any]:
    res = _get("/v5/market/open-interest", {"category": "linear", "symbol": symbol, "intervalTime": interval, "limit": 12}, ttl=20)
    rows = (res or {}).get("list") or []
    vals = [_sf(x.get("openInterest")) for x in reversed(rows)]
    if not vals:
        return {"current": None, "trend": "UNKNOWN", "change_pct": 0}
    cur = vals[-1]
    prev = vals[0] or cur
    chg = ((cur - prev) / prev * 100) if prev else 0
    trend = "RISING" if chg > 0.5 else "FALLING" if chg < -0.5 else "FLAT"
    return {"current": round(cur, 2), "trend": trend, "change_pct": round(chg, 2)}

def funding(symbol: str) -> Dict[str, Any]:
    res = _get("/v5/market/tickers", {"category": "linear", "symbol": symbol}, ttl=20)
    rows = (res or {}).get("list") or []
    if not rows:
        return {"rate": None, "bias": "NEUTRAL"}
    rate = _sf(rows[0].get("fundingRate"))
    bias = "LONGS_CROWDED" if rate > 0.0005 else "SHORTS_CROWDED" if rate < -0.0005 else "NEUTRAL"
    return {"rate": round(rate * 100, 5), "bias": bias}

def orderflow_summary(candles: List[Dict[str, Any]], orderbook: Dict[str, Any], symbol: str | None = None) -> Dict[str, Any]:
    cvd = cvd_proxy(candles)
    cvd_bias = cvd_slope(cvd)
    ob_bias = classify_orderbook(float(orderbook.get("imbalance", 0.0) or 0.0))

    tf = {
        "buy_pressure": 0, "sell_pressure": 0, "pressure": "NEUTRAL",
        "large_trades": 0, "large_bias": "NEUTRAL",
        "cluster_bias": "NEUTRAL", "institutional_score": 0,
        "absorption": "NONE", "iceberg_risk": "LOW",
    }
    oi = {"current": None, "trend": "UNKNOWN", "change_pct": 0}
    fr = {"rate": None, "bias": "NEUTRAL"}

    if symbol:
        tf = trade_flow(symbol)
        oi = open_interest(symbol)
        fr = funding(symbol)

    if not tf.get("buy_pressure") and not tf.get("sell_pressure"):
        if cvd_bias == "LONG":
            tf["buy_pressure"], tf["sell_pressure"], tf["pressure"] = 60, 40, "LONG"
        elif cvd_bias == "SHORT":
            tf["buy_pressure"], tf["sell_pressure"], tf["pressure"] = 40, 60, "SHORT"
        else:
            tf["buy_pressure"], tf["sell_pressure"], tf["pressure"] = 50, 50, "NEUTRAL"

    votes = []
    for v in [cvd_bias, ob_bias, tf.get("pressure"), tf.get("large_bias"), tf.get("cluster_bias")]:
        if v in ("LONG", "SHORT"):
            votes.append(v)

    long_votes = votes.count("LONG")
    short_votes = votes.count("SHORT")
    bias = "LONG" if long_votes > short_votes else "SHORT" if short_votes > long_votes else "NEUTRAL"

    has_real_trades = bool(tf.get("buy_notional") or tf.get("sell_notional"))
    quality = "HEDGE_ORDERFLOW" if has_real_trades else "PROXY_FALLBACK"
    if bias == "NEUTRAL" and votes:
        quality = "DIVERGENCE"

    spoof_risk = "LOW"
    if ob_bias == "LONG" and tf.get("pressure") == "SHORT":
        spoof_risk = "ASK/BID_DIVERGENCE"
    elif ob_bias == "SHORT" and tf.get("pressure") == "LONG":
        spoof_risk = "ASK/BID_DIVERGENCE"

    return {
        "bias": bias,
        "flow": bias,
        "quality": quality,
        "cvd": cvd[-80:],
        "cvd_bias": cvd_bias,
        "cvd_proxy": cvd_bias,
        "orderbook": ob_bias,
        "imbalance": float(orderbook.get("imbalance", 0.0) or 0.0),

        "buy_pressure": tf.get("buy_pressure", 0),
        "sell_pressure": tf.get("sell_pressure", 0),
        "pressure": tf.get("pressure", "NEUTRAL"),
        "buy_notional": tf.get("buy_notional", 0),
        "sell_notional": tf.get("sell_notional", 0),
        "tape_delta": tf.get("tape_delta", 0),
        "weighted_delta": tf.get("weighted_delta", 0),

        "large_trades": tf.get("large_trades", 0),
        "extreme_trades": tf.get("extreme_trades", 0),
        "large_threshold": tf.get("large_threshold", 0),
        "large_buy_count": tf.get("large_buy_count", 0),
        "large_sell_count": tf.get("large_sell_count", 0),
        "large_buy_notional": tf.get("large_buy_notional", 0),
        "large_sell_notional": tf.get("large_sell_notional", 0),
        "large_delta": tf.get("large_delta", 0),
        "large_bias": tf.get("large_bias", "NEUTRAL"),

        "cluster_count": tf.get("cluster_count", 0),
        "cluster_notional": tf.get("cluster_notional", 0),
        "cluster_bias": tf.get("cluster_bias", "NEUTRAL"),

        "absorption": tf.get("absorption", "NONE"),
        "iceberg_risk": tf.get("iceberg_risk", "LOW"),
        "spoof_risk": spoof_risk,
        "institutional_score": tf.get("institutional_score", 0),

        "open_interest": oi,
        "funding": fr,
    }
