from typing import Any, Dict, List, Optional
from .liquidity_engine import find_swings


def structure_from_swings(swings: List[Dict[str, Any]]) -> Dict[str, Any]:
    highs = [s for s in swings if s['kind'] == 'H']
    lows  = [s for s in swings if s['kind'] == 'L']
    if len(highs) < 2 or len(lows) < 2:
        return {'bias': 'NEUTRAL', 'detail': 'not enough swings',
                'last_high': highs[-1] if highs else None,
                'last_low':  lows[-1]  if lows  else None}
    hh = highs[-1]['price'] > highs[-2]['price']
    hl = lows[-1]['price']  > lows[-2]['price']
    lh = highs[-1]['price'] < highs[-2]['price']
    ll = lows[-1]['price']  < lows[-2]['price']
    if hh and hl:
        return {'bias': 'LONG',    'detail': 'HH/HL', 'last_high': highs[-1], 'last_low': lows[-1]}
    if lh and ll:
        return {'bias': 'SHORT',   'detail': 'LH/LL', 'last_high': highs[-1], 'last_low': lows[-1]}
    return     {'bias': 'NEUTRAL', 'detail': 'range/mixed', 'last_high': highs[-1], 'last_low': lows[-1]}


def detect_bos_choch(candles: List[Dict[str, Any]],
                     swings: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """
    BOS/CHoCH detector — O(n) вместо O(n²).

    Улучшения vs v7:
    - Не пересчитывает structure_from_swings на каждой свече.
      Вместо этого строим события от свинга к свингу.
    - Дедупликация по (type, direction, level_bucket).
    """
    swings = swings if swings is not None else find_swings(candles)
    events: List[Dict[str, Any]] = []
    if len(swings) < 4:
        return events

    highs = [s for s in swings if s['kind'] == 'H']
    lows  = [s for s in swings if s['kind'] == 'L']

    # Определяем текущий bias один раз
    structure = structure_from_swings(swings)
    bias = structure['bias']

    # --- BOS/CHoCH по последним свинговым уровням ---
    # O(k*n) with small k=6. No candles.index(), no all-swings scan per candle.
    for sh in highs[-6:]:
        level = float(sh['price'])
        start_idx = int(sh['idx']) + 1
        for j in range(start_idx, len(candles)):
            if float(candles[j]['close']) > level:
                ev_type = 'BOS' if bias == 'LONG' else 'CHoCH'
                events.append({'type': ev_type, 'direction': 'LONG',
                                'time': candles[j]['time'], 'idx': j,
                                'level': level})
                break

    for sl in lows[-6:]:
        level = float(sl['price'])
        start_idx = int(sl['idx']) + 1
        for j in range(start_idx, len(candles)):
            if float(candles[j]['close']) < level:
                ev_type = 'BOS' if bias == 'SHORT' else 'CHoCH'
                events.append({'type': ev_type, 'direction': 'SHORT',
                                'time': candles[j]['time'], 'idx': j,
                                'level': level})
                break

    # Дедупликация — оставляем уникальные по (type, direction, уровень с точностью 4 знака)
    out: List[Dict[str, Any]] = []
    seen = set()
    for e in sorted(events, key=lambda x: x.get('idx', 0)):
        key = (e['type'], e['direction'], round(float(e['level']), 4))
        if key not in seen:
            out.append(e)
            seen.add(key)

    return out[-12:]


def detect_fvg(candles: List[Dict[str, Any]],
               lookback: int = 120,
               min_size_mult: float = 0.15) -> List[Dict[str, Any]]:
    if len(candles) < 3:
        return []
    avg_range = sum(float(c['high']) - float(c['low']) for c in candles[-50:]) / max(1, min(50, len(candles)))
    min_size  = avg_range * min_size_mult
    zones: List[Dict[str, Any]] = []
    start = max(2, len(candles) - lookback)

    for i in range(start, len(candles)):
        c0, c2 = candles[i - 2], candles[i]
        future  = candles[i + 1:]

        # Бычий FVG
        if float(c2['low']) > float(c0['high']):
            lo, hi = float(c0['high']), float(c2['low'])
            if hi - lo >= min_size:
                zones.append({'type': 'BULLISH_FVG', 'low': lo, 'high': hi,
                               'mid': (lo + hi) / 2, 'time': c2['time'], 'idx': i,
                               'mitigated': _is_mitigated(future, lo, hi)})

        # Медвежий FVG
        elif float(c2['high']) < float(c0['low']):
            lo, hi = float(c2['high']), float(c0['low'])
            if hi - lo >= min_size:
                zones.append({'type': 'BEARISH_FVG', 'low': lo, 'high': hi,
                               'mid': (lo + hi) / 2, 'time': c2['time'], 'idx': i,
                               'mitigated': _is_mitigated(future, lo, hi)})

    return zones[-20:]


def _is_mitigated(future: List[Dict[str, Any]], low: float, high: float) -> bool:
    mid = (low + high) / 2
    return any(float(c['low']) <= mid <= float(c['high']) for c in future)


def premium_discount(candles: List[Dict[str, Any]],
                     swings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    swings = swings if swings is not None else find_swings(candles)
    highs  = [s for s in swings if s['kind'] == 'H']
    lows   = [s for s in swings if s['kind'] == 'L']
    if not highs or not lows or not candles:
        return {'zone': 'UNKNOWN', 'equilibrium': None, 'range_high': None, 'range_low': None}
    hi, lo = highs[-1]['price'], lows[-1]['price']
    if hi < lo:
        hi, lo = lo, hi
    eq    = (hi + lo) / 2
    close = float(candles[-1]['close'])
    zone  = 'PREMIUM' if close > eq * 1.001 else 'DISCOUNT' if close < eq * 0.999 else 'EQUILIBRIUM'
    return {'zone': zone, 'equilibrium': round(eq, 8),
            'range_high': round(hi, 8), 'range_low': round(lo, 8),
            'pct_from_eq': round((close - eq) / eq * 100, 2)}
