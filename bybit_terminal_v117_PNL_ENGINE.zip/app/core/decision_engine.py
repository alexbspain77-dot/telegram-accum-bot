"""decision_engine.py v8.1 — улучшенная версия

Исправления:
  1. atr() теперь считает True Range (с учётом gaps)
  2. impulse_exhaustion — порог силы поднят с 45 до 55,
     добавлен min_atr_move чтобы не блокировать мелкие откаты
  3. order_block_context — max_dist_pct увеличен до 1.2% (было 0.8%)
  4. decision_filters возвращает structured decision dict для UI
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional


def _f(x: Any, default: float = 0.0) -> float:
    try: return float(x)
    except Exception: return default


def atr(candles: List[Dict[str, Any]], period: int = 14) -> float:
    """True Range ATR — учитывает gaps между свечами."""
    if len(candles) < 2:
        return 0.0
    rows = candles[-period - 1:]
    trs = []
    for i in range(1, len(rows)):
        prev_close = _f(rows[i-1].get('close'))
        hi = _f(rows[i].get('high'))
        lo = _f(rows[i].get('low'))
        tr = max(hi - lo, abs(hi - prev_close), abs(lo - prev_close))
        trs.append(tr)
    if not trs:
        return 0.0
    # Wilder smoothing
    val = sum(trs[:period]) / max(1, min(period, len(trs)))
    for tr in trs[period:]:
        val = (val * (period - 1) + tr) / period
    return round(val, 8)


def recent_momentum(candles: List[Dict[str, Any]], lookback: int = 8) -> Dict[str, Any]:
    """Оценивает momentum последних N свечей по body/range ratio."""
    if len(candles) < lookback + 2:
        return {'bias': 'NEUTRAL', 'strength': 0, 'body_ratio': 0,
                'red_ratio': 0, 'green_ratio': 0, 'net_move': 0}
    rows = candles[-lookback:]
    body_sum  = sum(_f(c['close']) - _f(c['open']) for c in rows)
    range_sum = sum(max(_f(c['high']) - _f(c['low']), 1e-12) for c in rows)
    red   = sum(1 for c in rows if _f(c['close']) < _f(c['open']))
    green = sum(1 for c in rows if _f(c['close']) > _f(c['open']))
    body_ratio = abs(body_sum) / max(range_sum, 1e-12)
    bias = 'LONG' if body_sum > 0 else 'SHORT' if body_sum < 0 else 'NEUTRAL'
    strength = min(100, round(body_ratio * 140 + max(red, green) / lookback * 30, 1))
    return {
        'bias': bias, 'strength': strength,
        'body_ratio': round(body_ratio, 4),
        'red_ratio':  round(red   / lookback, 3),
        'green_ratio':round(green / lookback, 3),
        'net_move':   body_sum,
    }


def impulse_exhaustion(candles: List[Dict[str, Any]], direction: str,
                        lookback: int = 34) -> Dict[str, Any]:
    """
    Фильтр позднего входа.

    Исправления vs оригинала:
    - порог силы momentum: 55 (было 45) — меньше ложных блокировок
    - добавлен min_move: импульс должен быть > 1.5 ATR чтобы вообще считаться
    - добавлен grace zone: если цена уже глубоко в ретрейсе (>65%), блок снимается
      (уже не поздно — это новая точка входа)
    """
    if len(candles) < lookback:
        return {'exhausted': False, 'reason': 'not enough candles'}

    rows = candles[-lookback:]
    hi   = max(_f(c['high'])  for c in rows)
    lo   = min(_f(c['low'])   for c in rows)
    close = _f(candles[-1]['close'])
    rng   = max(hi - lo, 1e-12)
    mom   = recent_momentum(candles, 8)

    # Минимальный размер импульса — 1.5 ATR
    atr_val = atr(candles, 14)
    min_move = atr_val * 1.5 if atr_val else rng * 0.3
    if rng < min_move:
        return {'exhausted': False, 'reason': 'range too small for exhaustion filter', 'momentum': mom}

    retrace_from_high = (hi - close) / rng
    bounce_from_low   = (close - lo)  / rng

    RETRACE_THRESHOLD = 0.45
    DEEP_RETRACEMENT  = 0.65   # если >65% — это уже новый сетап, не поздний вход
    MOMENTUM_THRESHOLD = 55     # было 45

    if direction == 'LONG':
        if (RETRACE_THRESHOLD <= retrace_from_high < DEEP_RETRACEMENT
                and mom['bias'] == 'SHORT'
                and mom['strength'] >= MOMENTUM_THRESHOLD):
            return {'exhausted': True,
                    'reason': f'late LONG: retrace {retrace_from_high:.0%} from high + SHORT momentum {mom["strength"]}',
                    'momentum': mom}

    if direction == 'SHORT':
        if (RETRACE_THRESHOLD <= bounce_from_low < DEEP_RETRACEMENT
                and mom['bias'] == 'LONG'
                and mom['strength'] >= MOMENTUM_THRESHOLD):
            return {'exhausted': True,
                    'reason': f'late SHORT: bounce {bounce_from_low:.0%} from low + LONG momentum {mom["strength"]}',
                    'momentum': mom}

    return {'exhausted': False, 'reason': 'no exhaustion detected', 'momentum': mom}


def order_block_context(smc: Dict[str, Any], price: float, direction: str,
                         max_dist_pct: float = 1.2) -> Dict[str, Any]:
    """
    Проверяет положение цены относительно Order Blocks.
    max_dist_pct увеличен до 1.2% (было 0.8%) — менее строгий фильтр.
    """
    active_obs  = smc.get('active_obs')  or []
    mitigation  = smc.get('mitigation_zones') or []
    zones = list(active_obs) + list(mitigation)
    if not zones or not price:
        return {'state': 'NONE', 'score': 0, 'reason': 'no active OB'}

    want = 'BULLISH' if direction == 'LONG' else 'BEARISH'
    best = None
    best_dist = 1e9

    for z in zones:
        low  = _f(z.get('low'))
        high = _f(z.get('high'))
        mid  = _f(z.get('mid'), (low + high) / 2)
        dist = 0.0 if low <= price <= high else abs(mid - price) / price * 100
        if dist < best_dist:
            best = z
            best_dist = dist

    if not best:
        return {'state': 'NONE', 'score': 0, 'reason': 'no OB found'}

    ztype = str(best.get('type', ''))
    if want in ztype and best_dist <= max_dist_pct:
        return {'state': 'ALIGNED',  'score': 12,
                'reason': f'near aligned {ztype} ({best_dist:.2f}%)', 'zone': best}
    if ('BULLISH' in ztype or 'BEARISH' in ztype) and want not in ztype and best_dist <= max_dist_pct:
        return {'state': 'CONFLICT', 'score': -18,
                'reason': f'near opposite {ztype} ({best_dist:.2f}%)', 'zone': best}
    return {'state': 'FAR', 'score': 0,
            'reason': f'nearest OB too far ({best_dist:.2f}%)', 'zone': best}


def decision_filters(candles: List[Dict[str, Any]], smc: Dict[str, Any],
                     direction: str, elliott: Optional[Dict[str, Any]],
                     price: float) -> Dict[str, Any]:
    """
    Собирает все hard filters и score adjustments.
    Возвращает структурированный dict для отображения в UI.
    """
    blockers:  List[str] = []
    reasons:   List[str] = []
    score_adj: int = 0

    # 1. Momentum conflict
    mom = recent_momentum(candles, 8)
    if mom['bias'] not in ('NEUTRAL', direction) and mom['strength'] >= 55:
        score_adj -= 22
        reasons.append(f"Momentum conflict: {mom['bias']} str={mom['strength']}")

    # 2. Impulse exhaustion (hard block)
    exh = impulse_exhaustion(candles, direction)
    if exh.get('exhausted'):
        blockers.append(exh['reason'])
        score_adj -= 35

    # 3. Order Block context
    ob = order_block_context(smc, price, direction)
    score_adj += ob.get('score', 0)
    if ob.get('state') in ('ALIGNED', 'CONFLICT'):
        reasons.append(ob.get('reason', ''))

    # 4. Elliott wave alignment / conflict
    etype = (elliott or {}).get('type', 'NONE')
    if etype and etype != 'NONE':
        if direction == 'LONG'  and 'SHORT' in etype:
            score_adj -= 25
            reasons.append(f'Elliott conflict: {etype}')
        elif direction == 'SHORT' and 'LONG' in etype:
            score_adj -= 25
            reasons.append(f'Elliott conflict: {etype}')
        elif direction in etype:
            score_adj += 8
            reasons.append(f'Elliott aligns: {etype} (+8)')

    return {
        'score_adjustment': score_adj,
        'blockers':   blockers,
        'reasons':    reasons,
        'momentum':   mom,
        'exhaustion': exh,
        'order_block':ob,
        # Для UI — читаемый статус
        'status': 'BLOCKED' if blockers else ('WEAK' if score_adj < -20 else 'OK'),
        'atr': atr(candles, 14),
    }
