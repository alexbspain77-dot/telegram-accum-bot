
"""scenario_engine.py v8.1 — final decision layer.

NO_TRADE is default. A trade needs structure + trigger + context.
New in v8.1:
- momentum/exhaustion filter;
- order block context;
- Elliott conflicts can block/penalise;
- sweep/CHoCH/BOS are treated as triggers, not decoration.
"""
from __future__ import annotations
import datetime
from typing import Any, Dict, List, Optional
from .decision_engine import decision_filters

SESSIONS = {
    'ASIA':   (0,  8),
    'LONDON': (7,  16),
    'NY':     (13, 22),
}
SESSION_PENALTY = {'ASIA': -8, 'LONDON': 0, 'NY': 0, 'OVERLAP': 5}


def _current_session() -> str:
    h = datetime.datetime.utcnow().hour
    in_london = SESSIONS['LONDON'][0] <= h < SESSIONS['LONDON'][1]
    in_ny     = SESSIONS['NY'][0]     <= h < SESSIONS['NY'][1]
    if in_london and in_ny: return 'OVERLAP'
    if in_london: return 'LONDON'
    if in_ny: return 'NY'
    return 'ASIA'


def _nearest_fvg(fvg_list: List[Dict], price: float, direction: str) -> Optional[Dict]:
    want = 'BULLISH_FVG' if direction == 'LONG' else 'BEARISH_FVG'
    candidates = [f for f in fvg_list if not f.get('mitigated', True) and f.get('type') == want]
    if not candidates or not price: return None
    return min(candidates, key=lambda f: abs(float(f.get('mid', 0)) - price))


def _latest_fresh(items: List[Dict[str, Any]], max_age: int, last_idx: int) -> Optional[Dict[str, Any]]:
    if not items: return None
    for x in reversed(items):
        idx = x.get('idx')
        if idx is None or last_idx - int(idx) <= max_age:
            return x
    return items[-1]


def build_scenario(
    liquidity: Dict[str, Any], smc: Dict[str, Any], orderflow: Dict[str, Any],
    mtf: Dict[str, Any], pd: Dict[str, Any], *, elliott: Optional[Dict[str, Any]] = None,
    rsi_last: Optional[float] = None, price: Optional[float] = None,
    candles: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    candles = candles or []
    price = float(price or (candles[-1]['close'] if candles else 0) or 0)
    last_idx = len(candles) - 1
    sweeps = liquidity.get('sweeps', []) or []
    events = smc.get('events', []) or []
    fvg_list = smc.get('fvg', []) or []
    structure = smc.get('structure', {}) or {}
    structure_bias = structure.get('bias', 'NEUTRAL')
    mtf_bias = mtf.get('bias', 'NEUTRAL')
    flow_bias = orderflow.get('bias', 'NEUTRAL')
    flow_quality = orderflow.get('quality', 'NO_EDGE')
    absorption = orderflow.get('absorption', 'NONE')
    spoof_risk = orderflow.get('spoof_risk', 'LOW')
    iceberg_risk = orderflow.get('iceberg_risk', 'LOW')
    large_bias = orderflow.get('large_bias', 'NEUTRAL')
    cluster_bias = orderflow.get('cluster_bias', 'NEUTRAL')
    institutional_score = float(orderflow.get('institutional_score') or 0)
    tape_delta = float(orderflow.get('tape_delta') or 0)
    weighted_delta = float(orderflow.get('weighted_delta') or 0)
    pd_zone = pd.get('zone', 'UNKNOWN')
    session = _current_session()

    reasons: List[str] = []
    trap = 'NONE'
    setup = 'NO_VALID_SETUP'

    latest_sweep = _latest_fresh(sweeps, 40, last_idx)
    latest_event = _latest_fresh(events, 40, last_idx)
    latest_event_dir = latest_event.get('direction', 'NEUTRAL') if latest_event else 'NEUTRAL'
    latest_event_type = latest_event.get('type', 'NONE') if latest_event else 'NONE'

    reasons.append(f"Sweep: {latest_sweep.get('type')}" if latest_sweep else 'No fresh sweep')
    reasons.append(f"Structure event: {latest_event_type} {latest_event_dir}" if latest_event else 'No fresh BOS/CHoCH')
    reasons.append(f"Bias: structure {structure_bias} | MTF {mtf_bias} | Flow {flow_bias} ({flow_quality})")
    reasons.append(f"OF: absorption {absorption} | spoof {spoof_risk} | iceberg {iceberg_risk} | inst {institutional_score}")
    reasons.append(f"PD zone: {pd_zone} | Session: {session}")

    # Trap setup: sweep one side then CHoCH opposite.
    if latest_sweep and latest_event_type == 'CHoCH':
        st = latest_sweep.get('type')
        if st == 'buy_side_sweep' and latest_event_dir == 'SHORT':
            trap, setup = 'BULL_TRAP', 'BUY_SIDE_SWEEP_TO_SHORT'
        elif st == 'sell_side_sweep' and latest_event_dir == 'LONG':
            trap, setup = 'BEAR_TRAP', 'SELL_SIDE_SWEEP_TO_LONG'

    # Direction priority: trap > fresh structure event > structure+MTF alignment.
    direction = 'NEUTRAL'
    if trap == 'BULL_TRAP': direction = 'SHORT'
    elif trap == 'BEAR_TRAP': direction = 'LONG'
    elif latest_event_type in ('BOS', 'CHoCH'):
        direction = latest_event_dir
    elif structure_bias == mtf_bias and structure_bias in ('LONG', 'SHORT'):
        direction = structure_bias

    if direction == 'NEUTRAL':
        return {'type': 'NO_TRADE', 'direction': 'NEUTRAL', 'setup': setup, 'confidence': 0,
                'trap': trap, 'session': session, 'reasons': reasons + ['No clear direction'],
                'decision': {'blockers': ['no direction']}}

    # Require an actionable trigger. Trend alignment alone is not enough.
    has_trigger = bool(latest_sweep or latest_event_type in ('BOS', 'CHoCH'))
    if not has_trigger:
        return {'type': 'NO_TRADE', 'direction': direction, 'setup': setup, 'confidence': 0,
                'trap': trap, 'session': session, 'reasons': reasons + ['No actionable trigger: no sweep/BOS/CHoCH'],
                'decision': {'blockers': ['no actionable trigger']}}

    confidence = 30
    if latest_sweep: confidence += 14
    if latest_event_type == 'CHoCH': confidence += 20
    elif latest_event_type == 'BOS': confidence += 10

    if mtf_bias == direction: confidence += 14
    elif mtf_bias not in ('NEUTRAL', direction):
        confidence -= 24; reasons.append('MTF conflict')

    if flow_bias == direction: confidence += 12
    elif flow_bias not in ('NEUTRAL', direction):
        confidence -= 28; reasons.append('Flow conflict')

    # Hedge orderflow decision integration.
    if flow_quality == 'DIVERGENCE':
        confidence -= 20
        reasons.append('Orderflow divergence: tape/book signals disagree')

    if spoof_risk != 'LOW':
        confidence -= 10
        reasons.append(f'Spoof risk detected: {spoof_risk}')

    if direction == 'LONG' and absorption == 'BUY_ABSORBED':
        confidence -= 15
        reasons.append('Buy absorption: aggressive buys are not moving price')
    elif direction == 'SHORT' and absorption == 'SELL_ABSORBED':
        confidence -= 15
        reasons.append('Sell absorption: aggressive sells are not moving price')
    elif direction == 'LONG' and absorption == 'SELL_ABSORBED':
        confidence += 7
        reasons.append('Sell absorption supports LONG reversal')
    elif direction == 'SHORT' and absorption == 'BUY_ABSORBED':
        confidence += 7
        reasons.append('Buy absorption supports SHORT reversal')

    if large_bias == direction:
        confidence += 7
        reasons.append('Large trade bias aligned')
    elif large_bias in ('LONG', 'SHORT') and large_bias != direction:
        confidence -= 9
        reasons.append('Large trade bias conflicts')

    if cluster_bias == direction:
        confidence += 8
        reasons.append('Large-trade cluster aligned')
    elif cluster_bias in ('LONG', 'SHORT') and cluster_bias != direction:
        confidence -= 10
        reasons.append('Large-trade cluster conflicts')

    if institutional_score >= 70:
        confidence += 8
        reasons.append(f'High institutional score: {institutional_score}')
    elif institutional_score <= 20 and flow_quality != 'PROXY_FALLBACK':
        confidence -= 5
        reasons.append(f'Weak institutional participation: {institutional_score}')

    if direction == 'LONG' and weighted_delta > 0:
        confidence += 4
    elif direction == 'SHORT' and weighted_delta < 0:
        confidence += 4
    elif weighted_delta and ((direction == 'LONG' and weighted_delta < 0) or (direction == 'SHORT' and weighted_delta > 0)):
        confidence -= 6
        reasons.append('Time-weighted tape delta conflicts')

    if pd_zone == 'DISCOUNT' and direction == 'LONG':
        confidence += 7; reasons.append('Discount zone supports LONG')
    elif pd_zone == 'PREMIUM' and direction == 'SHORT':
        confidence += 7; reasons.append('Premium zone supports SHORT')
    elif pd_zone == 'PREMIUM' and direction == 'LONG':
        confidence -= 12; reasons.append('Buying in premium zone')
    elif pd_zone == 'DISCOUNT' and direction == 'SHORT':
        confidence -= 12; reasons.append('Selling in discount zone')

    if rsi_last is not None:
        if direction == 'LONG' and rsi_last > 72:
            confidence -= 18; reasons.append(f'RSI {rsi_last:.1f}: LONG late/overbought')
        elif direction == 'SHORT' and rsi_last < 28:
            confidence -= 18; reasons.append(f'RSI {rsi_last:.1f}: SHORT late/oversold')

    nearest = _nearest_fvg(fvg_list, price, direction)
    if nearest:
        dist_pct = abs(float(nearest['mid']) - price) / max(price, 1e-12) * 100
        if dist_pct < 0.5:
            confidence += 8; reasons.append(f"Directional FVG very close: {dist_pct:.2f}%")
        elif dist_pct < 1.5:
            confidence += 4; reasons.append(f"Directional FVG nearby: {dist_pct:.2f}%")

    # v8.1 decision filters: momentum/exhaustion/OB/Elliott.
    decision = decision_filters(candles, smc, direction, elliott, price)
    confidence += int(decision.get('score_adjustment', 0))
    reasons.extend(decision.get('reasons', []))
    blockers = decision.get('blockers', [])

    # Session context.
    sess_adj = SESSION_PENALTY.get(session, 0)
    if sess_adj:
        confidence += sess_adj; reasons.append(f"Session {session} adjustment: {sess_adj:+d}")

    if setup == 'NO_VALID_SETUP':
        if latest_event_type == 'BOS': setup = 'STRUCTURE_CONTINUATION'
        elif latest_event_type == 'CHoCH': setup = 'STRUCTURE_SHIFT'
        else: setup = 'LIQUIDITY_STRUCTURE_TRIGGER'

    confidence = max(0, min(97, int(confidence)))

    # Hard blockers override optimistic scoring.
    if blockers:
        stype = 'NO_TRADE'
        confidence = min(confidence, 40)
        reasons.extend([f'BLOCK: {b}' for b in blockers])
    elif confidence < 50:
        stype = 'NO_TRADE'; reasons.append('Confidence below trade threshold (50)')
    elif confidence < 68:
        stype = f'WEAK_{direction}'
    else:
        stype = direction

    return {
        'type': stype, 'direction': direction, 'setup': setup, 'confidence': confidence,
        'trap': trap, 'session': session, 'reasons': reasons,
        'decision': decision,
        'orderflow': {
            'quality': flow_quality,
            'absorption': absorption,
            'spoof_risk': spoof_risk,
            'iceberg_risk': iceberg_risk,
            'large_bias': large_bias,
            'cluster_bias': cluster_bias,
            'institutional_score': institutional_score,
            'tape_delta': tape_delta,
            'weighted_delta': weighted_delta,
        },
    }
