from typing import Any, Dict, List


def evaluate_forward(candles: List[Dict[str, Any]], idx: int, direction: str, entry: float, stop: float, tp: float, max_bars: int = 48) -> Dict[str, Any]:
    end = min(len(candles), idx + max_bars + 1)
    for j in range(idx + 1, end):
        c = candles[j]
        if direction == 'LONG':
            if float(c['low']) <= stop:
                return {'result': 'LOSS', 'bars': j - idx, 'exit': stop}
            if float(c['high']) >= tp:
                return {'result': 'WIN', 'bars': j - idx, 'exit': tp}
        elif direction == 'SHORT':
            if float(c['high']) >= stop:
                return {'result': 'LOSS', 'bars': j - idx, 'exit': stop}
            if float(c['low']) <= tp:
                return {'result': 'WIN', 'bars': j - idx, 'exit': tp}
    return {'result': 'OPEN', 'bars': end - idx - 1, 'exit': candles[end-1]['close'] if end > idx else entry}


def summarize(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    closed = [t for t in trades if t.get('result') in ('WIN', 'LOSS')]
    wins = sum(1 for t in closed if t.get('result') == 'WIN')
    return {'total': len(trades), 'closed': len(closed), 'wins': wins, 'winrate': round(wins / len(closed) * 100, 2) if closed else 0.0}
