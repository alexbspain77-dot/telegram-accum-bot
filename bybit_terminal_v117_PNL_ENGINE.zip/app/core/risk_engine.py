"""risk_engine.py v9.3 — Risk Engine v2: direction-safe SL/TP, validation, sizing, EV"""
from __future__ import annotations
from typing import Any, Dict, List, Optional


def _sf(v, d=None):
    try:
        return float(v)
    except Exception:
        return d


def _round_price(x):
    if x is None:
        return None
    try:
        return round(float(x), 8)
    except Exception:
        return None


def _atr(candles, period=14):
    if not candles or len(candles) < period + 1:
        return None
    trs = []
    for i, c in enumerate(candles):
        h, l = float(c["high"]), float(c["low"])
        if i == 0:
            trs.append(h - l)
            continue
        p = float(candles[i-1]["close"])
        trs.append(max(h - l, abs(h - p), abs(l - p)))
    val = sum(trs[1:period+1]) / period
    for tr in trs[period+1:]:
        val = (val * (period - 1) + tr) / period
    return round(val, 8)


def structural_stop(entry, direction, swings, candles):
    if not entry or direction not in ("LONG", "SHORT"):
        return None
    atr_val = _atr(candles) or (entry * 0.005)
    buffer = max(atr_val * 0.30, entry * 0.001)
    if direction == "LONG":
        lows = [s for s in (swings or []) if s.get("kind") == "L" and float(s.get("price", 0)) < entry]
        base = float(lows[-1]["price"]) if lows else min(float(c["low"]) for c in candles[-20:])
        return round(base - buffer, 8)
    highs = [s for s in (swings or []) if s.get("kind") == "H" and float(s.get("price", 0)) > entry]
    base = float(highs[-1]["price"]) if highs else max(float(c["high"]) for c in candles[-20:])
    return round(base + buffer, 8)


def volatility_stop(entry, direction, candles, atr_mult=2.0):
    atr_val = _atr(candles)
    if not atr_val or not entry or direction not in ("LONG", "SHORT"):
        return None
    dist = atr_val * atr_mult
    return round(entry - dist if direction == "LONG" else entry + dist, 8)


def normalize_trade_levels(direction, entry, stop, tp1=None, tp2=None, atr_val=None):
    """
    Direction-safe normalization.
    LONG:  stop < entry < tp1 < tp2
    SHORT: stop > entry > tp1 > tp2
    """
    entry = _sf(entry)
    stop = _sf(stop)
    tp1 = _sf(tp1)
    tp2 = _sf(tp2)
    atr_val = _sf(atr_val, None)

    errors = []
    warnings = []

    if not entry or direction not in ("LONG", "SHORT"):
        return {
            "entry": entry, "stop": stop, "tp1": tp1, "tp2": tp2,
            "valid": False,
            "errors": ["invalid direction or entry"],
            "warnings": warnings,
        }

    # If no stop, build a safe volatility fallback.
    if not stop or stop == entry:
        dist = atr_val or entry * 0.01
        stop = entry - dist if direction == "LONG" else entry + dist
        warnings.append("stop fallback from ATR")

    # Force stop to correct side.
    if direction == "LONG" and stop >= entry:
        stop = entry - abs(stop - entry)
        if stop == entry:
            stop = entry - (atr_val or entry * 0.01)
        warnings.append("stop normalized below entry for LONG")
    elif direction == "SHORT" and stop <= entry:
        stop = entry + abs(entry - stop)
        if stop == entry:
            stop = entry + (atr_val or entry * 0.01)
        warnings.append("stop normalized above entry for SHORT")

    risk = abs(entry - stop)
    if risk <= 0:
        errors.append("zero risk distance")
        risk = atr_val or entry * 0.01

    # Force TPs to correct side. Preserve original distance if supplied, otherwise use R multiples.
    if direction == "LONG":
        if not tp1 or tp1 <= entry:
            tp1 = entry + (abs(entry - tp1) if tp1 else risk * 1.5)
            warnings.append("tp1 normalized above entry for LONG")
        if not tp2 or tp2 <= entry or tp2 <= tp1:
            base = abs(entry - tp2) if tp2 and tp2 <= entry else risk * 2.5
            tp2 = max(entry + base, tp1 + risk)
            warnings.append("tp2 normalized above tp1 for LONG")
    else:
        if not tp1 or tp1 >= entry:
            tp1 = entry - (abs(tp1 - entry) if tp1 else risk * 1.5)
            warnings.append("tp1 normalized below entry for SHORT")
        if not tp2 or tp2 >= entry or tp2 >= tp1:
            base = abs(tp2 - entry) if tp2 and tp2 >= entry else risk * 2.5
            tp2 = min(entry - base, tp1 - risk)
            warnings.append("tp2 normalized below tp1 for SHORT")

    # Final validation.
    valid = True
    if direction == "LONG":
        if not (stop < entry < tp1 < tp2):
            valid = False
            errors.append("invalid LONG structure: expected stop < entry < tp1 < tp2")
    else:
        if not (stop > entry > tp1 > tp2):
            valid = False
            errors.append("invalid SHORT structure: expected stop > entry > tp1 > tp2")

    return {
        "entry": _round_price(entry),
        "stop": _round_price(stop),
        "tp1": _round_price(tp1),
        "tp2": _round_price(tp2),
        "valid": valid,
        "errors": errors,
        "warnings": warnings,
    }


def position_size(entry, stop, account_usd=10000, risk_pct=1.0):
    if not entry or not stop or entry == stop:
        return {}
    risk_usd = account_usd * risk_pct / 100
    risk_per_unit = abs(entry - stop)
    units = risk_usd / risk_per_unit
    position_usd = units * entry
    return {
        "risk_usd": round(risk_usd, 2),
        "risk_pct": risk_pct,
        "units": round(units, 6),
        "position_usd": round(position_usd, 2),
        "leverage": round(position_usd / account_usd, 2),
        "account_usd": account_usd,
    }


def expected_value(rr1, win_rate_pct=50.0):
    if not rr1:
        return None
    wr = win_rate_pct / 100
    return round(wr * rr1 - (1 - wr) * 1.0, 3)


def trade_quality_score(scenario, rr1, smc, mtf, orderflow, is_valid=True):
    score = 0
    breakdown = {}
    conf = int(scenario.get("confidence") or 0)
    pts = min(40, int(conf * 0.4))
    score += pts
    breakdown["confidence"] = pts

    if rr1 and rr1 >= 3.0:
        pts = 20
    elif rr1 and rr1 >= 2.0:
        pts = 14
    elif rr1 and rr1 >= 1.5:
        pts = 8
    else:
        pts = 0
    score += pts
    breakdown["risk_reward"] = pts

    direction = scenario.get("direction")
    if mtf.get("bias") == direction:
        score += 15
        breakdown["mtf"] = 15
    elif mtf.get("bias") == "NEUTRAL":
        score += 5
        breakdown["mtf"] = 5
    else:
        breakdown["mtf"] = 0

    if orderflow.get("bias") == direction and orderflow.get("quality") == "CONFIRMED":
        score += 10
        breakdown["flow"] = 10
    elif orderflow.get("bias") == direction:
        score += 5
        breakdown["flow"] = 5
    else:
        breakdown["flow"] = 0

    if scenario.get("trap", "NONE") in ("BULL_TRAP", "BEAR_TRAP"):
        score += 10
        breakdown["trap"] = 10
    else:
        breakdown["trap"] = 0

    if scenario.get("session", "") in ("LONDON", "NY", "OVERLAP"):
        score += 5
        breakdown["session"] = 5
    else:
        breakdown["session"] = 0

    if not is_valid:
        score = min(score, 25)
        breakdown["validity_penalty"] = -75

    score = max(0, min(100, score))
    grade = "A" if score >= 80 else "B" if score >= 65 else "C" if score >= 50 else "D"
    if not is_valid:
        grade = "INVALID"
    return {"score": score, "grade": grade, "breakdown": breakdown}


def build_scenarios(entry, stop, tp1, tp2, direction, atr_val):
    if not entry or not stop:
        return {}
    risk = abs(entry - stop)
    r3 = entry + risk * 3 if direction == "LONG" else entry - risk * 3
    return {
        "base": {"target": round(tp1 or (entry + risk * 1.5 if direction == "LONG" else entry - risk * 1.5), 8), "label": "TP1 — базовый"},
        "best": {"target": round(tp2 or r3, 8), "label": "TP2 — лучший"},
        "worst": {"target": round(stop, 8), "label": "Stop — худший"},
        "breakeven": round(entry + (atr_val or risk * 0.3) if direction == "LONG" else entry - (atr_val or risk * 0.3), 8),
    }


def _nearest_directional_targets(entry, direction, targets):
    """Use liquidity targets only if they are on the correct side."""
    targets = targets or {}
    tp1 = _sf(targets.get("tp1"))
    tp2 = _sf(targets.get("tp2"))
    if direction == "LONG":
        if tp1 is not None and tp1 <= entry:
            tp1 = None
        if tp2 is not None and tp2 <= entry:
            tp2 = None
    elif direction == "SHORT":
        if tp1 is not None and tp1 >= entry:
            tp1 = None
        if tp2 is not None and tp2 >= entry:
            tp2 = None
    return tp1, tp2


def build_risk_plan(entry, direction, swings, candles, targets,
                    scenario=None, smc=None, mtf=None, orderflow=None,
                    account_usd=10000, risk_pct=1.0):
    scenario = scenario or {}
    smc = smc or {}
    mtf = mtf or {}
    orderflow = orderflow or {}

    entry = _sf(entry)
    direction = direction if direction in ("LONG", "SHORT") else scenario.get("direction", "NEUTRAL")
    atr_val = _atr(candles)

    if not entry or direction not in ("LONG", "SHORT"):
        return {
            "entry": entry,
            "stop": None,
            "invalidation": None,
            "tp1": None,
            "tp2": None,
            "rr1": None,
            "rr2": None,
            "risk_pct": None,
            "atr": atr_val,
            "sizing": {},
            "ev": None,
            "quality": {"score": 0, "grade": "INVALID", "breakdown": {"reason": "no direction"}},
            "scenarios": {},
            "max_daily_loss_usd": round(account_usd * 0.03, 2),
            "valid": False,
            "errors": ["no directional risk plan"],
            "warnings": [],
        }

    s1 = structural_stop(entry, direction, swings, candles)
    s2 = volatility_stop(entry, direction, candles, 2.0)

    if s1 and s2:
        stop = min(s1, s2) if direction == "LONG" else max(s1, s2)
    else:
        stop = s1 or s2

    tp1, tp2 = _nearest_directional_targets(entry, direction, targets)

    levels = normalize_trade_levels(direction, entry, stop, tp1, tp2, atr_val)
    entry = levels["entry"]
    stop = levels["stop"]
    tp1 = levels["tp1"]
    tp2 = levels["tp2"]

    def _rr(tp):
        if not stop or not tp or not entry:
            return None
        r = abs(entry - stop)
        return round(abs(tp - entry) / r, 2) if r else None

    rr1 = _rr(tp1)
    rr2 = _rr(tp2)

    buf = (atr_val or (entry * 0.003)) * 0.5 if entry else 0
    invalidation = round(stop - buf if direction == "LONG" else stop + buf, 8) if stop else stop

    valid = levels["valid"]
    errors = list(levels.get("errors") or [])
    warnings = list(levels.get("warnings") or [])

    if rr1 is not None and rr1 < 1.0:
        warnings.append("RR1 below 1.0")
    if rr1 is not None and rr1 < 1.2:
        warnings.append("RR1 below 1.2")

    return {
        "entry": entry,
        "stop": stop,
        "invalidation": invalidation,
        "tp1": tp1,
        "tp2": tp2,
        "rr1": rr1,
        "rr2": rr2,
        "risk_pct": round(abs(entry - stop) / entry * 100, 3) if stop and entry else None,
        "atr": atr_val,
        "sizing": position_size(entry, stop, account_usd, risk_pct) if stop and valid else {},
        "ev": expected_value(rr1, 50.0),
        "quality": trade_quality_score(scenario, rr1, smc, mtf, orderflow, valid),
        "scenarios": build_scenarios(entry, stop, tp1, tp2, direction, atr_val) if stop else {},
        "max_daily_loss_usd": round(account_usd * 0.03, 2),
        "valid": valid,
        "errors": errors,
        "warnings": warnings,
        "normalized": bool(warnings),
        "direction": direction,
    }


def rr(entry, stop, target):
    if not stop or not target or not entry:
        return None
    r = abs(entry - stop)
    return round(abs(target - entry) / r, 2) if r else None
