from typing import Any, Dict, List, Optional


def _avg_range(candles: List[Dict[str, Any]], lookback: int = 50) -> float:
    recent = candles[-lookback:] if len(candles) > lookback else candles
    if not recent:
        return 0.0
    return sum(float(c['high']) - float(c['low']) for c in recent) / len(recent)


def find_swings(candles: List[Dict[str, Any]], left: int = 8, right: int = 8) -> List[Dict[str, Any]]:
    """Institutional swing detector using high/low, not close.

    Larger defaults reduce false pivots versus retail zigzag-style detection.
    """
    if len(candles) < left + right + 1:
        return []
    pivots: List[Dict[str, Any]] = []
    for i in range(left, len(candles) - right):
        h = float(candles[i]['high'])
        l = float(candles[i]['low'])
        lp = candles[i-left:i]
        rp = candles[i+1:i+right+1]
        if h > max(float(c['high']) for c in lp) and h >= max(float(c['high']) for c in rp):
            pivots.append({'idx': i, 'time': candles[i]['time'], 'price': h, 'kind': 'H'})
        if l < min(float(c['low']) for c in lp) and l <= min(float(c['low']) for c in rp):
            pivots.append({'idx': i, 'time': candles[i]['time'], 'price': l, 'kind': 'L'})
    pivots.sort(key=lambda x: x['idx'])

    cleaned: List[Dict[str, Any]] = []
    for p in pivots:
        if not cleaned or cleaned[-1]['kind'] != p['kind']:
            cleaned.append(p)
        else:
            prev = cleaned[-1]
            if (p['kind'] == 'H' and p['price'] > prev['price']) or (p['kind'] == 'L' and p['price'] < prev['price']):
                cleaned[-1] = p
    return cleaned


def find_liquidity_pools(candles: List[Dict[str, Any]], swings: Optional[List[Dict[str, Any]]] = None, tolerance_atr_mult: float = 0.25) -> List[Dict[str, Any]]:
    """Find likely resting liquidity: equal highs/lows clustered around swing levels."""
    swings = swings if swings is not None else find_swings(candles)
    atr_like = _avg_range(candles)
    tol = max(atr_like * tolerance_atr_mult, (candles[-1]['close'] if candles else 1) * 0.0008)
    pools: List[Dict[str, Any]] = []

    for kind, pool_type in [('H', 'buy_side_liquidity'), ('L', 'sell_side_liquidity')]:
        pts = [s for s in swings if s['kind'] == kind]
        used = set()
        for i, p in enumerate(pts):
            if i in used:
                continue
            cluster = [p]
            for j in range(i + 1, len(pts)):
                if abs(float(pts[j]['price']) - float(p['price'])) <= tol:
                    cluster.append(pts[j])
                    used.add(j)
            if len(cluster) >= 2:
                price = sum(float(x['price']) for x in cluster) / len(cluster)
                pools.append({
                    'type': pool_type,
                    'price': price,
                    'touches': len(cluster),
                    'first_idx': cluster[0]['idx'],
                    'last_idx': cluster[-1]['idx'],
                    'time': cluster[-1]['time'],
                    'strength': min(100, len(cluster) * 25),
                })
    return sorted(pools, key=lambda x: (x['strength'], x['last_idx']), reverse=True)


def detect_sweeps(candles: List[Dict[str, Any]], pools: List[Dict[str, Any]], lookback: int = 35) -> List[Dict[str, Any]]:
    """Detect sweep + rejection, not merely a level breach."""
    sweeps: List[Dict[str, Any]] = []
    recent_start = max(0, len(candles) - lookback)
    for p in pools:
        for i in range(max(recent_start, int(p.get('last_idx', 0)) + 1), len(candles)):
            c = candles[i]
            close = float(c['close'])
            high = float(c['high'])
            low = float(c['low'])
            price = float(p['price'])
            if p['type'] == 'buy_side_liquidity' and high > price and close < price:
                sweeps.append({'type': 'buy_side_sweep', 'price': price, 'time': c['time'], 'idx': i, 'rejection_close': close, 'strength': p.get('strength', 0)})
            elif p['type'] == 'sell_side_liquidity' and low < price and close > price:
                sweeps.append({'type': 'sell_side_sweep', 'price': price, 'time': c['time'], 'idx': i, 'rejection_close': close, 'strength': p.get('strength', 0)})
    # Keep newest unique sweeps
    uniq = []
    seen = set()
    for s in sorted(sweeps, key=lambda x: x['idx'], reverse=True):
        key = (s['type'], round(s['price'], 6))
        if key not in seen:
            uniq.append(s)
            seen.add(key)
    return list(reversed(uniq[-12:]))


def nearest_liquidity_targets(entry: float, pools: List[Dict[str, Any]], direction: str) -> Dict[str, Any]:
    if not entry:
        return {'tp1': None, 'tp2': None, 'target_pools': []}
    if direction == 'LONG':
        above = sorted([p for p in pools if p['type'] == 'buy_side_liquidity' and p['price'] > entry], key=lambda p: p['price'])
        return {'tp1': above[0]['price'] if len(above) > 0 else None, 'tp2': above[1]['price'] if len(above) > 1 else None, 'target_pools': above[:3]}
    if direction == 'SHORT':
        below = sorted([p for p in pools if p['type'] == 'sell_side_liquidity' and p['price'] < entry], key=lambda p: p['price'], reverse=True)
        return {'tp1': below[0]['price'] if len(below) > 0 else None, 'tp2': below[1]['price'] if len(below) > 1 else None, 'target_pools': below[:3]}
    return {'tp1': None, 'tp2': None, 'target_pools': []}
