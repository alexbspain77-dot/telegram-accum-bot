"""
market_scanner.py v8.6 — оптимизированный

Исправления:
1. Лимит снижен до 20 символов (было 100) — меньше нагрузки
2. min_confidence=50 по умолчанию — только сильные сигналы в heatmap
3. TTL кэша увеличен до 30 сек
4. Heatmap endpoint: только LONG/SHORT с confidence>=55 — никакого мусора
5. Добавлен watchlist-first режим: сначала watchlist, потом топ рынок
"""
from __future__ import annotations
import time
from typing import Any, Dict, List
from .data_feed import get_dashboard, get_tickers, normalize_symbol

_CACHE:  Dict[str, Any] = {"time": 0.0, "tf": None, "data": []}
_HM_CACHE: Dict[str, Any] = {"time": 0.0, "data": []}

CACHE_TTL   = 30   # было 20
HM_TTL      = 60   # heatmap обновляется реже
SCAN_LIMIT  = 20   # было 100 — снизили нагрузку
MIN_CONF    = 50   # минимальный confidence для попадания в сканер
HM_MIN_CONF = 55   # минимальный confidence для heatmap


def scan_market(tf: str = "15", min_confidence: int = MIN_CONF,
                limit: int = SCAN_LIMIT, symbols: str = "") -> List[Dict[str, Any]]:
    """
    Сканирует рынок.
    symbols — опциональный список через запятую (watchlist-first режим).
    """
    now = time.time()
    cache_key_tf = str(tf)
    if (_CACHE["tf"] == cache_key_tf and
            now - float(_CACHE["time"] or 0) < CACHE_TTL and
            not symbols):
        return list(_CACHE["data"])

    try:
        rows = get_dashboard(symbols, limit=min(limit, SCAN_LIMIT), interval=str(tf))
    except Exception as e:
        print("[market_scanner] get_dashboard error:", type(e).__name__, e)
        rows = []

    out: List[Dict[str, Any]] = []
    for s in rows:
        try:
            conf = float(s.get("confidence") or 0)
            if conf < min_confidence:
                continue
            out.append({
                **s,
                "confidence": round(conf, 1),
                "side": s.get("direction") or s.get("side") or "NEUTRAL",
                "rr":   s.get("rr1") or s.get("rr") or 0,
            })
        except Exception as e:
            print("[market_scanner] row error:", s.get("symbol"), e)

    out.sort(key=lambda x: float(x.get("confidence") or 0), reverse=True)
    result = out[:30]

    if not symbols:
        _CACHE.update({"time": now, "tf": cache_key_tf, "data": result})

    return result


def get_heatmap_signals(tf: str = "15") -> List[Dict[str, Any]]:
    """
    Возвращает только сильные сигналы для heatmap.
    Только LONG/SHORT, confidence >= 55, не NO_TRADE.
    Кэш 60 сек.
    """
    now = time.time()
    if now - float(_HM_CACHE["time"] or 0) < HM_TTL and _HM_CACHE["data"]:
        return list(_HM_CACHE["data"])

    all_signals = scan_market(tf=tf, min_confidence=HM_MIN_CONF, limit=SCAN_LIMIT)

    heatmap = []
    for s in all_signals:
        direction = s.get("direction") or s.get("side") or "NEUTRAL"
        stype     = s.get("scenario_type") or direction
        conf      = float(s.get("confidence") or 0)

        # Только реальные сигналы — не NO_TRADE, не мусор
        if direction not in ("LONG", "SHORT"):
            continue
        if stype == "NO_TRADE" and s.get("early_mode") != "EARLY":
            continue
        if conf < HM_MIN_CONF:
            continue

        heatmap.append({
            "symbol":     s.get("symbol"),
            "direction":  direction,
            "confidence": conf,
            "setup":      stype,
            "trap":       s.get("trap",""),
            "early_mode": s.get("early_mode",""),
            "early_grade":s.get("early_grade",""),
            "rr1":        s.get("rr1"),
            "quality":    s.get("quality"),
            "session":    s.get("session"),
            "bos":        s.get("bos"),
            "choch":      s.get("choch"),
            "has_fvg":    s.get("has_fvg"),
            "has_sweep":  s.get("has_sweep"),
        })

    heatmap.sort(key=lambda x: float(x.get("confidence") or 0), reverse=True)
    _HM_CACHE.update({"time": now, "data": heatmap[:20]})
    return heatmap
