Phase Engine v1 integrated.

File:
- app/phase_engine.py

Phases:
- ACCUMULATION
- DISTRIBUTION
- MIXED_ABSORPTION
- NEUTRAL

Used models:
- OBV divergence
- A/D line
- CMF
- delta proxy
- volume spike absorption
- volume profile b/P shape
- orderflow absorption

Integration:
- app/institutional.py calls detect_phase()
- phase_decision_adjustment() changes scenario confidence
- app/data_feed.py sends market_phase / phase_strength to dashboard cards
- app/server.py sends phase in /api/v7/chart/<symbol>
- templates/chart_window.html shows Market Phase block
