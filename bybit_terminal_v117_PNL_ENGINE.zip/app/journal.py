"""
journal.py — persistent signal journal for v7.5.

Stores every actionable scenario snapshot in JSONL so we can later backtest,
review mistakes, and build UI statistics without adding a database yet.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json
from typing import Any, Dict, List

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)
JOURNAL_PATH = DATA_DIR / "signal_journal.jsonl"


def append_signal(symbol: str, tf: str, report: Dict[str, Any]) -> None:
    scenario = report.get("scenario", {}) or {}
    stype = scenario.get("type", "NO_TRADE")
    confidence = int(scenario.get("confidence", 0) or 0)

    # Keep the journal useful: store only actionable or high-interest cases.
    if stype == "NO_TRADE" and confidence < 45 and scenario.get("trap", "NONE") == "NONE":
        return

    row = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "symbol": symbol,
        "tf": tf,
        "scenario": stype,
        "direction": scenario.get("direction"),
        "confidence": confidence,
        "setup": scenario.get("setup"),
        "trap": scenario.get("trap"),
        "reasons": scenario.get("reasons", [])[:8],
        "risk": report.get("risk", {}),
        "summary": report.get("summary", {}),
    }
    with JOURNAL_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_last(limit: int = 100) -> List[Dict[str, Any]]:
    if not JOURNAL_PATH.exists():
        return []
    lines = JOURNAL_PATH.read_text(encoding="utf-8").splitlines()[-limit:]
    out = []
    for line in lines:
        try:
            out.append(json.loads(line))
        except Exception:
            continue
    return list(reversed(out))


def clear() -> None:
    JOURNAL_PATH.write_text("", encoding="utf-8")
