from typing import List, Dict, Any, Optional


def sma(values: List[float], period: int) -> List[Optional[float]]:
    if period <= 0:
        raise ValueError("period must be positive")
    out: List[Optional[float]] = [None] * len(values)
    if len(values) < period:
        return out
    window_sum = sum(values[:period])
    out[period - 1] = window_sum / period
    for i in range(period, len(values)):
        window_sum += values[i] - values[i - period]
        out[i] = window_sum / period
    return out


def ema(values: List[float], period: int) -> List[Optional[float]]:
    """EMA seeded with SMA(period). Values before period-1 are None.

    This avoids the common error where EMA starts from the first close and distorts
    early values, especially on short datasets.
    """
    if period <= 0:
        raise ValueError("period must be positive")
    out: List[Optional[float]] = [None] * len(values)
    if len(values) < period:
        return out
    k = 2 / (period + 1)
    e = sum(values[:period]) / period
    out[period - 1] = e
    for i in range(period, len(values)):
        e = values[i] * k + e * (1 - k)
        out[i] = e
    return out


def rsi(values: List[float], period: int = 14) -> List[Optional[float]]:
    """Wilder RSI in O(n). Values before period are None."""
    if period <= 0:
        raise ValueError("period must be positive")
    out: List[Optional[float]] = [None] * len(values)
    if len(values) < period + 1:
        return out

    gains = []
    losses = []
    for i in range(1, period + 1):
        ch = values[i] - values[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))

    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    out[period] = 100.0 if avg_loss == 0 else 100.0 - (100.0 / (1.0 + avg_gain / avg_loss))

    for i in range(period + 1, len(values)):
        ch = values[i] - values[i - 1]
        gain = max(ch, 0.0)
        loss = max(-ch, 0.0)
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
        out[i] = 100.0 if avg_loss == 0 else 100.0 - (100.0 / (1.0 + avg_gain / avg_loss))
    return out


def atr(candles: List[Dict[str, Any]], period: int = 14) -> List[Optional[float]]:
    out: List[Optional[float]] = [None] * len(candles)
    if len(candles) < period + 1:
        return out
    trs: List[float] = []
    for i, c in enumerate(candles):
        if i == 0:
            tr = float(c["high"]) - float(c["low"])
        else:
            prev_close = float(candles[i - 1]["close"])
            tr = max(
                float(c["high"]) - float(c["low"]),
                abs(float(c["high"]) - prev_close),
                abs(float(c["low"]) - prev_close),
            )
        trs.append(tr)
    first = sum(trs[1:period + 1]) / period
    out[period] = first
    val = first
    for i in range(period + 1, len(candles)):
        val = (val * (period - 1) + trs[i]) / period
        out[i] = val
    return out


def to_line(candles: List[Dict[str, Any]], values):
    return [
        {"time": c["time"], "value": float(v)}
        for c, v in zip(candles, values)
        if v is not None
    ]
