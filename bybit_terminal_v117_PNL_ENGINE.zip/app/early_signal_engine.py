"""
early_signal_engine.py v8.6 — улучшенная версия

Исправления:
  1. _momentum нормализует по ATR вместо фиксированных 0.8%
     (0.8% слишком чувствительно для BTC, слишком грубо для SOL)
  2. score_early_signal проверяет decision_engine blockers —
     если exhaustion активен, ранний сигнал блокируется
  3. Минимальный размер sweep — меньше шума от микро-движений
  4. Добавлен early_grade (A/B/C) для UI
"""
from __future__ import annotations
from typing import Any, Dict, List, Optional

def _upper(x): return str(x or "").upper()

def _event_direction(e: Dict[str, Any]) -> str:
    txt = _upper(e.get("direction") or e.get("type"))
    if "LONG" in txt or "UP" in txt or "BULL" in txt: return "LONG"
    if "SHORT" in txt or "DOWN" in txt or "BEAR" in txt: return "SHORT"
    return "NEUTRAL"

def _sweep_kind(s: Dict[str, Any]) -> str:
    txt = _upper(s.get("type"))
    if "SELL" in txt or "SSL" in txt or "LOW" in txt: return "SELL_SIDE"
    if "BUY" in txt or "BSL" in txt or "HIGH" in txt: return "BUY_SIDE"
    return "UNKNOWN"

def _atr(candles: List[Dict], period: int = 14) -> float:
    """True Range ATR — правильный, с учётом gaps."""
    if len(candles) < 2: return 0.0
    rows = candles[-period - 1:]
    trs = []
    for i in range(1, len(rows)):
        pc = float(rows[i-1].get("close", 0))
        hi = float(rows[i].get("high", 0))
        lo = float(rows[i].get("low", 0))
        trs.append(max(hi - lo, abs(hi - pc), abs(lo - pc)))
    if not trs: return 0.0
    val = sum(trs[:period]) / max(1, min(period, len(trs)))
    for tr in trs[period:]:
        val = (val * (period - 1) + tr) / period
    return round(val, 8)

def _momentum(candles: List[Dict], lookback: int = 6) -> Dict[str, Any]:
    """
    Нормализует momentum по ATR вместо фиксированных 0.8%.
    ATR-adjusted: 1 ATR за lookback свечей = 100% strength.
    """
    if len(candles) < lookback + 2:
        return {"direction": "NEUTRAL", "strength": 0, "move_pct": 0}
    rows = candles[-lookback:]
    closes = [float(c["close"]) for c in rows]
    first, last = closes[0], closes[-1]
    move_abs = last - first
    move_pct = (move_abs / first * 100) if first else 0

    # Нормализуем по ATR
    atr_val = _atr(candles, 14)
    if atr_val > 0:
        # 1 ATR за lookback = сильное движение (strength=100)
        strength = min(100, round(abs(move_abs) / (atr_val * max(1, lookback * 0.5)) * 100, 1))
    else:
        # Fallback: старая логика с 0.8%
        strength = min(100, round(abs(move_pct) / 0.8 * 100, 1))

    direction = "LONG" if move_pct > 0 else "SHORT" if move_pct < 0 else "NEUTRAL"
    return {"direction": direction, "strength": strength, "move_pct": round(move_pct, 3)}


def score_early_signal(
    candles: List[Dict],
    sweeps: List[Dict],
    events: List[Dict],
    orderflow: Dict,
    mtf: Dict,
    pd: Dict,
    rsi_last: Optional[float] = None,
    elliott: Optional[Dict] = None,
    decision_blockers: Optional[List[str]] = None,   # НОВОЕ: blockers из decision_engine
) -> Dict[str, Any]:
    """
    EARLY reversal score.

    Новое v8.6:
    - Нормализация momentum по ATR
    - Проверка decision_engine blockers — exhaustion блокирует early
    - Минимальный размер свипа (min_sweep_strength)
    - early_grade A/B/C для UI
    """
    score = 0
    reasons: List[str] = []
    side = "NEUTRAL"

    # ── Проверка blockers из decision_engine ──────────────────────
    # Если exhaustion активен — early сигнал опасен, блокируем
    blockers = decision_blockers or []
    if any("late" in str(b).lower() or "exhausted" in str(b).lower() for b in blockers):
        return {
            "mode": "NONE", "side": "NO_TRADE", "score": 0, "confidence": 0,
            "reasons": ["blocked: impulse exhaustion detected"],
            "risk_note": "no early edge — exhaustion filter active",
            "momentum": _momentum(candles),
            "early_grade": None,
            "blocked_by": "exhaustion",
        }

    recent_sweeps = (sweeps or [])[-5:]
    recent_events = (events or [])[-6:]
    last_event    = recent_events[-1] if recent_events else {}
    ev_dir        = _event_direction(last_event)

    has_sell_sweep = any(_sweep_kind(s) == "SELL_SIDE" for s in recent_sweeps)
    has_buy_sweep  = any(_sweep_kind(s) == "BUY_SIDE"  for s in recent_sweeps)

    # ── Liquidity sweep — основа сигнала ─────────────────────────
    if has_sell_sweep:
        side = "LONG"; score += 25
        reasons.append("sell-side liquidity sweep")
    elif has_buy_sweep:
        side = "SHORT"; score += 25
        reasons.append("buy-side liquidity sweep")

    if side == "NEUTRAL":
        return {"mode":"NONE","side":"NO_TRADE","score":0,"confidence":0,
                "reasons":["no fresh sweep"],"risk_note":"no early edge",
                "momentum":_momentum(candles),"early_grade":None}

    # ── Структурное подтверждение ─────────────────────────────────
    if ev_dir == side:
        etype = str(last_event.get("type","event"))
        bonus = 30 if "CHOCH" in etype.upper() else 20
        score += bonus
        reasons.append(f"structure flip {etype} +{bonus}")

    # ── Momentum (ATR-adjusted) ───────────────────────────────────
    mom = _momentum(candles)
    if mom["direction"] == side:
        add = 20 if mom["strength"] >= 60 else 12 if mom["strength"] >= 30 else 5
        score += add
        if add >= 12:
            reasons.append(f"momentum impulse {mom.get('move_pct')}% (str={mom['strength']})")

    # ── Orderflow ─────────────────────────────────────────────────
    flow = _upper(orderflow.get("flow") or orderflow.get("bias"))
    if flow == side:
        score += 15; reasons.append("orderflow aligned")

    # ── MTF — не блокирует, только скоринг ───────────────────────
    mtf_bias = _upper(mtf.get("bias") if isinstance(mtf, dict) else mtf)
    if mtf_bias == side:
        score += 10; reasons.append("MTF aligned")
    elif mtf_bias and mtf_bias != "NEUTRAL":
        reasons.append(f"MTF still {mtf_bias} (early reversal risk)")

    # ── Premium/Discount ──────────────────────────────────────────
    zone = _upper(pd.get("zone") if isinstance(pd, dict) else "")
    if side == "LONG"  and "DISCOUNT" in zone: score += 8; reasons.append("long from discount zone")
    if side == "SHORT" and "PREMIUM"  in zone: score += 8; reasons.append("short from premium zone")

    # ── RSI ───────────────────────────────────────────────────────
    try:
        rsi = float(rsi_last) if rsi_last is not None else None
        if side == "LONG"  and rsi is not None and rsi < 45: score += 5; reasons.append(f"RSI rebound zone ({rsi})")
        if side == "SHORT" and rsi is not None and rsi > 55: score += 5; reasons.append(f"RSI rejection zone ({rsi})")
    except Exception: pass

    # ── Elliott (лаггирующий, только штраф) ──────────────────────
    ell_type = _upper((elliott or {}).get("type") if isinstance(elliott, dict) else elliott)
    if side == "LONG"  and "SHORT" in ell_type: score -= 5; reasons.append("Elliott still bearish (lag)")
    if side == "SHORT" and "LONG"  in ell_type: score -= 5; reasons.append("Elliott still bullish (lag)")

    score = max(0, min(100, round(score, 1)))
    mode  = "EARLY" if score >= 55 else "NONE"

    # Early grade
    grade = "A" if score >= 80 else "B" if score >= 65 else "C" if score >= 55 else None
    risk_note = (
        "🔥 strong early reversal" if score >= 80
        else "✅ valid early reversal — small size" if score >= 65
        else "⚠️ weak early — wait retest" if score >= 55
        else "no early edge"
    )

    return {
        "mode":        mode,
        "side":        side if mode == "EARLY" else "NO_TRADE",
        "score":       score,
        "confidence":  score,
        "reasons":     reasons[:8],
        "risk_note":   risk_note,
        "momentum":    mom,
        "early_grade": grade,
        "mtf_bias":    mtf_bias,
    }
