from __future__ import annotations
from typing import Any, Dict, List, Optional
import math

def _f(v, d=0.0):
    try: return float(v)
    except Exception: return d

def _pct(a, b):
    b = abs(b) if b else 1e-12
    return (a / b) * 100.0

def _lin_slope(vals: List[float]) -> float:
    n = len(vals)
    if n < 2: return 0.0
    xs = list(range(n))
    mx = sum(xs)/n
    my = sum(vals)/n
    den = sum((x-mx)**2 for x in xs) or 1e-12
    return sum((xs[i]-mx)*(vals[i]-my) for i in range(n)) / den

def _atr(candles: List[Dict[str, Any]], n: int = 14) -> float:
    if len(candles) < 2: return 0.0
    trs=[]
    for i,c in enumerate(candles[-n-1:]):
        h,l=_f(c.get("high")),_f(c.get("low"))
        if i==0:
            trs.append(h-l); continue
        p=_f(candles[-n-1+i-1].get("close"))
        trs.append(max(h-l, abs(h-p), abs(l-p)))
    return sum(trs)/max(1,len(trs))

def _range_stats(candles, n=40):
    part=candles[-n:]
    highs=[_f(c.get("high")) for c in part]
    lows=[_f(c.get("low")) for c in part]
    closes=[_f(c.get("close")) for c in part]
    vols=[_f(c.get("volume")) for c in part]
    hi=max(highs) if highs else 0
    lo=min(lows) if lows else 0
    close=closes[-1] if closes else 0
    width=(hi-lo)/max(close,1e-12)*100 if close else 0
    return {"high":hi,"low":lo,"close":close,"width_pct":width,"highs":highs,"lows":lows,"closes":closes,"vols":vols}

def detect_compression(candles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(candles) < 30: return None
    part=candles[-30:]
    highs=[_f(c.get("high")) for c in part]
    lows=[_f(c.get("low")) for c in part]
    ranges=[max(0,_f(c.get("high"))-_f(c.get("low"))) for c in part]
    vols=[_f(c.get("volume")) for c in part]

    hi_slope=_lin_slope(highs[-18:])
    lo_slope=_lin_slope(lows[-18:])
    rng_recent=sum(ranges[-8:])/8
    rng_prev=sum(ranges[:12])/12
    vol_recent=sum(vols[-8:])/8 if vols else 0
    vol_prev=sum(vols[:12])/12 if vols else 0
    close=_f(part[-1].get("close"))

    lower_highs = hi_slope < 0
    higher_lows = lo_slope > 0
    range_contract = rng_recent < rng_prev * 0.72 if rng_prev else False
    vol_contract = vol_recent < vol_prev * 0.85 if vol_prev else False

    if lower_highs and higher_lows and (range_contract or vol_contract):
        strength = 45
        if range_contract: strength += 20
        if vol_contract: strength += 15
        if abs(hi_slope) > 0 and abs(lo_slope) > 0: strength += 10
        return {
            "type":"COMPRESSION",
            "direction":"NEUTRAL",
            "strength":min(95,int(strength)),
            "bias":"BREAKOUT_PENDING",
            "high":round(max(highs[-18:]),8),
            "low":round(min(lows[-18:]),8),
            "reason":"lower highs + higher lows / volatility compression",
        }
    return None

def detect_range_box(candles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(candles) < 35: return None
    st=_range_stats(candles, 42)
    width=st["width_pct"]
    close=st["close"]
    if not close: return None
    atr=_atr(candles,14)
    atr_pct=atr/max(close,1e-12)*100
    touches_hi=sum(1 for h in st["highs"] if abs(h-st["high"])/max(close,1e-12)*100 < max(0.25, atr_pct*0.8))
    touches_lo=sum(1 for l in st["lows"] if abs(l-st["low"])/max(close,1e-12)*100 < max(0.25, atr_pct*0.8))
    if width <= max(4.5, atr_pct*8) and touches_hi>=2 and touches_lo>=2:
        strength=min(90, 40+touches_hi*7+touches_lo*7)
        return {
            "type":"RANGE_BOX",
            "direction":"NEUTRAL",
            "strength":int(strength),
            "high":round(st["high"],8),
            "low":round(st["low"],8),
            "width_pct":round(width,3),
            "touches_high":touches_hi,
            "touches_low":touches_lo,
            "reason":"defined range with repeated high/low touches",
        }
    return None

def detect_liquidity_sweep(candles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(candles) < 25: return None
    prev=candles[-21:-1]
    last=candles[-1]
    prev_hi=max(_f(c.get("high")) for c in prev)
    prev_lo=min(_f(c.get("low")) for c in prev)
    h,l,o,c=_f(last.get("high")),_f(last.get("low")),_f(last.get("open")),_f(last.get("close"))
    rng=max(h-l,1e-12)
    close_pos=(c-l)/rng
    vol=_f(last.get("volume"))
    avg_vol=sum(_f(x.get("volume")) for x in prev)/max(1,len(prev))
    vol_ok=vol>avg_vol*1.15 if avg_vol else False

    if l < prev_lo and c > prev_lo and close_pos > 0.55:
        strength=65 + (15 if vol_ok else 0)
        return {"type":"LIQUIDITY_SWEEP","direction":"LONG","strength":min(95,strength),
                "level":round(prev_lo,8),"sweep_low":round(l,8),"reason":"sell-side sweep and reclaim"}
    if h > prev_hi and c < prev_hi and close_pos < 0.45:
        strength=65 + (15 if vol_ok else 0)
        return {"type":"LIQUIDITY_SWEEP","direction":"SHORT","strength":min(95,strength),
                "level":round(prev_hi,8),"sweep_high":round(h,8),"reason":"buy-side sweep and reject"}
    return None

def detect_impulse_pullback(candles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(candles) < 35: return None
    part=candles[-35:]
    closes=[_f(c.get("close")) for c in part]
    highs=[_f(c.get("high")) for c in part]
    lows=[_f(c.get("low")) for c in part]
    atr=_atr(candles,14) or (closes[-1]*0.005)
    # impulse on bars -15..-6, pullback on last 6
    imp_start=closes[-18]
    imp_end=closes[-7]
    move=imp_end-imp_start
    pull=closes[-1]-imp_end
    if abs(move) < atr*2.0: return None

    if move > 0:
        retr=abs(pull)/max(abs(move),1e-12)
        higher_low=min(lows[-6:]) > min(lows[-18:-7])
        if 0.25 <= retr <= 0.72 and higher_low:
            return {"type":"IMPULSE_PULLBACK","direction":"LONG","strength":min(92,int(55+(1-retr)*35)),
                    "impulse_from":round(imp_start,8),"impulse_to":round(imp_end,8),
                    "retracement":round(retr,3),"reason":"bullish impulse with controlled pullback"}
    else:
        retr=abs(pull)/max(abs(move),1e-12)
        lower_high=max(highs[-6:]) < max(highs[-18:-7])
        if 0.25 <= retr <= 0.72 and lower_high:
            return {"type":"IMPULSE_PULLBACK","direction":"SHORT","strength":min(92,int(55+(1-retr)*35)),
                    "impulse_from":round(imp_start,8),"impulse_to":round(imp_end,8),
                    "retracement":round(retr,3),"reason":"bearish impulse with controlled pullback"}
    return None

def detect_breakout_retest(candles: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if len(candles) < 35: return None
    prev=candles[-31:-3]
    last3=candles[-3:]
    hi=max(_f(c.get("high")) for c in prev)
    lo=min(_f(c.get("low")) for c in prev)
    c0=_f(last3[0].get("close"))
    l1=_f(last3[1].get("low")); h1=_f(last3[1].get("high"))
    c2=_f(last3[2].get("close"))
    atr=_atr(candles,14) or 0
    tol=max(atr*0.6, _f(last3[-1].get("close"))*0.002)
    if c0 > hi and abs(l1-hi) <= tol and c2 > hi:
        return {"type":"BREAKOUT_RETEST","direction":"LONG","strength":78,"level":round(hi,8),
                "reason":"breakout above range and successful retest"}
    if c0 < lo and abs(h1-lo) <= tol and c2 < lo:
        return {"type":"BREAKOUT_RETEST","direction":"SHORT","strength":78,"level":round(lo,8),
                "reason":"breakdown below range and successful retest"}
    return None

def detect_patterns(candles: List[Dict[str, Any]], smc: Dict[str,Any] | None=None, orderflow: Dict[str,Any] | None=None) -> Dict[str, Any]:
    try:
        patterns=[]
        for fn in (detect_liquidity_sweep, detect_breakout_retest, detect_impulse_pullback, detect_compression, detect_range_box):
            p=fn(candles)
            if p: patterns.append(p)
        patterns=sorted(patterns, key=lambda x: x.get("strength",0), reverse=True)
        primary=patterns[0] if patterns else None

        long_score=sum(p.get("strength",0) for p in patterns if p.get("direction")=="LONG")
        short_score=sum(p.get("strength",0) for p in patterns if p.get("direction")=="SHORT")
        neutral_score=sum(p.get("strength",0) for p in patterns if p.get("direction")=="NEUTRAL")
        if long_score > short_score and long_score>=55:
            bias="LONG"
        elif short_score > long_score and short_score>=55:
            bias="SHORT"
        elif neutral_score>=60:
            bias="NEUTRAL_SETUP"
        else:
            bias="NEUTRAL"
        return {"ok":True,"patterns":patterns[:8],"primary":primary,"bias":bias,
                "long_score":int(long_score),"short_score":int(short_score),"neutral_score":int(neutral_score)}
    except Exception as e:
        return {"ok":False,"patterns":[],"primary":None,"bias":"ERROR","error":str(e)}

def pattern_decision_adjustment(patterns_report: Dict[str,Any], direction: str) -> Dict[str,Any]:
    direction=direction or "NEUTRAL"
    pats=patterns_report.get("patterns") or []
    adj=0; reasons=[]; warnings=[]; blockers=[]
    for p in pats[:5]:
        typ=p.get("type"); pd=p.get("direction"); strength=int(p.get("strength") or 0)
        if pd==direction and direction in ("LONG","SHORT"):
            add=8 if strength<75 else 14
            adj+=add; reasons.append(f"{typ} supports {direction} (+{add})")
        elif pd in ("LONG","SHORT") and direction in ("LONG","SHORT") and pd!=direction:
            adj-=10; warnings.append(f"{typ} conflicts with {direction}")
        elif typ=="COMPRESSION":
            warnings.append("compression: wait for breakout confirmation")
            adj-=2
        elif typ=="RANGE_BOX":
            warnings.append("range market: avoid midpoint entries")
            adj-=4
    return {"score_adjustment":adj,"reasons":reasons,"warnings":warnings,"blockers":blockers}
