"""data_feed.py v8.6 — adds early_mode/grade/score to dashboard cards"""
from __future__ import annotations
import random, time
from typing import Any, Dict, List, Optional

try:
    import requests as _r
    _session = _r.Session()
    _session.headers.update({"User-Agent":"bybit-terminal/8.6"})
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

BYBIT = "https://api.bybit.com"
DEFAULT_SYMBOLS = [
    "BTCUSDT","ETHUSDT","SOLUSDT","XRPUSDT","BNBUSDT",
    "DOGEUSDT","AVAXUSDT","ADAUSDT","LINKUSDT","DOTUSDT",
    "UNIUSDT","LTCUSDT","ATOMUSDT","NEARUSDT","MATICUSDT",
]

_ticker_cache: tuple = (0.0, [])
_ohlc_cache: Dict[str,tuple] = {}

def _get(path, params=None, timeout=8):
    if not _HAS_REQUESTS: return None
    try:
        r = _session.get(BYBIT+path, params=params or {}, timeout=timeout)
        js = r.json()
        return js["result"] if js.get("retCode")==0 else None
    except Exception: return None

def normalize_symbol(s):
    s = str(s).upper().strip().replace("/","").replace("-","").replace(" ","")
    return s if s.endswith("USDT") else s+"USDT"

def _sf(v, d=0.0):
    try: return float(v)
    except Exception: return d

def get_tickers(limit=30):
    global _ticker_cache
    now = time.time()
    if now - _ticker_cache[0] < 20 and _ticker_cache[1]:
        return _ticker_cache[1][:limit]
    raw = _get("/v5/market/tickers", {"category":"linear","limit":"200"})
    if raw and raw.get("list"):
        tickers = sorted(
            [t for t in raw["list"] if t.get("symbol","").endswith("USDT")],
            key=lambda x: _sf(x.get("turnover24h"), 0), reverse=True
        )
        _ticker_cache = (now, tickers)
        return tickers[:limit]
    return _mock_tickers(limit)

def get_ohlc(symbol, interval="60", limit=300):
    key = f"{symbol}_{interval}_{limit}"
    now = time.time()
    if key in _ohlc_cache and now - _ohlc_cache[key][0] < 35:
        return _ohlc_cache[key][1]
    raw = _get("/v5/market/kline", {"category":"linear","symbol":symbol,
                                     "interval":str(interval),"limit":str(limit)})
    if raw and raw.get("list"):
        candles = []
        for row in reversed(raw["list"]):
            try: candles.append({"time":int(row[0])//1000,"open":float(row[1]),"high":float(row[2]),
                                  "low":float(row[3]),"close":float(row[4]),"volume":float(row[5])})
            except Exception: pass
        _ohlc_cache[key] = (now, candles)
        return candles
    return _mock_ohlc(symbol, limit)

def get_mtf_bias(symbol):
    biases = {}
    for tf, name in [("240","h4"),("D","d1"),("W","w1")]:
        candles = get_ohlc(symbol, tf, 60)
        if len(candles) >= 3:
            hi = max(c["high"] for c in candles[-20:])
            lo = min(c["low"]  for c in candles[-20:])
            close = candles[-1]["close"]
            biases[name] = "LONG" if close > (hi+lo)/2 else "SHORT"
        else:
            biases[name] = "NEUTRAL"
    v = list(biases.values())
    L, S = v.count("LONG"), v.count("SHORT")
    return {"bias":"LONG" if L>S else "SHORT" if S>L else "NEUTRAL", **biases, "votes":{"LONG":L,"SHORT":S}}

def get_orderbook_imbalance(symbol):
    raw = _get("/v5/market/orderbook", {"category":"linear","symbol":symbol,"limit":"25"})
    if not raw: return {"imbalance":0.0,"bias":"NEUTRAL","bid_vol":0,"ask_vol":0}
    bids = sum(_sf(b[1]) for b in (raw.get("b") or []))
    asks = sum(_sf(a[1]) for a in (raw.get("a") or []))
    total = bids + asks
    imb = (bids-asks)/total if total else 0.0
    return {"imbalance":round(imb,4),"bid_vol":round(bids,2),"ask_vol":round(asks,2),
            "bias":"LONG" if imb>0.05 else "SHORT" if imb<-0.05 else "NEUTRAL"}

def get_dashboard(symbols="", limit=30, interval="15"):
    from .institutional import institutional_report
    requested = [normalize_symbol(x) for x in symbols.replace(","," ").split() if x.strip()]
    if requested:
        ticker_map = {t.get("symbol"):t for t in get_tickers(160)}
        raw = [ticker_map.get(sym,{"symbol":sym,"lastPrice":"0","price24hPcnt":"0","turnover24h":"0"})
               for sym in requested[:limit]]
    else:
        raw = get_tickers(limit)

    cards: List[Dict[str,Any]] = []
    for t in raw[:limit]:
        symbol = normalize_symbol(t.get("symbol") or "BTCUSDT")
        last   = _sf(t.get("lastPrice"), 0)
        change = round(_sf(t.get("price24hPcnt"), 0) * 100, 3)
        try:
            inst = institutional_report(symbol, interval)
            sc   = inst.get("scenario", {})
            smc  = inst.get("smc", {})
            of   = inst.get("orderflow", {})
            mtf  = inst.get("mtf", {})
            risk = inst.get("risk", {})
            confluence = inst.get("confluence", {}) or {}
            phase = inst.get("phase", {}) or {}
            pro = inst.get("pro_trader", {}) or {}
            dv3 = inst.get("decision_v3", {}) or {}
            patterns = inst.get("patterns", {}) or {}
            zones = inst.get("smart_zones", {}) or {}
            dec  = sc.get("decision", {})
            early= inst.get("early_signal", {})

            rsi_last = inst.get("rsi")
            fvg_list = inst.get("fvg_zones", [])
            sweeps   = inst.get("liquidity", {}).get("sweeps", [])
            active_obs = smc.get("active_obs", [])

            candles = get_ohlc(symbol, interval, 60)
            from .indicators import ema
            closes = [c["close"] for c in candles]
            e9  = ema(closes, 9)
            e21 = ema(closes, 21)
            e9l  = next((x for x in reversed(e9)  if x is not None), None)
            e21l = next((x for x in reversed(e21) if x is not None), None)
            ema_cross_up   = (e9l and e21l and len(e9)>1 and len(e21)>1 and
                               e9[-2] is not None and e21[-2] is not None and
                               e9[-2]<e21[-2] and e9l>e21l)
            ema_cross_down = (e9l and e21l and len(e9)>1 and len(e21)>1 and
                               e9[-2] is not None and e21[-2] is not None and
                               e9[-2]>e21[-2] and e9l<e21l)

            direction  = sc.get("direction","NEUTRAL")
            confidence = sc.get("confidence", 0)

            cards.append({
                "symbol":    symbol, "price": last, "change24h": change,
                "direction": direction,
                "scenario_type": sc.get("type") or direction,
                "confidence": confidence,
                "setup":     sc.get("setup","NONE"),
                "trap":      sc.get("trap","NONE"),
                "session":   inst.get("session"),
                "rsi":       rsi_last,
                "rsi_signal":("OS" if rsi_last and rsi_last<35 else
                               "OB" if rsi_last and rsi_last>65 else None),
                "ema_cross_up":   ema_cross_up,
                "ema_cross_down": ema_cross_down,
                "ema_bullish":    e9l and e21l and e9l>e21l,
                "has_fvg":   len(fvg_list)>0,
                "has_ob":    len(active_obs)>0,
                "has_sweep": len(sweeps)>0,
                "bos":       any(e.get("type")=="BOS"   for e in smc.get("events",[])),
                "choch":     any(e.get("type")=="CHoCH" for e in smc.get("events",[])),
                "elliott":   (inst.get("elliott") or {}).get("type","NONE"),
                "mtf_bias":  mtf.get("bias","NEUTRAL"),
                "mtf_aligned":mtf.get("bias")==direction,
                "flow_bias":          of.get("flow") or of.get("bias") or "NEUTRAL",
                "buy_pressure":        of.get("buy_pressure"),
                "sell_pressure":       of.get("sell_pressure"),
                "large_bias":          of.get("large_bias","NEUTRAL"),
                "cluster_bias":        of.get("cluster_bias","NEUTRAL"),
                "institutional_score": of.get("institutional_score",0),
                "large_delta":         of.get("large_delta",0),
                "absorption":          of.get("absorption"),
                "iceberg_risk":        of.get("iceberg_risk"),
                "spoof_risk":          of.get("spoof_risk"),
                "tape_delta":          of.get("tape_delta"),
                "weighted_delta":      of.get("weighted_delta"),
                "extreme_trades":      of.get("extreme_trades"),
                "cluster_count":       of.get("cluster_count"),
                "quality_of":          of.get("quality"),
                "pd_zone":   smc.get("premium_discount",{}).get("zone"),
                "rr1":       risk.get("rr1"),
                "quality":   risk.get("quality",{}).get("grade"),
                "confluence_score": confluence.get("score"),
                "confluence_grade": confluence.get("grade"),
                "confluence_action": confluence.get("action"),
                "market_phase": phase.get("phase"),
                "phase_strength": phase.get("strength"),
                "phase_bias": phase.get("bias"),
                "pro_action": pro.get("action"),
                "pro_score": pro.get("score"),
                "pro_permission": pro.get("permission"),
                "pro_risk_label": pro.get("risk_label"),
                "decision_v3_action": dv3.get("action"),
                "decision_v3_probability": dv3.get("probability"),
                "decision_v3_ev": dv3.get("ev"),
                "decision_v3_grade": dv3.get("grade"),
                "pattern_primary": (patterns.get("primary") or {}).get("type"),
                "pattern_bias": patterns.get("bias"),
                "pattern_strength": (patterns.get("primary") or {}).get("strength"),
                "smart_zone_context": zones.get("context"),
                "smart_zone_strength": (zones.get("primary") or {}).get("strength"),
                "smart_zone_adjustment": zones.get("adjustment"),
                "ev":        risk.get("ev"),
                "decision_status": dec.get("status","OK"),
                "blockers":  dec.get("blockers",[]),
                # ── Early signal ──────────────────────────────────
                "early_mode":  early.get("mode",""),
                "early_grade": early.get("early_grade",""),
                "early_score": early.get("score", 0),
                "reasons":   (sc.get("reasons") or [])[:4],
            })
        except Exception as e:
            print(f"[dashboard] {symbol}: {type(e).__name__}: {e}")
            cards.append({"symbol":symbol,"price":last,"change24h":change,
                           "direction":"NEUTRAL","scenario_type":"NO_TRADE",
                           "confidence":0,"setup":"ERROR","trap":"NONE",
                           "early_mode":"","early_grade":"","early_score":0,
                           "reasons":[str(e)]})

    cards.sort(key=lambda x: float(x.get("confidence",0)), reverse=True)
    return cards

def _mock_ohlc(symbol, limit):
    base = 78000 if "BTC" in symbol else 3000 if "ETH" in symbol else 100
    candles=[]; t=int(time.time())-limit*3600; price=base
    for _ in range(limit):
        o=price; h=o*(1+random.uniform(0,.01)); l=o*(1-random.uniform(0,.01))
        c=random.uniform(l,h)
        candles.append({"time":t*1000,"open":o,"high":h,"low":l,"close":c,"volume":random.uniform(100,10000)})
        price=c; t+=3600
    return candles

def _mock_tickers(limit):
    out=[]
    for s in DEFAULT_SYMBOLS[:limit]:
        base=78000 if s=="BTCUSDT" else 3000 if s=="ETHUSDT" else random.uniform(0.05,250)
        out.append({"symbol":s,"lastPrice":str(base*(1+random.uniform(-.01,.01))),
                    "price24hPcnt":str(random.uniform(-.04,.04)),"turnover24h":str(random.uniform(1e6,1e9))})
    return out
