
import json, os, time

TRADES_FILE = os.path.join("logs","trades.jsonl")
os.makedirs("logs", exist_ok=True)

open_positions = {}

def open_trade(symbol, decision):
    open_positions[symbol] = {
        "entry": decision.get("entry"),
        "tp": decision.get("tp"),
        "sl": decision.get("sl"),
        "direction": decision.get("direction"),
        "ts": time.time()
    }

def update_price(symbol, price):
    if symbol not in open_positions:
        return None

    pos = open_positions[symbol]

    hit_tp = price >= pos["tp"] if pos["direction"]=="LONG" else price <= pos["tp"]
    hit_sl = price <= pos["sl"] if pos["direction"]=="LONG" else price >= pos["sl"]

    if hit_tp or hit_sl:
        pnl = (price - pos["entry"]) / pos["entry"]
        if pos["direction"]=="SHORT":
            pnl = -pnl

        trade = {
            "symbol": symbol,
            "entry": pos["entry"],
            "exit": price,
            "pnl": pnl,
            "result": 1 if pnl > 0 else 0,
            "ts": time.time()
        }

        with open(TRADES_FILE,"a") as f:
            f.write(json.dumps(trade)+"\n")

        del open_positions[symbol]
        return trade

    return None
