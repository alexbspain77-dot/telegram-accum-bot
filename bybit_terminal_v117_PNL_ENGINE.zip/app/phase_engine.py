from __future__ import annotations
from typing import Any, Dict, List
import math

def _f(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d

def _sma(vals, n):
    if not vals:
        return 0.0
    vals = vals[-n:]
    return sum(vals) / max(1, len(vals))

def _obv(candles: List[Dict[str, Any]]) -> List[float]:
    out = [0.0]
    for i in range(1, len(candles)):
        close = _f(candles[i].get("close"))
        prev = _f(candles[i-1].get("close"))
        vol = _f(candles[i].get("volume"))
        if close > prev:
            out.append(out[-1] + vol)
        elif close < prev:
            out.append(out[-1] - vol)
        else:
            out.append(out[-1])
    return out

def _ad_line(candles: List[Dict[str, Any]]) -> List[float]:
    out = []
    total = 0.0
    for c in candles:
        h, l, close, vol = _f(c.get("high")), _f(c.get("low")), _f(c.get("close")), _f(c.get("volume"))
        rng = max(h - l, 1e-12)
        clv = ((close - l) - (h - close)) / rng
        total += clv * vol
        out.append(total)
    return out

def _cmf(candles: List[Dict[str, Any]], n: int = 20) -> float:
    part = candles[-n:]
    mfv = 0.0
    vol_sum = 0.0
    for c in part:
        h, l, close, vol = _f(c.get("high")), _f(c.get("low")), _f(c.get("close")), _f(c.get("volume"))
        rng = max(h - l, 1e-12)
        clv = ((close - l) - (h - close)) / rng
        mfv += clv * vol
        vol_sum += vol
    return mfv / max(vol_sum, 1e-12)

def _slope(vals: List[float], n: int = 20) -> float:
    vals = vals[-n:]
    if len(vals) < 2:
        return 0.0
    return (vals[-1] - vals[0]) / max(abs(vals[0]), 1.0)

def _price_slope(candles: List[Dict[str, Any]], n: int = 20) -> float:
    part = candles[-n:]
    if len(part) < 2:
        return 0.0
    a, b = _f(part[0].get("close")), _f(part[-1].get("close"))
    return (b - a) / max(abs(a), 1e-12)

def _range_compression(candles: List[Dict[str, Any]], n: int = 20) -> float:
    part = candles[-n:]
    if len(part) < 2:
        return 0.0
    highs = [_f(c.get("high")) for c in part]
    lows = [_f(c.get("low")) for c in part]
    close = _f(part[-1].get("close"))
    rng_pct = (max(highs) - min(lows)) / max(close, 1e-12) * 100
    # high score when range is compressed
    return max(0.0, min(100.0, 100.0 - rng_pct * 22.0))

def _volume_spike_absorption(candles: List[Dict[str, Any]], n: int = 20) -> Dict[str, Any]:
    if len(candles) < n + 2:
        return {"score": 0, "side": "NONE"}
    last = candles[-1]
    vols = [_f(c.get("volume")) for c in candles[-n-1:-1]]
    avg_vol = _sma(vols, n)
    vol = _f(last.get("volume"))
    h, l, o, c = _f(last.get("high")), _f(last.get("low")), _f(last.get("open")), _f(last.get("close"))
    rng = max(h - l, 1e-12)
    body = abs(c - o)
    compression = 1.0 - min(1.0, body / rng)
    vol_ratio = vol / max(avg_vol, 1e-12)
    score = max(0, min(100, (vol_ratio - 1.0) * 35 + compression * 45))
    # wick logic
    lower_wick = min(o, c) - l
    upper_wick = h - max(o, c)
    if lower_wick > upper_wick * 1.25:
        side = "ACCUMULATION"
    elif upper_wick > lower_wick * 1.25:
        side = "DISTRIBUTION"
    else:
        side = "NEUTRAL"
    return {"score": int(score), "side": side, "vol_ratio": round(vol_ratio, 2), "compression": round(compression, 2)}

def _delta_proxy(candles: List[Dict[str, Any]], n: int = 20) -> float:
    vals = []
    for c in candles[-n:]:
        h, l, o, close, vol = _f(c.get("high")), _f(c.get("low")), _f(c.get("open")), _f(c.get("close")), _f(c.get("volume"))
        rng = max(h - l, 1e-12)
        vals.append(vol * ((close - o) / rng))
    return sum(vals)

def _volume_profile_phase(candles: List[Dict[str, Any]], bins: int = 24, n: int = 120) -> Dict[str, Any]:
    part = candles[-n:]
    if len(part) < 20:
        return {"shape": "UNKNOWN", "score": 0, "hvn": None}
    highs = [_f(c.get("high")) for c in part]
    lows = [_f(c.get("low")) for c in part]
    lo, hi = min(lows), max(highs)
    if hi <= lo:
        return {"shape": "UNKNOWN", "score": 0, "hvn": None}
    step = (hi - lo) / bins
    buckets = [0.0 for _ in range(bins)]
    for c in part:
        price = (_f(c.get("high")) + _f(c.get("low")) + _f(c.get("close"))) / 3.0
        idx = int((price - lo) / step)
        idx = max(0, min(bins - 1, idx))
        buckets[idx] += _f(c.get("volume"))
    max_i = max(range(bins), key=lambda i: buckets[i])
    hvn = lo + step * (max_i + 0.5)
    pos = (hvn - lo) / max(hi - lo, 1e-12)
    # b-profile: HVN low part = accumulation; P-profile: HVN high part = distribution
    if pos < 0.42:
        return {"shape": "B_PROFILE_ACCUMULATION", "score": int((0.42 - pos) / 0.42 * 100), "hvn": hvn}
    if pos > 0.58:
        return {"shape": "P_PROFILE_DISTRIBUTION", "score": int((pos - 0.58) / 0.42 * 100), "hvn": hvn}
    return {"shape": "BALANCED", "score": 25, "hvn": hvn}

def detect_phase(candles: List[Dict[str, Any]], orderflow: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Detect accumulation / distribution / neutral phase. Fail-safe."""
    try:
        orderflow = orderflow or {}
        if not candles or len(candles) < 40:
            return {"phase": "UNKNOWN", "strength": 0, "bias": "NEUTRAL", "signals": ["not enough candles"]}

        closes = [_f(c.get("close")) for c in candles]
        obv = _obv(candles)
        ad = _ad_line(candles)
        cmf = _cmf(candles, 20)
        price_sl = _price_slope(candles, 24)
        obv_sl = _slope(obv, 24)
        ad_sl = _slope(ad, 24)
        delta = _delta_proxy(candles, 24)
        abs_vol = _volume_spike_absorption(candles, 24)
        vp = _volume_profile_phase(candles, 24, 120)
        compression = _range_compression(candles, 24)

        acc = 0
        dist = 0
        signals = []

        # OBV / A-D divergence
        if price_sl < -0.003 and obv_sl > 0.02:
            acc += 22; signals.append("OBV bullish divergence")
        if price_sl > 0.003 and obv_sl < -0.02:
            dist += 22; signals.append("OBV bearish divergence")

        if price_sl < -0.003 and ad_sl > 0.02:
            acc += 18; signals.append("A/D accumulation divergence")
        if price_sl > 0.003 and ad_sl < -0.02:
            dist += 18; signals.append("A/D distribution divergence")

        # CMF
        if cmf > 0.08:
            acc += 14; signals.append(f"CMF positive {round(cmf, 2)}")
        elif cmf < -0.08:
            dist += 14; signals.append(f"CMF negative {round(cmf, 2)}")

        # Delta absorption proxy
        if price_sl <= 0 and delta > 0:
            acc += 16; signals.append("positive delta while price weak/flat")
        if price_sl >= 0 and delta < 0:
            dist += 16; signals.append("negative delta while price strong/flat")

        # Volume spike with small body / wick absorption
        if abs_vol["score"] >= 55:
            if abs_vol["side"] == "ACCUMULATION":
                acc += 16; signals.append(f"sell pressure absorbed vol x{abs_vol.get('vol_ratio')}")
            elif abs_vol["side"] == "DISTRIBUTION":
                dist += 16; signals.append(f"buy pressure absorbed vol x{abs_vol.get('vol_ratio')}")
            else:
                acc += 5; dist += 5; signals.append("high volume without progress")

        # Volume profile
        if vp["shape"] == "B_PROFILE_ACCUMULATION":
            acc += min(16, int(vp["score"] * 0.25)); signals.append("b-profile volume accumulation")
        elif vp["shape"] == "P_PROFILE_DISTRIBUTION":
            dist += min(16, int(vp["score"] * 0.25)); signals.append("P-profile volume distribution")

        # Orderflow hints
        flow = orderflow.get("flow") or orderflow.get("bias") or "NEUTRAL"
        absorption = orderflow.get("absorption") or "NONE"
        if absorption == "SELL_ABSORBED":
            acc += 16; signals.append("orderflow SELL_ABSORBED")
        elif absorption == "BUY_ABSORBED":
            dist += 16; signals.append("orderflow BUY_ABSORBED")
        if flow == "LONG" and price_sl <= 0.001:
            acc += 8; signals.append("flow LONG during flat/weak price")
        elif flow == "SHORT" and price_sl >= -0.001:
            dist += 8; signals.append("flow SHORT during flat/strong price")

        # Cause building: compressed range boosts stronger side
        if compression >= 55:
            if acc > dist:
                acc += 8; signals.append("range compression / cause building")
            elif dist > acc:
                dist += 8; signals.append("range compression / cause building")

        acc = max(0, min(100, int(acc)))
        dist = max(0, min(100, int(dist)))

        if acc >= dist + 12 and acc >= 35:
            phase = "ACCUMULATION"
            strength = acc
            bias = "LONG"
        elif dist >= acc + 12 and dist >= 35:
            phase = "DISTRIBUTION"
            strength = dist
            bias = "SHORT"
        elif max(acc, dist) >= 45:
            phase = "MIXED_ABSORPTION"
            strength = max(acc, dist)
            bias = "NEUTRAL"
        else:
            phase = "NEUTRAL"
            strength = max(acc, dist)
            bias = "NEUTRAL"

        return {
            "phase": phase,
            "strength": strength,
            "bias": bias,
            "accumulation_score": acc,
            "distribution_score": dist,
            "cmf": round(cmf, 4),
            "obv_slope": round(obv_sl, 4),
            "ad_slope": round(ad_sl, 4),
            "price_slope": round(price_sl, 4),
            "delta_proxy": round(delta, 2),
            "volume_profile": vp,
            "absorption_volume": abs_vol,
            "signals": signals[:10],
        }
    except Exception as e:
        return {"phase": "ERROR", "strength": 0, "bias": "NEUTRAL", "signals": [str(e)]}

def phase_decision_adjustment(phase: Dict[str, Any], direction: str) -> Dict[str, Any]:
    direction = direction or "NEUTRAL"
    p = (phase or {}).get("phase", "NEUTRAL")
    strength = int((phase or {}).get("strength", 0) or 0)
    adj = 0
    reasons = []
    blockers = []

    if p == "ACCUMULATION":
        if direction == "LONG":
            adj += 8 if strength < 65 else 14
            reasons.append(f"Phase supports LONG: accumulation {strength}")
        elif direction == "SHORT":
            adj -= 12
            reasons.append(f"Phase conflicts SHORT: accumulation {strength}")
            if strength >= 70:
                blockers.append("strong accumulation against SHORT")
    elif p == "DISTRIBUTION":
        if direction == "SHORT":
            adj += 8 if strength < 65 else 14
            reasons.append(f"Phase supports SHORT: distribution {strength}")
        elif direction == "LONG":
            adj -= 12
            reasons.append(f"Phase conflicts LONG: distribution {strength}")
            if strength >= 70:
                blockers.append("strong distribution against LONG")
    elif p == "MIXED_ABSORPTION":
        adj -= 4
        reasons.append("Mixed absorption phase: reduce confidence")

    return {"score_adjustment": adj, "reasons": reasons, "blockers": blockers}
