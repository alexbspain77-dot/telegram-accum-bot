from flask import Flask, render_template, request, jsonify, redirect
from .data_feed import get_dashboard, get_ohlc, normalize_symbol
from .indicators import ema, rsi, to_line
from .institutional import institutional_report
from .market_data import get_global_market
from .news_engine import build_news
from .account_manager import register_user, login_user, logout_user, get_profile, save_watchlist, save_telegram, all_users
from .telegram_signal_service import maybe_send_signal, send_message, send_signal_to_matching_users

VALID_TF = ["1","5","15","60","240"]
def _tf(t): return t if str(t) in VALID_TF else "60"


def _norm_chart_fvg(inst, candles):
    zones = inst.get("fvg_zones") or []
    out = []
    if not candles:
        return out
    last_time = int(candles[-1]["time"])
    tf_sec = 60
    if len(candles) >= 2:
        try:
            tf_sec = max(60, int((int(candles[-1]["time"]) - int(candles[-2]["time"])) / 1000))
        except Exception:
            tf_sec = 60
    for z in zones[-10:]:
        try:
            t = int(z.get("time") or last_time)
            if t > 1e12: t = int(t / 1000)
            else: t = int(t / 1000) if t > 1e10 else t
            out.append({
                "type": "bullish" if "BULL" in str(z.get("type","")).upper() else "bearish",
                "raw_type": z.get("type"),
                "low": float(z.get("low")),
                "high": float(z.get("high")),
                "mid": float(z.get("mid", (float(z.get("low"))+float(z.get("high")))/2)),
                "start": t,
                "end": int(last_time/1000) + tf_sec * 25 if last_time > 1e10 else last_time + tf_sec * 25,
                "mitigated": bool(z.get("mitigated")),
            })
        except Exception:
            pass
    return out

def _norm_chart_bos(inst):
    events = ((inst.get("smc") or {}).get("events") or [])
    out = []
    for e in events[-12:]:
        if e.get("type") != "BOS":
            continue
        try:
            out.append({
                "type": "bullish" if e.get("direction") == "LONG" else "bearish",
                "direction": e.get("direction"),
                "level": float(e.get("level")),
                "time": int(e.get("time") or 0),
                "idx": e.get("idx"),
            })
        except Exception:
            pass
    return out

def create_app():
    app = Flask(__name__, template_folder="../templates", static_folder="../static")

    def _auth_token():
        return request.headers.get("X-Auth-Token") or request.cookies.get("bt_token") or request.args.get("token","")



    # ── Unified UI Router ─────────────────────────────────────────
    @app.route("/ui")
    def ui_router():
        view = request.args.get("view", "dashboard")
        symbol = normalize_symbol(request.args.get("symbol", "BTCUSDT"))
        tf = _tf(request.args.get("tf", "15"))
        if view == "chart":
            return render_template("chart_window.html", symbol=symbol, tf=tf)
        if view == "workspace":
            return render_template("workspace.html", symbol=symbol, tf=tf)
        if view == "journal":
            return render_template("journal.html")
        if view == "news":
            return render_template("dashboard.html", tf=tf)
        return render_template("dashboard.html", tf=tf)

    @app.route("/window/<symbol>")
    def window_redirect(symbol):
        return redirect(f"/ui?view=chart&symbol={normalize_symbol(symbol)}&tf={_tf(request.args.get('tf','15'))}")

    @app.route("/workspace")
    def workspace(): return render_template("workspace.html", symbol=normalize_symbol(request.args.get("symbol","BTCUSDT")), tf=_tf(request.args.get("tf","15")))

    @app.route("/")
    def dashboard(): return render_template("dashboard.html", tf=_tf(request.args.get("tf","60")))


    @app.route("/chart")
    def chart_window():
        symbol = normalize_symbol(request.args.get("symbol", "BTCUSDT"))
        return render_template("chart_window.html", symbol=symbol, tf=_tf(request.args.get("tf","15")))

    @app.route("/chart/<symbol>")
    def chart(symbol): return redirect(f"/ui?view=chart&symbol={normalize_symbol(symbol)}&tf={_tf(request.args.get('tf','15'))}")

    @app.route("/journal")
    def journal(): return render_template("journal.html")


    # ── Accounts / Cloud Watchlist / Telegram ─────────────────────
    @app.route("/api/account/register", methods=["POST"])
    def api_account_register():
        js = request.get_json(silent=True) or {}
        res = register_user(js.get("username",""), js.get("password",""), js.get("telegram_chat_id",""), js.get("telegram_enabled", False))
        resp = jsonify(res)
        if res.get("ok"):
            resp.set_cookie("bt_token", res.get("token",""), max_age=60*60*24*365, samesite="Lax")
        return resp

    @app.route("/api/account/login", methods=["POST"])
    def api_account_login():
        js = request.get_json(silent=True) or {}
        res = login_user(js.get("username",""), js.get("password",""))
        resp = jsonify(res)
        if res.get("ok"):
            resp.set_cookie("bt_token", res.get("token",""), max_age=60*60*24*365, samesite="Lax")
        return resp

    @app.route("/api/account/logout", methods=["POST"])
    def api_account_logout():
        res = logout_user(_auth_token())
        resp = jsonify(res)
        resp.delete_cookie("bt_token")
        return resp

    @app.route("/api/account/me")
    def api_account_me():
        return jsonify(get_profile(_auth_token()))

    @app.route("/api/watchlist", methods=["GET", "POST"])
    def api_watchlist():
        token = _auth_token()
        if request.method == "GET":
            prof = get_profile(token)
            return jsonify(prof if prof.get("ok") else {"ok": False, "error": prof.get("error"), "watchlist": []})
        js = request.get_json(silent=True) or {}
        return jsonify(save_watchlist(token, js.get("watchlist") or js.get("symbols") or []))

    @app.route("/api/telegram/settings", methods=["POST"])
    def api_telegram_settings():
        js = request.get_json(silent=True) or {}
        return jsonify(save_telegram(
            _auth_token(),
            js.get("chat_id",""),
            js.get("enabled", False),
            js.get("min_confidence",65),
            js.get("only_pro_trade", True),
        ))

    @app.route("/api/telegram/test", methods=["POST"])
    def api_telegram_test():
        prof = get_profile(_auth_token())
        if not prof.get("ok"):
            return jsonify({"ok": False, "error": "not authenticated"})
        chat_id = (prof.get("telegram") or {}).get("chat_id")
        if not chat_id:
            return jsonify({"ok": False, "error": "telegram chat id is empty"})
        return jsonify(send_message(chat_id, "✅ Bybit Terminal: тестовое сообщение. Telegram подключен."))

    @app.route("/api/telegram/send_signal", methods=["POST"])
    def api_telegram_send_signal():
        js = request.get_json(silent=True) or {}
        symbol = normalize_symbol(js.get("symbol","BTCUSDT"))
        signal = js.get("signal") or {}
        signal["symbol"] = symbol
        prof = get_profile(_auth_token())
        if not prof.get("ok"):
            return jsonify({"ok": False, "error": "not authenticated"})
        user = all_users().get(prof.get("username"), {})
        return jsonify(maybe_send_signal(prof.get("username"), user, signal))

    @app.route("/api/v7/signals")
    @app.route("/api/signals")
    def api_signals():
        tf    = _tf(request.args.get("tf","60"))
        q     = request.args.get("q","")
        limit = int(request.args.get("limit","30"))
        data  = get_dashboard(q, limit=limit, interval=tf)
        # Telegram signal delivery for logged-in user. Anti-spam is handled in telegram_signal_service.
        try:
            prof = get_profile(_auth_token())
            if prof.get("ok"):
                user = all_users().get(prof.get("username"), {})
                for sig in data:
                    maybe_send_signal(prof.get("username"), user, sig)
        except Exception:
            pass
        return jsonify({"ok":True,"engine":"v8.6","tf":tf,"count":len(data),"signals":data})

    @app.route("/api/v7/chart/<symbol>")
    @app.route("/api/chart/<symbol>")
    def api_chart(symbol):
        tf      = _tf(request.args.get("tf","60"))
        symbol  = normalize_symbol(symbol)
        candles = get_ohlc(symbol, tf, 300)
        closes  = [c["close"] for c in candles]
        volumes = [{"time":c["time"],"value":c.get("volume",0),
                    "color":"rgba(38,166,154,0.45)" if c["close"]>=c["open"] else "rgba(239,83,80,0.45)"}
                   for c in candles]
        inst = institutional_report(symbol, tf)
        risk = inst.get("risk",{})
        return jsonify({
            "ok":True,"symbol":symbol,"tf":tf,
            "candles":candles,"volume":volumes,
            "ema9":  to_line(candles,ema(closes,9)),
            "ema21": to_line(candles,ema(closes,21)),
            "ema55": to_line(candles,ema(closes,55)),
            "rsi":   to_line(candles,rsi(closes,14)),
            "institutional":inst,"scenario":inst.get("scenario",{}),
            "levels":       inst.get("levels",[]),
            "fvg_zones":    inst.get("fvg_zones",[]),
            "session_bands":inst.get("session_bands",[]),
            "markers":      inst.get("markers",[]),
            "risk":risk,
            "entry":risk.get("entry"),"stop":risk.get("stop"),
            "tp1": risk.get("tp1"), "tp2":risk.get("tp2"),
            "elliott":        inst.get("elliott"),
            "elliott_points": inst.get("elliott_points",[]),
            "rsi_last":  inst.get("rsi"),
            "session":   inst.get("session"),
            "early_signal": inst.get("early_signal",{}),
            "fvg": _norm_chart_fvg(inst, candles),
            "bos": _norm_chart_bos(inst),
            "confluence": inst.get("confluence",{}),
            "phase": inst.get("phase",{}),
            "pro_trader": inst.get("pro_trader",{}),
            "decision_v3": inst.get("decision_v3",{}),
            "patterns": inst.get("patterns",{}),
            "smart_zones": inst.get("smart_zones",{}),
        })

    @app.route("/api/v7/institutional/<symbol>")
    @app.route("/api/institutional/<symbol>")
    def api_institutional(symbol):
        return jsonify(institutional_report(normalize_symbol(symbol), _tf(request.args.get("tf","60"))))

    # ── Heatmap — только сильные сигналы ──────────────────────────
    @app.route("/api/v7/heatmap")
    def api_heatmap():
        tf       = _tf(request.args.get("tf","15"))
        min_conf = int(request.args.get("min_confidence","55"))
        try:
            from .event_engine import HEAT
            # Если event_engine уже прогрелся — используем HEAT
            if len(HEAT) >= 3:
                data = HEAT
                source = "heat"
            else:
                from .market_scanner import get_heatmap_signals
                data = get_heatmap_signals(tf=tf)
                source = "scan"

            # Telegram delivery for heatmap signals.
            # Sends only signals passing each user's Telegram filters and only symbols from user's watchlist.
            try:
                users = all_users()
                for sig in (data or [])[:20]:
                    if int(float(sig.get("confidence") or 0)) >= min_conf:
                        send_signal_to_matching_users(users, sig)
            except Exception as tg_e:
                print("[telegram heatmap]", tg_e)

            return jsonify({"ok":True,"engine":"event" if source=="heat" else "scanner","source":source,
                            "count":len(data),"signals":data})
        except Exception as e:
            return jsonify({"ok":False,"signals":[],"error":str(e)})


    @app.route("/api/v7/news")
    @app.route("/api/news")
    def api_news():
        try:
            return jsonify(build_news())
        except Exception as e:
            return jsonify({"ok": False, "risk": 0, "risk_label": "LOW", "macro": [], "crypto": [], "error": str(e)})

    @app.route("/api/global")
    @app.route("/api/v7/global")
    def api_global():
        return jsonify(get_global_market())

    # ── Journal ────────────────────────────────────────────────────
    @app.route("/api/journal/stats")
    def api_journal_stats():
        try:
            from .trade_journal import stats as tj_stats
            st = tj_stats()
        except Exception as e:
            st = {"total":0,"open":0,"closed":0,"wins":0,"losses":0,"winrate":0,"pnl_usd":0}
            print("[journal/stats]", e)
        try:
            from .learning_engine import get_learning
            learn = get_learning()
        except Exception as e:
            learn = {"trade_count":0,"insights":[],"error":str(e)}
        return jsonify({"stats":st,"learning":learn})

    @app.route("/api/journal/trades")
    def api_journal_trades():
        try:
            from .trade_journal import _load
            trades = _load()
            return jsonify({"ok":True,"trades":trades,"count":len(trades)})
        except Exception as e:
            return jsonify({"ok":False,"trades":[],"error":str(e)})

    @app.route("/api/journal/open", methods=["POST"])
    def api_journal_open():
        try:
            from .trade_journal import open_trade
            payload  = request.get_json(force=True) or {}
            symbol   = normalize_symbol(payload.get("symbol","BTCUSDT"))
            payload["symbol"] = symbol
            snapshot = institutional_report(symbol, _tf(payload.get("tf","60")))
            trade    = open_trade(payload, snapshot)
            return jsonify({"ok":True,"trade":trade})
        except Exception as e:
            print("[journal/open]", e)
            return jsonify({"ok":False,"error":str(e)})

    @app.route("/api/journal/close/<trade_id>", methods=["POST"])
    def api_journal_close(trade_id):
        try:
            from .trade_journal import close_trade
            payload = request.get_json(force=True) or {}
            trade   = close_trade(trade_id, payload)
            return jsonify({"ok":True,"trade":trade})
        except Exception as e:
            print("[journal/close]", e)
            return jsonify({"ok":False,"error":str(e)})


    # ── V7 Journal aliases used by chart UI ───────────────────────
    @app.route("/api/v7/trades", methods=["GET"])
    def api_v7_trades():
        try:
            from .trade_journal import list_trades
            symbol = request.args.get("symbol")
            status = request.args.get("status")
            limit = int(request.args.get("limit", "200"))
            return jsonify({"ok": True, "items": list_trades(symbol=symbol, status=status, limit=limit)})
        except Exception as e:
            print("[api/v7/trades]", e)
            return jsonify({"ok": False, "items": [], "error": str(e)})

    @app.route("/api/v7/trades/open", methods=["POST"])
    def api_v7_trades_open():
        try:
            from .trade_journal import open_trade
            payload = request.get_json(force=True) or {}
            symbol = normalize_symbol(payload.get("symbol", "BTCUSDT"))
            payload["symbol"] = symbol
            snapshot = payload.get("scenario_snapshot") or institutional_report(symbol, _tf(payload.get("tf", "60")))
            trade = open_trade(payload, snapshot)
            return jsonify({"ok": True, "trade": trade})
        except Exception as e:
            print("[api/v7/trades/open]", e)
            return jsonify({"ok": False, "error": str(e)})

    @app.route("/api/v7/trades/<trade_id>/close", methods=["POST"])
    def api_v7_trades_close(trade_id):
        try:
            from .trade_journal import close_trade
            payload = request.get_json(force=True) or {}
            trade = close_trade(trade_id, payload)
            return jsonify({"ok": True, "trade": trade})
        except Exception as e:
            print("[api/v7/trades/close]", e)
            return jsonify({"ok": False, "error": str(e)})

    @app.route("/api/v7/learning")
    def api_v7_learning():
        try:
            from .learning_engine import get_learning
            return jsonify({"ok": True, "learning": get_learning()})
        except Exception as e:
            return jsonify({"ok": False, "learning": {"trade_count": 0, "insights": []}, "error": str(e)})

    # ── Telegram ───────────────────────────────────────────────────
    @app.route("/api/telegram/test", methods=["POST"])
    def tg_test():
        try:
            from .telegram import send_raw
            ok = send_raw("🧪 <b>Тест Bybit Terminal v8.6</b>\nСоединение работает ✅")
            return jsonify({"ok":ok})
        except Exception as e:
            return jsonify({"ok":False,"message":str(e)})

    @app.route("/api/telegram/notify/<symbol>", methods=["POST"])
    def tg_notify(symbol):
        try:
            from .telegram import format_signal, send_raw
            report = institutional_report(normalize_symbol(symbol))
            ok = send_raw(format_signal(normalize_symbol(symbol), report))
            return jsonify({"ok":ok})
        except Exception as e:
            return jsonify({"ok":False,"message":str(e)})

    from .event_engine import start
    start()
    
    @app.route("/api/stats")
    def stats():
        return compute_stats()

    
    @app.route("/api/pnl")
    def pnl():
        return pnl_stats()

    return app




import json, os

def compute_stats():
    path = os.path.join("logs","performance.jsonl")
    if not os.path.exists(path):
        return {"trades":0,"winrate":0,"avg_ev":0}

    total = 0
    wins = 0

    with open(path) as f:
        for line in f:
            row = json.loads(line)
            total += 1
            if row.get("result") and row["result"].get("pnl",0) > 0:
                wins += 1

    return {
        "trades": total,
        "winrate": (wins/total if total else 0)
    }

import json, os

def pnl_stats():
    path=os.path.join("logs","trades.jsonl")
    if not os.path.exists(path):
        return {"trades":0,"pnl":0}

    total=0
    pnl_sum=0

    with open(path) as f:
        for line in f:
            t=json.loads(line)
            total+=1
            pnl_sum+=t.get("pnl",0)

    return {"trades":total,"total_pnl":pnl_sum}

