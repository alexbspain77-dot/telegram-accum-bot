from __future__ import annotations
from typing import Any, Dict, List

def _f(v, d=0.0):
    try: return float(v)
    except Exception: return d

def _atr(candles: List[Dict[str, Any]], n: int = 14) -> float:
    if not candles or len(candles) < 2: return 0.0
    part = candles[-(n+1):]
    trs=[]
    for i,c in enumerate(part):
        h,l=_f(c.get("high")),_f(c.get("low"))
        if i==0:
            trs.append(h-l)
        else:
            pc=_f(part[i-1].get("close"))
            trs.append(max(h-l, abs(h-pc), abs(l-pc)))
    return sum(trs)/max(1,len(trs))

def _vol_avg(candles, n=30):
    vols=[_f(c.get("volume")) for c in candles[-n:]]
    return sum(vols)/max(1,len(vols))

def build_smart_zones(candles: List[Dict[str, Any]], sweeps=None, events=None, fvg=None, phase=None, patterns=None) -> Dict[str, Any]:
    """
    Smart Zone Engine v1.
    Converts visual red/yellow zones into actionable signal context:
    - DANGER_CHOP_ZONE: avoid midpoint / reduce confidence
    - MANIPULATION_ZONE: sweep cluster / trap area
    - BREAKOUT_ZONE: price escaped zone and should trade only with retest/flow
    """
    try:
        sweeps=sweeps or []
        events=events or []
        fvg=fvg or []
        phase=phase or {}
        patterns=patterns or {}
        if not candles or len(candles)<30:
            return {"ok":False,"zones":[],"context":"NO_DATA","adjustment":0,"blockers":[],"warnings":[],"reasons":[]}

        last=candles[-1]
        close=_f(last.get("close"))
        atr=_atr(candles,14) or close*0.005
        zones=[]

        # 1) Main recent chop/manipulation zone from last 60 bars
        part=candles[-60:]
        hi=max(_f(c.get("high")) for c in part)
        lo=min(_f(c.get("low")) for c in part)
        width_pct=(hi-lo)/max(close,1e-12)*100
        recent_sweeps=[s for s in sweeps if s.get("time",0) >= (part[0].get("time",0))]
        sweep_count=len(recent_sweeps)
        recent_bos=[e for e in events[-20:] if e.get("type") in ("BOS","CHoCH")]
        phase_name=phase.get("phase","NEUTRAL")
        primary=(patterns.get("primary") or {}) if isinstance(patterns,dict) else {}
        ptype=primary.get("type")

        inside = lo <= close <= hi
        zone_type="DANGER_CHOP_ZONE"
        strength=45
        if sweep_count>=3:
            zone_type="MANIPULATION_ZONE"; strength+=20
        if phase_name in ("ACCUMULATION","DISTRIBUTION","MIXED_ABSORPTION"):
            strength+=15
        if ptype in ("RANGE_BOX","COMPRESSION"):
            strength+=12
        if width_pct <= 8:
            strength+=8

        zones.append({
            "type":zone_type,
            "kind":"danger",
            "low":round(lo,8),
            "high":round(hi,8),
            "mid":round((lo+hi)/2,8),
            "start":int(part[0].get("time",0)),
            "end":int(last.get("time",0)) + 60*60*12,
            "strength":min(95,int(strength)),
            "inside":inside,
            "sweep_count":sweep_count,
            "width_pct":round(width_pct,3),
            "reason":"recent range with sweeps/phase/pattern context",
        })

        # 2) FVG zones as actionable re-entry zones
        for z in (fvg or [])[-6:]:
            try:
                low=_f(z.get("low")); high=_f(z.get("high"))
                if not low or not high: continue
                direction="LONG" if "BULL" in str(z.get("type","")).upper() or str(z.get("type","")).lower()=="bullish" else "SHORT"
                in_fvg = min(low,high) <= close <= max(low,high)
                zones.append({
                    "type":"FVG_RETEST_ZONE",
                    "kind":"opportunity",
                    "direction":direction,
                    "low":round(min(low,high),8),
                    "high":round(max(low,high),8),
                    "mid":round((low+high)/2,8),
                    "start":int(z.get("time") or last.get("time",0)),
                    "end":int(last.get("time",0)) + 60*60*8,
                    "strength":70 if in_fvg else 55,
                    "inside":in_fvg,
                    "reason":"fresh FVG retest area",
                })
            except Exception:
                pass

        # 3) Current context / signal effect
        warnings=[]; blockers=[]; reasons=[]; adjustment=0; context="NEUTRAL_ZONE"

        danger=zones[0]
        upper=danger["high"]; lower=danger["low"]; mid=danger["mid"]
        breakout_long = close > upper + atr*0.25
        breakout_short = close < lower - atr*0.25
        near_mid = abs(close-mid) <= atr*0.75

        if danger["inside"]:
            context="INSIDE_DANGER_ZONE"
            adjustment -= 18
            warnings.append("price inside danger/chop zone")
            if near_mid:
                adjustment -= 12
                blockers.append("price in zone midpoint")
            reasons.append("wait for clean breakout/retest")
        elif breakout_long:
            context="BREAKOUT_ABOVE_ZONE"
            adjustment += 10
            reasons.append("price broke above smart zone")
        elif breakout_short:
            context="BREAKDOWN_BELOW_ZONE"
            adjustment += 10
            reasons.append("price broke below smart zone")

        opp_inside=[z for z in zones[1:] if z.get("inside")]
        if opp_inside:
            z=opp_inside[0]
            context = "FVG_RETEST_ACTIVE"
            adjustment += 8
            reasons.append(f"active {z.get('direction')} FVG retest zone")

        return {
            "ok":True,
            "zones":zones[:10],
            "primary":zones[0],
            "context":context,
            "adjustment":adjustment,
            "blockers":blockers,
            "warnings":warnings,
            "reasons":reasons,
        }
    except Exception as e:
        return {"ok":False,"zones":[],"context":"ERROR","adjustment":0,"blockers":[str(e)],"warnings":[],"reasons":[]}

def zone_decision_adjustment(zone_report: Dict[str,Any], direction: str) -> Dict[str,Any]:
    direction=direction or "NEUTRAL"
    adj=int(zone_report.get("adjustment") or 0)
    blockers=list(zone_report.get("blockers") or [])
    warnings=list(zone_report.get("warnings") or [])
    reasons=list(zone_report.get("reasons") or [])
    ctx=zone_report.get("context")
    primary=zone_report.get("primary") or {}

    # Direction-specific breakout rules.
    if ctx=="BREAKOUT_ABOVE_ZONE":
        if direction=="LONG":
            adj += 8; reasons.append("zone breakout confirms LONG")
        elif direction=="SHORT":
            adj -= 15; blockers.append("short against zone breakout")
    elif ctx=="BREAKDOWN_BELOW_ZONE":
        if direction=="SHORT":
            adj += 8; reasons.append("zone breakdown confirms SHORT")
        elif direction=="LONG":
            adj -= 15; blockers.append("long against zone breakdown")
    elif ctx=="INSIDE_DANGER_ZONE":
        if primary.get("strength",0) >= 75:
            blockers.append("high strength danger zone")
    return {"score_adjustment":adj,"blockers":blockers,"warnings":warnings,"reasons":reasons}
