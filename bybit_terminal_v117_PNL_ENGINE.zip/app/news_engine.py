
from __future__ import annotations
import datetime, time, re
from typing import Any, Dict, List
try:
    import requests
except Exception:
    requests = None

_CACHE = {"ts": 0.0, "data": None}
TTL = 300

MACRO_WORDS = ["cpi","inflation","fomc","fed","powell","rate","nonfarm","payroll","jobs","unemployment","pce","gdp","ppi","retail","ism","jolts","treasury","yield"]
CRYPTO_WORDS = ["pump","breakout","etf","sec","blackrock","binance","coinbase","whale","liquidation","hack","exploit","airdrop","listing","delisting","lawsuit","solana","bitcoin","ethereum"]

def _get_json(url, params=None, timeout=7):
    if requests is None:
        return None
    try:
        r = requests.get(url, params=params or {}, timeout=timeout, headers={"User-Agent":"Mozilla/5.0 bybit-terminal-news"})
        if r.status_code >= 400:
            return None
        return r.json()
    except Exception:
        return None

def _score(title, words):
    t = (title or "").lower()
    return sum(1 for w in words if w in t)

def _impact(title, base=12, words=None):
    words = words or CRYPTO_WORDS
    return min(100, base + _score(title, words) * 12)

def get_macro_news() -> List[Dict[str, Any]]:
    out=[]
    data=_get_json("https://api.tradingeconomics.com/calendar", {"c":"guest:guest","importance":"2"})
    if isinstance(data, list):
        for e in data[:30]:
            title=e.get("Event") or e.get("Category") or "Macro event"
            country=e.get("Country") or ""
            if country and "united states" not in str(country).lower() and "fed" not in title.lower() and "fomc" not in title.lower():
                continue
            imp=e.get("Importance") or 2
            try: imp=int(float(imp))
            except Exception: imp=2
            score=min(100, 10 + imp*12 + _score(title, MACRO_WORDS)*10)
            out.append({
                "type":"macro","title":title,"source":"TradingEconomics",
                "time":e.get("Date") or "", "impact":score, "tag":"HIGH" if score>=45 else "MED",
                "url":"https://tradingeconomics.com/calendar"
            })
    if not out:
        out=[
            {"type":"macro","title":"US CPI / Inflation watch","source":"Macro watch","time":"","impact":45,"tag":"HIGH","url":"https://www.investing.com/economic-calendar/"},
            {"type":"macro","title":"FOMC / Fed rates risk window","source":"Macro watch","time":"","impact":45,"tag":"HIGH","url":"https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"},
            {"type":"macro","title":"US Jobs / NFP / Unemployment watch","source":"Macro watch","time":"","impact":34,"tag":"MED","url":"https://www.bls.gov/schedule/news_release/empsit.htm"},
        ]
    return out[:8]

def get_crypto_news() -> List[Dict[str, Any]]:
    out=[]
    # Source 1: CryptoCompare
    data=_get_json("https://min-api.cryptocompare.com/data/v2/news/", {"lang":"EN"})
    items=(data or {}).get("Data") if isinstance(data,dict) else None
    if items:
        for n in items[:20]:
            title=n.get("title") or ""
            if not title: continue
            score=_impact(title, 10, CRYPTO_WORDS)
            out.append({
                "type":"crypto","title":title,"source":n.get("source") or "CryptoCompare",
                "time":n.get("published_on") or "", "impact":score,
                "tag":"HIGH" if score>=40 else "MED" if score>=22 else "LOW",
                "url":n.get("url") or ""
            })
    # Source 2 fallback: CoinGecko status/news endpoint is not always available; keep curated useful links instead of error.
    if not out:
        out=[
            {"type":"crypto","title":"Crypto market news feed unavailable — open CoinDesk latest","source":"System fallback","time":"","impact":12,"tag":"LOW","url":"https://www.coindesk.com/"},
            {"type":"crypto","title":"Check Cointelegraph latest crypto headlines","source":"System fallback","time":"","impact":12,"tag":"LOW","url":"https://cointelegraph.com/"},
            {"type":"crypto","title":"Check CryptoPanic market news aggregator","source":"System fallback","time":"","impact":12,"tag":"LOW","url":"https://cryptopanic.com/"},
        ]
    return out[:12]

def build_news() -> Dict[str, Any]:
    now=time.time()
    if _CACHE["data"] and now-_CACHE["ts"]<TTL:
        return _CACHE["data"]
    macro=get_macro_news()
    crypto=get_crypto_news()
    max_macro=max([x.get("impact",0) for x in macro] or [0])
    max_crypto=max([x.get("impact",0) for x in crypto] or [0])
    risk=min(100, round(max_macro*0.55 + max_crypto*0.35 + min(len(crypto),8)*1.5, 1))
    label="HIGH" if risk>=65 else "MEDIUM" if risk>=35 else "LOW"
    data={
        "ok":True,
        "time":datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z",
        "risk":risk,"risk_label":label,
        "macro":macro,"crypto":crypto,
        "summary":{"headline":f"News risk {label}","note":"Новости используются как риск-контекст, а не как самостоятельный торговый сигнал."}
    }
    _CACHE["ts"]=now
    _CACHE["data"]=data
    return data
