"""
sessions.py — Asia / London / NY / Overlap session ranges

Используется в scenario_engine и на графике (вертикальные зоны сессий).
"""
from __future__ import annotations
import datetime
from typing import List, Dict, Any


SESSIONS_UTC = {
    'ASIA':    (0,  8),
    'LONDON':  (7,  16),
    'NY':      (13, 22),
}
SESSION_COLORS = {
    'ASIA':    'rgba(167,139,250,0.06)',
    'LONDON':  'rgba(96,165,250,0.07)',
    'NY':      'rgba(34,197,94,0.06)',
    'OVERLAP': 'rgba(245,158,11,0.08)',
}


def current_session() -> str:
    h = datetime.datetime.utcnow().hour
    in_l = SESSIONS_UTC['LONDON'][0] <= h < SESSIONS_UTC['LONDON'][1]
    in_n = SESSIONS_UTC['NY'][0]     <= h < SESSIONS_UTC['NY'][1]
    if in_l and in_n:
        return 'OVERLAP'
    if in_l:
        return 'LONDON'
    if in_n:
        return 'NY'
    return 'ASIA'


def session_for_timestamp(ts_ms: int) -> str:
    """Определяет сессию по timestamp в миллисекундах."""
    h = datetime.datetime.utcfromtimestamp(ts_ms / 1000).hour
    in_l = SESSIONS_UTC['LONDON'][0] <= h < SESSIONS_UTC['LONDON'][1]
    in_n = SESSIONS_UTC['NY'][0]     <= h < SESSIONS_UTC['NY'][1]
    if in_l and in_n:
        return 'OVERLAP'
    if in_l:
        return 'LONDON'
    if in_n:
        return 'NY'
    return 'ASIA'


def build_session_bands(candles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Генерирует данные сессионных зон для графика.
    Возвращает список {from, to, color, name} для TradingView background bands.
    """
    if not candles:
        return []

    bands: List[Dict[str, Any]] = []
    prev_sess = None
    band_start = None

    for c in candles:
        ts = c['time']
        # time может быть уже в секундах (TW) или мс
        if ts > 1e10:
            ts_sec = ts // 1000
        else:
            ts_sec = ts
        h = datetime.datetime.utcfromtimestamp(ts_sec).hour
        in_l = SESSIONS_UTC['LONDON'][0] <= h < SESSIONS_UTC['LONDON'][1]
        in_n = SESSIONS_UTC['NY'][0]     <= h < SESSIONS_UTC['NY'][1]
        if in_l and in_n:
            sess = 'OVERLAP'
        elif in_l:
            sess = 'LONDON'
        elif in_n:
            sess = 'NY'
        else:
            sess = 'ASIA'

        if sess != prev_sess:
            if prev_sess and band_start:
                bands.append({'from': band_start, 'to': ts_sec,
                               'color': SESSION_COLORS[prev_sess], 'name': prev_sess})
            band_start = ts_sec
            prev_sess  = sess

    # Закрываем последнюю полосу
    if prev_sess and band_start and candles:
        last_ts = candles[-1]['time']
        if last_ts > 1e10:
            last_ts = last_ts // 1000
        bands.append({'from': band_start, 'to': last_ts,
                      'color': SESSION_COLORS[prev_sess], 'name': prev_sess})

    return bands
