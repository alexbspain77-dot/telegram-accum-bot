"""
market_data.py v8.6 — Global Market с надёжным fallback

Примечание: Open Interest, Funding, Large Trades теперь берутся
из orderflow_engine (который вызывается в institutional_report).
Этот файл отвечает только за Global Market (CoinGecko → Bybit fallback).
"""
from __future__ import annotations
import time
import requests

_s = requests.Session()
_s.headers.update({"User-Agent": "bybit-terminal/8.6"})

_GLOBAL_CACHE: tuple = (0.0, {})
CG    = "https://api.coingecko.com/api/v3"
BYBIT = "https://api.bybit.com"
TTL   = 300  # 5 минут

def _get(url, timeout=6):
    try:
        r = _s.get(url, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def _bybit_ticker(symbol):
    try:
        r = _s.get(f"{BYBIT}/v5/market/tickers", params={"category":"linear","symbol":symbol}, timeout=5)
        js = r.json()
        if js.get("retCode") == 0:
            lst = js.get("result",{}).get("list",[])
            return lst[0] if lst else {}
    except Exception:
        pass
    return {}

def get_global_market() -> dict:
    global _GLOBAL_CACHE
    now = time.time()
    cached_time, cached_data = _GLOBAL_CACHE
    if cached_data and now - cached_time < TTL:
        return cached_data

    # ── Primary: CoinGecko ────────────────────────────────────────
    js = _get(f"{CG}/global")
    if js and "data" in js:
        data = js["data"]
        pct  = data.get("market_cap_percentage") or {}
        btc  = float(pct.get("bitcoin") or pct.get("btc") or 0)
        eth  = float(pct.get("ethereum") or pct.get("eth") or 0)
        total = float((data.get("total_market_cap") or {}).get("usd") or 0)
        vol   = float((data.get("total_volume") or {}).get("usd") or 0)
        result = {
            "btc_dominance":     round(btc, 2),
            "eth_dominance":     round(eth, 2),
            "altcoin_dom":       round(max(0, 100 - btc), 2),
            "total_mcap_usd":    round(total),
            "total_vol_usd":     round(vol),
            "market_cap":        f"${round(total/1e12,2)}T" if total else "—",
            "volume":            f"${round(vol/1e9,1)}B"    if vol   else "—",
            "btc_dom_signal":    "BTC_RISK_ON" if btc > 52 else "ALT_RISK_ON" if btc < 45 else "NEUTRAL",
            "signal":            "BTC_RISK_ON" if btc > 52 else "ALT_RISK_ON" if btc < 45 else "NEUTRAL",
            "source":            "CoinGecko",
        }
        _GLOBAL_CACHE = (now, result)
        return result

    # ── Fallback: Bybit tickers ───────────────────────────────────
    try:
        btc_t = _bybit_ticker("BTCUSDT")
        eth_t = _bybit_ticker("ETHUSDT")
        btc_p = float(btc_t.get("lastPrice") or 0)
        eth_p = float(eth_t.get("lastPrice") or 0)
        # Approximate: BTC ~19.7M supply, ETH ~120M
        btc_mc  = btc_p * 19_700_000
        eth_mc  = eth_p * 120_000_000
        total_e = btc_mc / 0.52  # ~52% BTC dominance
        btc_dom = round(btc_mc / total_e * 100, 1) if total_e else None
        result = {
            "btc_dominance":  btc_dom,
            "eth_dominance":  round(eth_mc / total_e * 100, 1) if total_e else None,
            "altcoin_dom":    round(100 - btc_dom, 1) if btc_dom else None,
            "total_mcap_usd": round(total_e),
            "total_vol_usd":  None,
            "market_cap":     f"${round(total_e/1e12,2)}T" if total_e else "—",
            "volume":         "—",
            "btc_dom_signal": "NEUTRAL",
            "signal":         "NEUTRAL",
            "btc_price":      btc_p,
            "eth_price":      eth_p,
            "source":         "Bybit (CoinGecko недоступен)",
            "_fallback":      True,
        }
        _GLOBAL_CACHE = (now, result)
        return result
    except Exception as e:
        result = {
            "btc_dominance": None, "altcoin_dom": None,
            "total_mcap_usd": None, "total_vol_usd": None,
            "market_cap": "—", "volume": "—",
            "btc_dom_signal": "UNAVAILABLE", "signal": "UNAVAILABLE",
            "source": "unavailable", "_error": str(e),
        }
        _GLOBAL_CACHE = (now - TTL + 60, result)
        return result

def get_extended_data(symbol=None, tf="60") -> dict:
    """Compatibility stub — реальные данные теперь в orderflow_engine."""
    return {
        "symbol": symbol, "tf": tf,
        "open_interest": {}, "funding": {},
        "large_trades": {}, "global_market": get_global_market(),
    }
