from __future__ import annotations
from typing import Any, Dict, List, Optional

def _f(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d

def _dir_from_fvg_type(t: str) -> str:
    t = str(t or "").upper()
    if "BULL" in t:
        return "LONG"
    if "BEAR" in t:
        return "SHORT"
    return "NEUTRAL"

def _fresh(item: Dict[str, Any], last_idx: int, max_age: int = 80) -> bool:
    try:
        idx = int(item.get("idx", last_idx))
        return last_idx - idx <= max_age
    except Exception:
        return True

def nearest_fvg(price: float, fvgs: List[Dict[str, Any]], direction: str | None = None) -> Optional[Dict[str, Any]]:
    if not price or not fvgs:
        return None
    direction = direction or "NEUTRAL"
    candidates = []
    for f in fvgs:
        if f.get("mitigated"):
            continue
        fd = _dir_from_fvg_type(f.get("type"))
        if direction in ("LONG", "SHORT") and fd != direction:
            continue
        low, high = _f(f.get("low")), _f(f.get("high"))
        if not low or not high:
            continue
        mid = _f(f.get("mid"), (low + high) / 2)
        dist_pct = abs(price - mid) / max(price, 1e-12) * 100
        inside = low <= price <= high
        ff = dict(f)
        ff.update({"direction": fd, "dist_pct": round(dist_pct, 4), "inside": inside})
        candidates.append(ff)
    if not candidates:
        return None
    return sorted(candidates, key=lambda x: (not x.get("inside", False), x.get("dist_pct", 999)))[0]

def latest_bos(events: List[Dict[str, Any]], direction: str | None = None) -> Optional[Dict[str, Any]]:
    direction = direction or "NEUTRAL"
    for e in reversed(events or []):
        if e.get("type") == "BOS" and (direction not in ("LONG", "SHORT") or e.get("direction") == direction):
            return e
    return None

def build_confluence(
    price: float,
    fvg_list: List[Dict[str, Any]],
    events: List[Dict[str, Any]],
    orderflow: Dict[str, Any],
    direction: str = "NEUTRAL",
    candles: List[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """
    Confluence Engine v1:
    FVG + BOS + orderflow. Returns score, action and reasons.
    Never raises.
    """
    try:
        candles = candles or []
        last_idx = len(candles) - 1
        flow = orderflow.get("flow") or orderflow.get("bias") or orderflow.get("pressure") or "NEUTRAL"
        quality = orderflow.get("quality", "NO_EDGE")
        large_bias = orderflow.get("large_bias", "NEUTRAL")
        cluster_bias = orderflow.get("cluster_bias", "NEUTRAL")
        absorption = orderflow.get("absorption", "NONE")
        inst = _f(orderflow.get("institutional_score"), 0)
        buy_p = _f(orderflow.get("buy_pressure"), 0)
        sell_p = _f(orderflow.get("sell_pressure"), 0)

        score = 0
        blockers = []
        reasons = []

        fvg = nearest_fvg(price, fvg_list, direction if direction in ("LONG", "SHORT") else None)
        bos = latest_bos(events, direction if direction in ("LONG", "SHORT") else None)

        if fvg:
            score += 18
            reasons.append(f"Fresh {fvg.get('direction')} FVG near price ({fvg.get('dist_pct')}%)")
            if fvg.get("inside"):
                score += 14
                reasons.append("Price is inside FVG reaction zone")
            elif fvg.get("dist_pct", 999) <= 0.35:
                score += 8
                reasons.append("Price is very close to FVG")
            if not _fresh(fvg, last_idx, 100):
                score -= 5
                reasons.append("FVG is older")
        else:
            reasons.append("No active directional FVG")

        if bos:
            score += 16
            reasons.append(f"BOS {bos.get('direction')} at {round(_f(bos.get('level')), 4)}")
            if _fresh(bos, last_idx, 80):
                score += 8
                reasons.append("BOS is fresh")
        else:
            reasons.append("No aligned BOS")

        if direction in ("LONG", "SHORT"):
            if flow == direction:
                score += 18
                reasons.append("Orderflow aligned")
            elif flow in ("LONG", "SHORT"):
                score -= 22
                blockers.append("flow conflict")
                reasons.append("Orderflow conflicts with setup")

            if large_bias == direction:
                score += 8
                reasons.append("Large trade bias aligned")
            elif large_bias in ("LONG", "SHORT"):
                score -= 8
                reasons.append("Large trade bias conflict")

            if cluster_bias == direction:
                score += 8
                reasons.append("Large trade cluster aligned")
            elif cluster_bias in ("LONG", "SHORT"):
                score -= 10
                reasons.append("Large trade cluster conflict")

            if direction == "LONG" and absorption == "BUY_ABSORBED":
                score -= 18
                blockers.append("buy absorption")
                reasons.append("Buy absorption blocks LONG quality")
            elif direction == "SHORT" and absorption == "SELL_ABSORBED":
                score -= 18
                blockers.append("sell absorption")
                reasons.append("Sell absorption blocks SHORT quality")
            elif direction == "LONG" and absorption == "SELL_ABSORBED":
                score += 8
                reasons.append("Sell absorption supports LONG")
            elif direction == "SHORT" and absorption == "BUY_ABSORBED":
                score += 8
                reasons.append("Buy absorption supports SHORT")

        if quality == "DIVERGENCE":
            score -= 15
            blockers.append("orderflow divergence")
            reasons.append("Orderflow divergence detected")

        if inst >= 70:
            score += 10
            reasons.append(f"Institutional score strong: {inst}")
        elif inst <= 20 and quality not in ("PROXY_FALLBACK", "NO_EDGE"):
            score -= 5
            reasons.append("Weak institutional activity")

        score = max(0, min(100, int(round(score))))

        if blockers and score < 75:
            grade, action = "BLOCKED", "WAIT"
        elif score >= 80:
            grade, action = "A+", "TRADE"
        elif score >= 68:
            grade, action = "A", "TRADE"
        elif score >= 55:
            grade, action = "B", "WAIT_RETEST"
        elif score >= 40:
            grade, action = "C", "WATCH"
        else:
            grade, action = "NO_EDGE", "SKIP"

        return {
            "ok": True,
            "score": score,
            "grade": grade,
            "action": action,
            "direction": direction,
            "fvg": fvg,
            "bos": bos,
            "orderflow": {
                "flow": flow,
                "quality": quality,
                "large_bias": large_bias,
                "cluster_bias": cluster_bias,
                "absorption": absorption,
                "institutional_score": inst,
                "buy_pressure": buy_p,
                "sell_pressure": sell_p,
            },
            "blockers": blockers,
            "reasons": reasons[:12],
        }
    except Exception as e:
        return {"ok": False, "score": 0, "grade": "ERROR", "action": "SKIP", "direction": direction, "blockers": [str(e)], "reasons": []}
