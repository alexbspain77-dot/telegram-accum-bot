"""institutional.py v8.6 — passes decision_blockers to early_signal_engine"""
from __future__ import annotations
from typing import Any, Dict
from .early_signal_engine import score_early_signal
from .data_feed import get_ohlc, get_mtf_bias, get_orderbook_imbalance
from .indicators import ema, rsi as calc_rsi, to_line
from .core import liquidity_engine, smc_engine, orderflow_engine
from .core.risk_engine import build_risk_plan
from .core.scenario_engine import build_scenario
from .sessions import build_session_bands
from .smc_full import full_smc_report
from .market_data import get_extended_data
from .confluence_engine import build_confluence
from .phase_engine import detect_phase, phase_decision_adjustment
from .pro_trader_engine import build_pro_trader_decision
from .pattern_engine import detect_patterns, pattern_decision_adjustment
from .decision_engine_v3 import build_decision_v3
from .smart_zone_engine import build_smart_zones, zone_decision_adjustment

try:
    from .elliott import detect_elliott
    _HAS_ELLIOTT = True
except Exception:
    _HAS_ELLIOTT = False

try:
    from .learning_engine import apply_learning_adjustment
    _HAS_LEARNING = True
except Exception:
    _HAS_LEARNING = False


def _elliott_points(elliott):
    if not elliott or not elliott.get("points"):
        return []
    labels = elliott.get("labels") or []
    pts = []
    for i, p in enumerate(elliott.get("points") or []):
        if not p: continue
        t = p.get("time") or p.get("timestamp")
        price = p.get("price")
        if t and price:
            t_sec = int(t)//1000 if int(t) > 1e10 else int(t)
            pts.append({"time": t_sec, "price": float(price),
                         "label": labels[i] if i < len(labels) else str(i+1),
                         "kind": p.get("kind","")})
    return pts


def institutional_report(symbol: str, tf: str = "60",
                          account_usd: float = 10000,
                          risk_pct: float = 1.0) -> Dict[str, Any]:
    symbol  = symbol.upper()
    candles = get_ohlc(symbol, tf, 320)
    mtf     = get_mtf_bias(symbol)
    ob      = get_orderbook_imbalance(symbol)
    entry   = float(candles[-1]["close"]) if candles else 0.0

    swings    = liquidity_engine.find_swings(candles, left=8, right=8)
    pools     = liquidity_engine.find_liquidity_pools(candles, swings)
    sweeps    = liquidity_engine.detect_sweeps(candles, pools)
    structure = smc_engine.structure_from_swings(swings)
    events    = smc_engine.detect_bos_choch(candles, swings)
    fvg       = smc_engine.detect_fvg(candles)
    pd        = smc_engine.premium_discount(candles, swings)

    try: smc_ext = full_smc_report(candles, swings)
    except Exception: smc_ext = {}

    of  = orderflow_engine.orderflow_summary(candles, ob, symbol)
    flow = of.get('flow') or of.get('bias') or of.get('pressure') or 'NEUTRAL'
    phase = detect_phase(candles, of)
    patterns = detect_patterns(candles, smc=None, orderflow=of)
    smc = {"structure":structure,"events":events,"fvg":fvg,"premium_discount":pd,**smc_ext}
    liq = {"pools":pools[:20],"sweeps":sweeps}
    smart_zones = build_smart_zones(candles, sweeps=sweeps, events=events, fvg=fvg, phase=phase, patterns=patterns)

    elliott = None
    if _HAS_ELLIOTT and len(candles) >= 20:
        try: elliott = detect_elliott(candles)
        except Exception: pass

    closes   = [float(c["close"]) for c in candles]
    rsi_vals = calc_rsi(closes, 14)
    rsi_last = next((v for v in reversed(rsi_vals) if v is not None), None)
    if rsi_last: rsi_last = round(rsi_last, 2)

    scenario  = build_scenario(liq, smc, of, mtf, pd,
                                elliott=elliott, rsi_last=rsi_last,
                                price=entry, candles=candles)
    direction = scenario.get("direction","NEUTRAL")
    targets   = liquidity_engine.nearest_liquidity_targets(entry, pools, direction)
    risk = build_risk_plan(entry, direction, swings, candles, targets,
                            scenario=scenario, smc=smc, mtf=mtf, orderflow=of,
                            account_usd=account_usd, risk_pct=risk_pct)

    confluence = build_confluence(entry, fvg, events, of, direction, candles)
    try:
        scenario.setdefault("decision", {})
        scenario["decision"]["confluence"] = confluence
        scenario["decision"]["confluence_grade"] = confluence.get("grade")
        scenario["decision"]["confluence_action"] = confluence.get("action")
        scenario["decision"]["confluence_score"] = confluence.get("score")
        if confluence.get("grade") in ("A+", "A") and confluence.get("direction") == direction:
            scenario["confidence"] = max(0, min(97, int(float(scenario.get("confidence") or 0) + 8)))
            scenario.setdefault("reasons", []).append(f"Confluence {confluence.get('grade')} FVG+BOS+Flow")
        elif confluence.get("grade") == "BLOCKED":
            scenario["confidence"] = min(int(float(scenario.get("confidence") or 0)), 45)
            scenario.setdefault("reasons", []).append("Confluence blocked: " + ", ".join(confluence.get("blockers") or []))
    except Exception:
        pass

    phase_adj = phase_decision_adjustment(phase, scenario.get("direction", "NEUTRAL"))
    pattern_adj = pattern_decision_adjustment(patterns, scenario.get("direction", "NEUTRAL"))
    zone_adj = zone_decision_adjustment(smart_zones, scenario.get("direction", "NEUTRAL"))
    try:
        scenario.setdefault("decision", {})
        scenario["decision"]["phase"] = phase
        scenario["decision"]["phase_adjustment"] = phase_adj
        scenario["decision"].setdefault("blockers", [])
        scenario["decision"]["blockers"].extend(phase_adj.get("blockers") or [])
        scenario.setdefault("reasons", [])
        scenario["reasons"].extend(phase_adj.get("reasons") or [])
        scenario["confidence"] = max(0, min(97, int(float(scenario.get("confidence") or 0) + float(phase_adj.get("score_adjustment") or 0) + float(pattern_adj.get("score_adjustment") or 0) + float(zone_adj.get("score_adjustment") or 0))))
        scenario["decision"]["patterns"] = patterns
        scenario["decision"]["pattern_adjustment"] = pattern_adj
        scenario["decision"]["smart_zones"] = smart_zones
        scenario["decision"]["zone_adjustment"] = zone_adj
        scenario["decision"]["blockers"].extend(pattern_adj.get("blockers") or [])
        scenario["decision"]["blockers"].extend(zone_adj.get("blockers") or [])
        scenario["reasons"].extend(pattern_adj.get("reasons") or [])
        scenario["reasons"].extend(pattern_adj.get("warnings") or [])
        scenario["reasons"].extend(zone_adj.get("reasons") or [])
        scenario["reasons"].extend(zone_adj.get("warnings") or [])
    except Exception:
        pass

    # ── Early signal — передаём decision_blockers ────────────────
    decision_blockers = (scenario.get("decision") or {}).get("blockers") or []
    early = score_early_signal(
        candles=candles, sweeps=sweeps, events=events,
        orderflow=of, mtf=mtf, pd=pd,
        rsi_last=rsi_last, elliott=elliott,
        decision_blockers=decision_blockers,   # ИСПРАВЛЕНО
    )

    # Upgrade NO_TRADE/weak to EARLY_REVERSAL
    try:
        sc_type = str(scenario.get("type") or "")
        sc_conf = float(scenario.get("confidence") or 0)
        if early.get("mode") == "EARLY" and (sc_type == "NO_TRADE" or sc_conf < 55):
            scenario["type"]      = "EARLY_REVERSAL"
            scenario["setup"]     = "EARLY_REVERSAL"
            scenario["direction"] = early.get("side")
            scenario["confidence"]= early.get("confidence")
            scenario["reasons"]   = list(early.get("reasons") or []) + list(scenario.get("reasons") or [])[:4]
            scenario.setdefault("decision", {})
            scenario["decision"]["mode"]             = "EARLY"
            scenario["decision"]["early_score"]      = early.get("score")
            scenario["decision"]["early_risk_note"]  = early.get("risk_note")
            scenario["decision"]["early_grade"]      = early.get("early_grade")
    except Exception: pass

    try: ext_data = get_extended_data(symbol)
    except Exception: ext_data = {}

    report = {
        "ok":True,"symbol":symbol,"tf":tf,
        "scenario":scenario,"liquidity":liq,"smc":smc,
        "orderflow":of,"phase":phase,"patterns":patterns,"smart_zones":smart_zones,"confluence":confluence,"flow":flow,"mtf":mtf,"risk":risk,
        "elliott":elliott,"elliott_points":_elliott_points(elliott),
        "rsi":rsi_last,"early_signal":early,
        "session":scenario.get("session"),
        "session_bands":build_session_bands(candles[-200:]),
        "fvg_zones":[f for f in fvg if not f.get("mitigated")][-10:],
        "extended":ext_data,
        "markers":_build_markers(events,sweeps),
        "levels":_build_levels(pools,risk),
        "summary":{
            "absorption":of.get("absorption"),"iceberg_risk":of.get("iceberg_risk"),"spoof_risk":of.get("spoof_risk"),"tape_delta":of.get("tape_delta"),"weighted_delta":of.get("weighted_delta"),"extreme_trades":of.get("extreme_trades"),"institutional_score":of.get("institutional_score"),"institutional_bias":direction,"flow":flow,"buy_pressure":of.get("buy_pressure"),"sell_pressure":of.get("sell_pressure"),
            "setup":      scenario.get("setup"),
            "confidence": scenario.get("confidence"),
            "market_phase": phase.get("phase"),
            "phase_strength": phase.get("strength"),
            "phase_bias": phase.get("bias"),
            "pattern_primary": (patterns.get("primary") or {}).get("type"),
            "pattern_bias": patterns.get("bias"),
            "pattern_strength": (patterns.get("primary") or {}).get("strength"),
            "smart_zone_context": smart_zones.get("context"),
            "smart_zone_strength": (smart_zones.get("primary") or {}).get("strength"),
            "smart_zone_adjustment": smart_zones.get("adjustment"),
            "trap":       scenario.get("trap"),
            "pd_zone":    pd.get("zone"),
            "pct_from_eq":pd.get("pct_from_eq"),
            "mtf_bias":   mtf.get("bias"),
            "flow_bias":  of.get("bias"),
            "rsi":        rsi_last,
            "session":    scenario.get("session"),
            "elliott":    elliott.get("type") if elliott else None,
            "quality":    risk.get("quality",{}).get("grade"),
            "ev":         risk.get("ev"),
            "early_mode":    early.get("mode"),
            "early_score":   early.get("score"),
            "early_grade":   early.get("early_grade"),
            "early_reasons": early.get("reasons"),
        }
    }

    pro_trader = build_pro_trader_decision(report)
    report["pro_trader"] = pro_trader
    report["candles"] = candles[-120:]
    decision_v3 = build_decision_v3(report)
    report["decision_v3"] = decision_v3
    from .pnl_engine import open_trade
    if decision_v3.get('action')=='TRADE':
        open_trade(symbol, {'entry': report.get('price',0),'tp': report.get('tp',0),'sl': report.get('sl',0),'direction': decision_v3.get('direction')})
    try:
        report["summary"]["pro_action"] = pro_trader.get("action")
        report["summary"]["pro_score"] = pro_trader.get("score")
        report["summary"]["pro_permission"] = pro_trader.get("permission")
        report["summary"]["pro_risk_label"] = pro_trader.get("risk_label")
        report["summary"]["decision_v3_action"] = decision_v3.get("action")
        report["summary"]["decision_v3_probability"] = decision_v3.get("probability")
        report["summary"]["decision_v3_ev"] = decision_v3.get("ev")
        report["summary"]["decision_v3_grade"] = decision_v3.get("grade")
    except Exception:
        pass

    if _HAS_LEARNING:
        try: report = apply_learning_adjustment(report)
        except Exception: pass

    return report


def _build_markers(events, sweeps):
    markers = []
    for e in (events or [])[-8:]:
        markers.append({"time":e["time"],
            "position":"aboveBar" if e["direction"]=="LONG" else "belowBar",
            "color":"#22c55e" if e["direction"]=="LONG" else "#ef4444",
            "shape":"arrowUp" if e["direction"]=="LONG" else "arrowDown",
            "text":f"{e['type']} {e['direction']}"})
    for s in (sweeps or [])[-6:]:
        markers.append({"time":s["time"],
            "position":"aboveBar" if s["type"]=="buy_side_sweep" else "belowBar",
            "color":"#eab308","shape":"circle",
            "text":"BSL sweep" if s["type"]=="buy_side_sweep" else "SSL sweep"})
    return markers

def _build_levels(pools, risk):
    levels = []
    for p in (pools or [])[:12]:
        levels.append({"name":"BSL" if p["type"]=="buy_side_liquidity" else "SSL",
                        "price":p["price"],"kind":p["type"],"strength":p["strength"]})
    for n in ["stop","tp1","tp2","invalidation"]:
        if risk.get(n):
            levels.append({"name":n.upper(),"price":risk[n],"kind":n,"strength":100})
    return levels
