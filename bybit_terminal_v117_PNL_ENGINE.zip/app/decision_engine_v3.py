from __future__ import annotations
from typing import Any, Dict, List
import math
from .ml_ensemble import ensemble_predict

def _f(v, d=0.0):
    try:
        if v is None:
            return d
        return float(v)
    except Exception:
        return d

def _i(v, d=0):
    try:
        return int(float(v))
    except Exception:
        return d

def _clamp(x, lo, hi):
    return max(lo, min(hi, x))

def _sigmoid(x):
    try:
        return 1.0 / (1.0 + math.exp(-x))
    except Exception:
        return 0.5

def _dir_score(value: str, direction: str, w: float = 1.0) -> float:
    value = str(value or "NEUTRAL").upper()
    direction = str(direction or "NEUTRAL").upper()
    if direction not in ("LONG", "SHORT"):
        return 0.0
    if value == direction:
        return abs(w)
    if value in ("LONG", "SHORT") and value != direction:
        return -abs(w)
    return 0.0

def _quality_to_score(q):
    q = str(q or "").upper()
    return {"A+": 12, "A": 10, "B": 5, "C": 0, "D": -8, "BLOCKED": -25}.get(q, 0)

def _phase_score(phase: Dict[str, Any], direction: str) -> float:
    ph = str(phase.get("phase") or "").upper()
    bias = str(phase.get("bias") or "").upper()
    strength = _f(phase.get("strength"), 0)
    s = _dir_score(bias, direction, min(14, strength / 6))
    if ph == "ACCUMULATION" and direction == "LONG":
        s += 8
    if ph == "DISTRIBUTION" and direction == "SHORT":
        s += 8
    if ph == "MIXED_ABSORPTION":
        s -= 4
    return s

def _pattern_score(patterns: Dict[str, Any], direction: str) -> float:
    s = 0.0
    for p in (patterns.get("patterns") or [])[:5]:
        pd = str(p.get("direction") or "NEUTRAL").upper()
        strength = _f(p.get("strength"), 0)
        typ = str(p.get("type") or "")
        if pd == direction:
            s += min(14, strength / 7)
        elif pd in ("LONG", "SHORT") and pd != direction:
            s -= min(14, strength / 7)
        elif typ == "COMPRESSION":
            s -= 2
        elif typ == "RANGE_BOX":
            s -= 3
    return s

def _zone_score(zones: Dict[str, Any], direction: str) -> float:
    ctx = str(zones.get("context") or "")
    adj = _f(zones.get("adjustment"), 0)
    s = adj * 0.75
    if ctx == "INSIDE_DANGER_ZONE":
        s -= 14
    if ctx == "BREAKOUT_ABOVE_ZONE":
        s += 10 if direction == "LONG" else -12
    if ctx == "BREAKDOWN_BELOW_ZONE":
        s += 10 if direction == "SHORT" else -12
    if ctx == "FVG_RETEST_ACTIVE":
        s += 7
    return s

def _orderflow_score(of: Dict[str, Any], direction: str) -> float:
    s = 0.0
    s += _dir_score(of.get("flow") or of.get("bias"), direction, 12)
    s += _dir_score(of.get("large_bias"), direction, 10)
    s += _dir_score(of.get("cluster_bias"), direction, 6)
    inst = _f(of.get("institutional_score"), 50)
    s += _clamp((inst - 50) / 4, -10, 12)
    buy = _f(of.get("buy_pressure"), 0)
    sell = _f(of.get("sell_pressure"), 0)
    if direction == "LONG":
        s += _clamp((buy - sell) / 8, -10, 10)
    elif direction == "SHORT":
        s += _clamp((sell - buy) / 8, -10, 10)
    absorption = str(of.get("absorption") or "").upper()
    if "BUY" in absorption and direction == "LONG":
        s += 8
    if "SELL" in absorption and direction == "SHORT":
        s += 8
    if "BUY" in absorption and direction == "SHORT":
        s -= 10
    if "SELL" in absorption and direction == "LONG":
        s -= 10
    return s

def _liquidity_score(liq: Dict[str, Any], direction: str) -> float:
    s = 0.0
    sweeps = liq.get("sweeps") or []
    for sw in sweeps[-5:]:
        typ = str(sw.get("type") or "").lower()
        if "sell_side" in typ:
            s += 6 if direction == "LONG" else -5
        elif "buy_side" in typ:
            s += 6 if direction == "SHORT" else -5
    return _clamp(s, -18, 18)

def _risk_score(risk: Dict[str, Any]) -> float:
    rr = _f(risk.get("rr1"), 0)
    ev = _f(risk.get("ev"), 0)
    q = (risk.get("quality") or {}).get("grade")
    s = _quality_to_score(q)
    if rr >= 2.0:
        s += 8
    elif rr >= 1.4:
        s += 4
    elif rr < 1.0:
        s -= 12
    if ev > 0:
        s += min(10, ev * 6)
    elif ev < 0:
        s -= min(12, abs(ev) * 8)
    if risk.get("valid") is False:
        s -= 30
    return s

def _regime_score(report: Dict[str, Any], direction: str) -> Dict[str, Any]:
    candles = report.get("candles") or report.get("chart", {}).get("candles") or []
    if not candles:
        return {"regime": "UNKNOWN", "score": 0, "volatility": 0, "trend": 0}
    closes = [_f(c.get("close")) for c in candles[-80:] if c.get("close") is not None]
    if len(closes) < 20:
        return {"regime": "UNKNOWN", "score": 0, "volatility": 0, "trend": 0}
    rets = []
    for a, b in zip(closes[:-1], closes[1:]):
        if a:
            rets.append((b - a) / a)
    vol = (sum(x * x for x in rets) / max(1, len(rets))) ** 0.5 * 100
    trend = (closes[-1] - closes[0]) / max(abs(closes[0]), 1e-12) * 100
    abs_trend = abs(trend)
    if vol > 1.7 and abs_trend > 2.0:
        regime = "VOLATILE_TREND"
    elif abs_trend > 1.2:
        regime = "TREND"
    elif vol < 0.45:
        regime = "LOW_VOL_RANGE"
    else:
        regime = "RANGE"
    score = 0
    if regime in ("TREND", "VOLATILE_TREND"):
        if trend > 0 and direction == "LONG":
            score += 8
        elif trend < 0 and direction == "SHORT":
            score += 8
        else:
            score -= 7
    elif regime in ("RANGE", "LOW_VOL_RANGE"):
        score -= 3
    return {"regime": regime, "score": score, "volatility": round(vol, 4), "trend": round(trend, 4)}

def build_decision_v3(report: Dict[str, Any]) -> Dict[str, Any]:
    scenario = report.get("scenario") or {}
    direction = str(scenario.get("direction") or "NEUTRAL").upper()
    base_conf = _f(scenario.get("confidence"), 0)
    if direction not in ("LONG", "SHORT"):
        return {
            "version": "v3",
            "action": "NO_TRADE",
            "permission": "NO_TRADE",
            "direction": direction,
            "probability": 50,
            "score": 0,
            "ev": 0,
            "grade": "NO_TRADE",
            "reasons": ["no directional scenario"],
            "blockers": ["direction neutral"],
            "components": {},
        }

    of = report.get("orderflow") or {}
    phase = report.get("phase") or {}
    patterns = report.get("patterns") or {}
    zones = report.get("smart_zones") or {}
    risk = report.get("risk") or {}
    liq = report.get("liquidity") or {}
    confluence = report.get("confluence") or {}
    mtf = report.get("mtf") or {}
    pro = report.get("pro_trader") or {}

    regime = _regime_score(report, direction)

    components = {
        "base_scenario": _clamp((base_conf - 50) / 2.2, -20, 22),
        "orderflow": _orderflow_score(of, direction),
        "phase": _phase_score(phase, direction),
        "patterns": _pattern_score(patterns, direction),
        "smart_zones": _zone_score(zones, direction),
        "liquidity": _liquidity_score(liq, direction),
        "risk": _risk_score(risk),
        "confluence": _quality_to_score(confluence.get("grade")),
        "mtf": _dir_score(mtf.get("bias"), direction, 8),
        "regime": regime.get("score", 0),
    }

    raw = sum(components.values())
    p_win = _clamp(100 * _sigmoid(raw / 38.0), 3, 97)

    rr = _f(risk.get("rr1"), 1.0)
    if rr <= 0:
        rr = 1.0
    ev = (p_win / 100.0) * rr - (1 - p_win / 100.0) * 1.0

    blockers: List[str] = []
    warnings: List[str] = []
    reasons: List[str] = []

    for b in (scenario.get("decision") or {}).get("blockers") or []:
        blockers.append(str(b))
    for b in zones.get("blockers") or []:
        blockers.append(str(b))
    if risk.get("valid") is False:
        blockers.append("invalid risk structure")
    if zones.get("context") == "INSIDE_DANGER_ZONE":
        warnings.append("inside smart danger zone")
    if confluence.get("grade") == "BLOCKED":
        warnings.append("confluence blocked")
    if rr < 1.15:
        warnings.append("RR below 1.15")
    if ev <= 0:
        warnings.append("negative EV")

    for k, v in sorted(components.items(), key=lambda kv: abs(kv[1]), reverse=True):
        if abs(v) >= 6:
            reasons.append(f"{k}: {'+' if v > 0 else ''}{round(v, 1)}")
    if regime.get("regime") != "UNKNOWN":
        reasons.append(f"regime {regime.get('regime')} trend={regime.get('trend')} vol={regime.get('volatility')}")

    score = int(_clamp(50 + raw, 0, 100))
    if blockers:
        action = "BLOCKED"
        permission = "NO_TRADE"
    elif p_win >= 64 and ev > 0.18 and rr >= 1.15:
        action = "TRADE"
        permission = "ALLOW"
    elif p_win >= 56 and ev > 0:
        action = "WAIT_CONFIRMATION"
        permission = "WATCH"
    else:
        action = "NO_TRADE"
        permission = "NO_TRADE"

    if p_win >= 72 and ev > 0.45 and not blockers:
        grade = "A+"
    elif p_win >= 64 and ev > 0.18 and not blockers:
        grade = "A"
    elif p_win >= 56 and ev > 0:
        grade = "B"
    elif blockers:
        grade = "BLOCKED"
    else:
        grade = "C"

    return {
        "version": "v3",
        "action": action,
        "permission": permission,
        "direction": direction,
        "probability": round(p_win, 1),
        "score": score,
        "ev": round(ev, 3),
        "rr1": round(rr, 3),
        "grade": grade,
        "regime": regime,
        "components": {k: round(v, 2) for k, v in components.items()},
        "reasons": reasons[:10],
        "warnings": warnings[:10],
        "blockers": list(dict.fromkeys(blockers))[:10],
        "pro_action": pro.get("action"),
        "zone_context": zones.get("context"),
    }
