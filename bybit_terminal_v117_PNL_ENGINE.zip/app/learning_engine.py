from __future__ import annotations
from .trade_journal import load_trades

def get_learning():
    trades = load_trades()
    closed = [t for t in trades if t.get("status") == "CLOSED"]
    wins = [t for t in closed if float(t.get("pnl_pct") or 0) > 0]
    losses = [t for t in closed if float(t.get("pnl_pct") or 0) <= 0]
    total = len(closed)
    avg = round(sum(float(t.get("pnl_pct") or 0) for t in closed) / total, 3) if total else 0
    return {
        "trade_count": total,
        "total_closed": total,
        "wins": len(wins),
        "losses": len(losses),
        "winrate": round(len(wins) / total * 100, 2) if total else 0,
        "pnl": round(sum(float(t.get("pnl_pct") or 0) for t in closed), 3),
        "avg_pnl_pct": avg,
        "insights": [
            "Need at least 10 closed trades for stable conclusions" if total < 10 else "Enough trades for first pattern review"
        ]
    }

def apply_learning_adjustment(report):
    # conservative placeholder: never breaks institutional_report
    return report
