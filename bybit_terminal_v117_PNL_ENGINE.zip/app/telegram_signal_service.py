from __future__ import annotations
from typing import Any, Dict
import os, time

try:
    import requests
except Exception:
    requests = None

LAST_SENT = {}  # process-memory anti-spam

def _token():
    return os.environ.get("TELEGRAM_BOT_TOKEN") or os.environ.get("TG_BOT_TOKEN") or "7548166927:AAGs6lNK3r4Kug7LDGkrs99U2Xah3eFdHh0"

def format_signal(symbol: str, signal: Dict[str, Any]) -> str:
    direction = signal.get("direction") or "NEUTRAL"
    conf = signal.get("confidence") or 0
    pro = signal.get("pro_action") or signal.get("pro_trader",{}).get("action") or ""
    score = signal.get("pro_score") or signal.get("pro_trader",{}).get("score") or ""
    price = signal.get("price") or signal.get("entry") or ""
    phase = signal.get("market_phase") or signal.get("phase",{}).get("phase") or ""
    pattern = signal.get("pattern_primary") or signal.get("patterns",{}).get("primary",{}).get("type") or ""
    rr = signal.get("rr1") or signal.get("risk",{}).get("rr1") or ""
    return (
        f"🚨 Bybit Terminal Signal\n"
        f"Symbol: {symbol}\n"
        f"Direction: {direction}\n"
        f"Confidence: {conf}%\n"
        f"PRO: {pro} {score}\n"
        f"Price/Entry: {price}\n"
        f"RR1: {rr}\n"
        f"Phase: {phase}\n"
        f"Pattern: {pattern}"
    )

def should_send(user: Dict[str, Any], signal: Dict[str, Any]) -> bool:
    if not user.get("telegram_enabled"): return False
    if not user.get("telegram_chat_id"): return False
    min_conf = int(user.get("telegram_min_confidence",65) or 65)
    conf = int(float(signal.get("confidence") or 0))
    if conf < min_conf: return False
    if user.get("telegram_only_pro_trade", True):
        action = signal.get("pro_action") or signal.get("pro_trader",{}).get("action")
        if action != "TRADE": return False
    return True

def send_message(chat_id: str, text: str) -> Dict[str, Any]:
    token = _token()
    if not token:
        return {"ok": False, "error": "TELEGRAM_BOT_TOKEN is not set"}
    if requests is None:
        return {"ok": False, "error": "requests is not installed"}
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True},
            timeout=10,
        )
        js = r.json()
        return {"ok": bool(js.get("ok")), "telegram": js}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def maybe_send_signal(username: str, user: Dict[str, Any], signal: Dict[str, Any]) -> Dict[str, Any]:
    if not should_send(user, signal):
        return {"ok": False, "skipped": True}
    symbol = signal.get("symbol") or "UNKNOWN"
    direction = signal.get("direction") or "NEUTRAL"
    conf = signal.get("confidence") or 0
    key = f"{username}:{symbol}:{direction}:{conf}"
    now = time.time()
    if key in LAST_SENT and now - LAST_SENT[key] < 15 * 60:
        return {"ok": False, "skipped": True, "reason": "cooldown"}
    LAST_SENT[key] = now
    return send_message(user.get("telegram_chat_id"), format_signal(symbol, signal))


def send_signal_to_matching_users(users: dict, signal: dict) -> dict:
    """Send one signal to every user who has Telegram enabled and whose watchlist contains symbol."""
    sent, skipped, errors = 0, 0, []
    symbol = signal.get("symbol") or ""
    for username, user in (users or {}).items():
        try:
            wl = user.get("watchlist") or []
            if symbol and wl and symbol not in wl:
                skipped += 1
                continue
            res = maybe_send_signal(username, user, signal)
            if res.get("ok"):
                sent += 1
            else:
                skipped += 1
                if res.get("error"):
                    errors.append({username: res.get("error")})
        except Exception as e:
            errors.append({username: str(e)})
    return {"ok": True, "sent": sent, "skipped": skipped, "errors": errors[:5]}
