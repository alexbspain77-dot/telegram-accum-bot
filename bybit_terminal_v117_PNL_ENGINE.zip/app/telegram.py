"""
telegram.py — Telegram-уведомления для v7

Отправляет сигналы в Telegram при смене scenario direction.
Запуск: python -m app.telegram  (тест отправки)

Переменные окружения (.env):
  TELEGRAM_TOKEN   — токен от @BotFather
  TELEGRAM_CHAT_ID — твой chat id
"""
from __future__ import annotations
import os
import json
import time
import threading
import requests
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

TOKEN   = os.getenv('TELEGRAM_TOKEN',   '')
CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')

# Хранилище последних направлений по символу — не спамим одинаковым сигналом
_last_direction: dict[str, str] = {}
_lock = threading.Lock()


def _send(text: str) -> bool:
    if not TOKEN or not CHAT_ID:
        print(f"[Telegram] не настроен: {text[:60]}")
        return False
    try:
        r = requests.post(
            f'https://api.telegram.org/bot{TOKEN}/sendMessage',
            json={'chat_id': CHAT_ID, 'text': text, 'parse_mode': 'HTML'},
            timeout=8
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[Telegram] ошибка: {e}")
        return False


def _confidence_bar(conf: int) -> str:
    filled = round(conf / 10)
    return '█' * filled + '░' * (10 - filled)


def format_signal(symbol: str, report: dict) -> str:
    sc   = report.get('scenario', {})
    risk = report.get('risk', {})
    of   = report.get('orderflow', {})
    mtf  = report.get('mtf', {})
    smc  = report.get('smc', {})
    pd   = smc.get('premium_discount', {})

    direction  = sc.get('direction', 'NEUTRAL')
    confidence = sc.get('confidence', 0)
    setup      = sc.get('setup', '—')
    trap       = sc.get('trap', 'NONE')
    session    = sc.get('session', '—')

    emoji = '🟢' if direction == 'LONG' else '🔴' if direction == 'SHORT' else '⚪'
    trap_line = f"\n⚠️ <b>Trap:</b> {trap}" if trap != 'NONE' else ''

    entry = risk.get('entry')
    stop  = risk.get('stop')
    tp1   = risk.get('tp1')
    tp2   = risk.get('tp2')
    rr1   = risk.get('rr1')

    def fmt(v):
        return f"${float(v):,.4f}" if v is not None else '—'

    return (
        f"{emoji} <b>{symbol} — {direction}</b>{trap_line}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📊 Уверенность: {confidence}%\n"
        f"{_confidence_bar(confidence)}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🔧 Setup:     <b>{setup}</b>\n"
        f"🕐 Сессия:    {session}\n"
        f"📈 MTF bias:  {mtf.get('bias', '—')}\n"
        f"💧 Flow:      {of.get('bias', '—')} ({of.get('quality', '—')})\n"
        f"🎯 PD Zone:   {pd.get('zone', '—')}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"💰 Entry:     {fmt(entry)}\n"
        f"🛑 Stop:      {fmt(stop)}\n"
        f"🎯 TP1:       {fmt(tp1)}\n"
        f"🎯 TP2:       {fmt(tp2)}\n"
        f"⚖️  RR1:       {rr1 if rr1 else '—'}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📝 {'; '.join((sc.get('reasons') or [])[:3])}"
    )


def notify_if_changed(symbol: str, report: dict) -> bool:
    """Отправляет уведомление только если direction изменился."""
    sc        = report.get('scenario', {})
    direction = sc.get('direction', 'NEUTRAL')
    stype     = sc.get('type', 'NO_TRADE')
    confidence= sc.get('confidence', 0)

    if stype == 'NO_TRADE' or direction == 'NEUTRAL' or confidence < 50:
        return False

    with _lock:
        if _last_direction.get(symbol) == direction:
            return False
        _last_direction[symbol] = direction

    return _send(format_signal(symbol, report))


def send_raw(text: str) -> bool:
    return _send(text)


def notify_startup(symbols: list[str]) -> None:
    _send(
        f"✅ <b>Bybit Signal Bot v7 запущен</b>\n"
        f"Мониторинг: {', '.join(symbols)}\n"
        f"Движки: SMC · Liquidity · Elliott · Session · RSI filter"
    )


# ── Фоновый поток мониторинга ────────────────────────────────────
def start_monitor(symbols: list[str], interval: int = 60) -> None:
    """Запускает фоновый поток — проверяет сигналы каждые interval секунд."""
    from .institutional import institutional_report

    def _loop():
        notify_startup(symbols)
        while True:
            for sym in symbols:
                try:
                    report = institutional_report(sym.upper(), '60')
                    notify_if_changed(sym.upper(), report)
                except Exception as e:
                    print(f"[monitor] {sym} error: {e}")
            time.sleep(interval)

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    print(f"[Telegram monitor] запущен для {symbols}, интервал {interval}с")


if __name__ == '__main__':
    # Быстрый тест отправки
    test = "🧪 <b>Тест Telegram</b>\nBybit Signal Bot v7 — соединение работает ✅"
    ok = _send(test)
    print("Отправлено!" if ok else "Ошибка — проверь TOKEN и CHAT_ID в .env")
