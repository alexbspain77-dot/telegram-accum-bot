from __future__ import annotations
from typing import Any, Dict, List

def _f(v, d=0.0):
    try:
        return float(v)
    except Exception:
        return d

def _i(v, d=0):
    try:
        return int(float(v))
    except Exception:
        return d

def build_pro_trader_decision(report: Dict[str, Any]) -> Dict[str, Any]:
    """
    Pro Trader Mode v1
    Combines scenario + confluence + phase + orderflow + news risk + risk plan.
    Produces a clear trade permission/action layer:
      TRADE / WAIT / BLOCKED / SKIP
    Never raises.
    """
    try:
        scenario = report.get("scenario") or {}
        risk = report.get("risk") or {}
        of = report.get("orderflow") or {}
        cf = report.get("confluence") or {}
        phase = report.get("phase") or {}
        news = report.get("news") or report.get("news_context") or {}
        patterns = report.get("patterns") or {}
        smart_zones = report.get("smart_zones") or {}

        direction = scenario.get("direction") or cf.get("direction") or "NEUTRAL"
        confidence = _i(scenario.get("confidence"), 0)
        cf_score = _i(cf.get("score"), 0)
        cf_grade = cf.get("grade") or "NO_EDGE"
        phase_name = phase.get("phase") or "NEUTRAL"
        phase_strength = _i(phase.get("strength"), 0)
        flow = of.get("flow") or of.get("bias") or "NEUTRAL"
        quality = of.get("quality") or "NO_EDGE"
        absorption = of.get("absorption") or "NONE"
        news_risk = _i(news.get("risk_score") or news.get("news_risk") or report.get("news_risk"), 0)
        high_impact = bool(news.get("high_impact") or news.get("fomc") or news.get("cpi"))

        blockers: List[str] = []
        warnings: List[str] = []
        reasons: List[str] = []
        score = 0

        # Core scoring
        score += min(35, confidence * 0.35)
        score += min(25, cf_score * 0.25)

        if cf_grade in ("A+", "A"):
            score += 12
            reasons.append(f"Confluence {cf_grade}")
        elif cf_grade == "BLOCKED":
            blockers.append("confluence blocked")

        if direction in ("LONG", "SHORT"):
            score += 8
            reasons.append(f"direction {direction}")
        else:
            blockers.append("no directional edge")

        if flow == direction and direction in ("LONG", "SHORT"):
            score += 12
            reasons.append("flow aligned")
        elif flow in ("LONG", "SHORT") and direction in ("LONG", "SHORT"):
            score -= 12
            warnings.append("flow conflict")

        if phase_name == "ACCUMULATION":
            if direction == "LONG":
                score += 10 if phase_strength < 70 else 15
                reasons.append("accumulation supports LONG")
            elif direction == "SHORT":
                score -= 15
                blockers.append("accumulation against SHORT" if phase_strength >= 70 else "phase conflict")
        elif phase_name == "DISTRIBUTION":
            if direction == "SHORT":
                score += 10 if phase_strength < 70 else 15
                reasons.append("distribution supports SHORT")
            elif direction == "LONG":
                score -= 15
                blockers.append("distribution against LONG" if phase_strength >= 70 else "phase conflict")
        elif phase_name == "MIXED_ABSORPTION":
            warnings.append("mixed absorption")
            score -= 5

        if quality == "DIVERGENCE":
            warnings.append("orderflow divergence")
            score -= 12

        if direction == "LONG" and absorption == "BUY_ABSORBED":
            blockers.append("buy absorption blocks LONG")
        if direction == "SHORT" and absorption == "SELL_ABSORBED":
            blockers.append("sell absorption blocks SHORT")

        # Pattern layer
        primary_pattern = (patterns.get("primary") or {}) if isinstance(patterns, dict) else {}
        pattern_list = (patterns.get("patterns") or []) if isinstance(patterns, dict) else []
        for p in pattern_list[:5]:
            ptype = p.get("type")
            pdir = p.get("direction")
            pstr = _i(p.get("strength"), 0)
            if pdir == direction and direction in ("LONG", "SHORT"):
                add = 8 if pstr < 75 else 14
                score += add
                reasons.append(f"pattern {ptype} supports {direction}")
            elif pdir in ("LONG", "SHORT") and direction in ("LONG", "SHORT") and pdir != direction:
                score -= 10
                warnings.append(f"pattern {ptype} conflicts")
            elif ptype == "COMPRESSION":
                warnings.append("compression needs breakout confirmation")
                score -= 2
            elif ptype == "RANGE_BOX":
                warnings.append("range box: avoid midpoint entries")
                score -= 4

        # Smart zone layer
        zone_ctx = smart_zones.get("context") if isinstance(smart_zones, dict) else None
        zone_adj = _i(smart_zones.get("adjustment"), 0) if isinstance(smart_zones, dict) else 0
        score += zone_adj
        if isinstance(smart_zones, dict):
            for b in (smart_zones.get("blockers") or []):
                blockers.append(str(b))
            for w in (smart_zones.get("warnings") or []):
                warnings.append(str(w))
            for r in (smart_zones.get("reasons") or []):
                reasons.append(str(r))
        if zone_ctx == "INSIDE_DANGER_ZONE":
            blockers.append("inside smart danger zone")
        elif zone_ctx == "BREAKOUT_ABOVE_ZONE" and direction == "LONG":
            reasons.append("smart zone breakout confirms LONG")
        elif zone_ctx == "BREAKDOWN_BELOW_ZONE" and direction == "SHORT":
            reasons.append("smart zone breakdown confirms SHORT")

        # News/risk layer
        if news_risk >= 85 or high_impact:
            blockers.append("high impact news risk")
            score -= 35
        elif news_risk >= 65:
            warnings.append("elevated news risk")
            score -= 15

        # Risk plan validation
        if risk.get("valid") is False:
            blockers.append("invalid trade structure")
        for err in (risk.get("errors") or []):
            blockers.append(str(err))
        for warn in (risk.get("warnings") or []):
            warnings.append(str(warn))

        entry = _f(risk.get("entry"))
        stop = _f(risk.get("stop"))
        tp1 = _f(risk.get("tp1"))
        tp2 = _f(risk.get("tp2"))
        rr1 = _f(risk.get("rr1"))
        ev = _f(risk.get("ev"), 0)

        if not entry or not stop or not tp1:
            blockers.append("missing entry/SL/TP")
        if rr1 and rr1 < 1.2:
            warnings.append("RR below 1.2")
            score -= 8
        if ev < 0:
            warnings.append("negative EV")
            score -= 8

        score = max(0, min(100, int(round(score))))

        if blockers:
            action = "BLOCKED"
            permission = False
        elif score >= 78 and confidence >= 65 and cf_score >= 65:
            action = "TRADE"
            permission = True
        elif score >= 58:
            action = "WAIT_RETEST"
            permission = False
        elif score >= 40:
            action = "WATCH"
            permission = False
        else:
            action = "SKIP"
            permission = False

        risk_label = "LOW"
        if news_risk >= 65 or len(warnings) >= 2:
            risk_label = "MEDIUM"
        if blockers or news_risk >= 85:
            risk_label = "HIGH"

        return {
            "ok": True,
            "mode": "PRO_TRADER",
            "score": score,
            "action": action,
            "permission": permission,
            "direction": direction,
            "risk_label": risk_label,
            "confidence": confidence,
            "confluence_score": cf_score,
            "confluence_grade": cf_grade,
            "phase": phase_name,
            "phase_strength": phase_strength,
            "flow": flow,
            "pattern_primary": primary_pattern.get("type") if isinstance(primary_pattern, dict) else None,
            "pattern_strength": primary_pattern.get("strength") if isinstance(primary_pattern, dict) else None,
            "smart_zone_context": smart_zones.get("context") if isinstance(smart_zones, dict) else None,
            "smart_zone_adjustment": smart_zones.get("adjustment") if isinstance(smart_zones, dict) else None,
            "news_risk": news_risk,
            "entry": entry,
            "stop": stop,
            "tp1": tp1,
            "tp2": tp2,
            "rr1": rr1,
            "ev": ev,
            "blockers": blockers,
            "warnings": warnings,
            "reasons": reasons[:10],
        }
    except Exception as e:
        return {
            "ok": False,
            "mode": "PRO_TRADER",
            "score": 0,
            "action": "SKIP",
            "permission": False,
            "risk_label": "ERROR",
            "blockers": [str(e)],
            "warnings": [],
            "reasons": [],
        }
