"""event_engine.py v8.6 — uses get_heatmap_signals, reduces server load"""
import threading, time

STATE = {}
HEAT  = []
_STARTED = False

def _get_scanner():
    try:
        from app.market_scanner import get_heatmap_signals
        return get_heatmap_signals
    except Exception as e:
        print("[event_engine] import error:", e)
        return None

def is_real_setup(prev, cur):
    if not prev: return False
    p_side = prev.get("direction") or prev.get("side","")
    c_side = cur.get("direction")  or cur.get("side","")
    p_conf = float(prev.get("confidence") or 0)
    c_conf = float(cur.get("confidence")  or 0)

    if c_side not in ("LONG","SHORT"): return False
    if c_side != p_side: return True
    if cur.get("choch") and not prev.get("choch"): return True
    if cur.get("has_sweep") and not prev.get("has_sweep"): return True
    if c_conf - p_conf >= 15: return True
    if cur.get("early_mode") == "EARLY" and prev.get("early_mode") != "EARLY": return True
    if cur.get("trap") and cur.get("trap") != "NONE" and prev.get("trap") != cur.get("trap"): return True
    return False

def monitor_loop():
    scanner = _get_scanner()
    if not scanner: return
    while True:
        try:
            rows = scanner(tf="15")
            for cur in rows:
                sym = cur.get("symbol")
                if not sym: continue
                prev = STATE.get(sym)
                if prev and is_real_setup(prev, cur):
                    HEAT.insert(0, {
                        "symbol":     sym,
                        "side":       cur.get("direction") or cur.get("side",""),
                        "confidence": cur.get("confidence", 0),
                        "rr":         cur.get("rr1") or cur.get("rr") or 0,
                        "setup":      cur.get("setup",""),
                        "trap":       cur.get("trap",""),
                        "early_mode": cur.get("early_mode",""),
                        "session":    cur.get("session",""),
                    })
                    HEAT[:] = HEAT[:30]
                STATE[sym] = cur
        except Exception as e:
            print("[event_engine] error:", e)
        time.sleep(30)  # было 20

def start():
    global _STARTED
    if _STARTED: return
    _STARTED = True
    threading.Thread(target=monitor_loop, daemon=True).start()
    print("[event_engine] started — interval 30s, limit 20 symbols")
