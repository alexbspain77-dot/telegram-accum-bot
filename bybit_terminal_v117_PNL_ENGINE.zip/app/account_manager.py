from __future__ import annotations
import json, time, hashlib, secrets
from pathlib import Path
from typing import Any, Dict, Optional

DATA_DIR = Path(__file__).resolve().parent / "data"
USERS_FILE = DATA_DIR / "users.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"

DEFAULT_WATCHLIST = ["BTCUSDT","ETHUSDT","SOLUSDT","XRPUSDT","BNBUSDT"]

def _ensure():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not USERS_FILE.exists(): USERS_FILE.write_text("{}", encoding="utf-8")
    if not SESSIONS_FILE.exists(): SESSIONS_FILE.write_text("{}", encoding="utf-8")

def _read(path: Path) -> Dict[str, Any]:
    _ensure()
    try: return json.loads(path.read_text(encoding="utf-8") or "{}")
    except Exception: return {}

def _write(path: Path, data: Dict[str, Any]):
    _ensure()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)

def _hash(password: str, salt: str) -> str:
    return hashlib.sha256((salt + "::" + str(password)).encode("utf-8")).hexdigest()

def normalize_symbol(s: str) -> str:
    s = str(s or "").upper().strip().replace("/","").replace("-","").replace(" ","")
    return s if s.endswith("USDT") else s + "USDT"

def create_session(username: str) -> str:
    sessions = _read(SESSIONS_FILE)
    token = secrets.token_urlsafe(32)
    sessions[token] = {"username": username, "created_at": int(time.time())}
    _write(SESSIONS_FILE, sessions)
    return token

def register_user(username: str, password: str, telegram_chat_id: str = "", telegram_enabled: bool = False) -> Dict[str, Any]:
    username = str(username or "").strip().lower()
    password = str(password or "")
    if len(username) < 3: return {"ok": False, "error": "username too short"}
    if len(password) < 4: return {"ok": False, "error": "password too short"}
    users = _read(USERS_FILE)
    if username in users: return {"ok": False, "error": "user already exists"}
    salt = secrets.token_hex(12)
    users[username] = {
        "username": username,
        "salt": salt,
        "password_hash": _hash(password, salt),
        "watchlist": DEFAULT_WATCHLIST[:],
        "telegram_chat_id": str(telegram_chat_id or "").strip(),
        "telegram_enabled": bool(telegram_enabled),
        "telegram_min_confidence": 65,
        "telegram_only_pro_trade": True,
        "created_at": int(time.time()),
        "updated_at": int(time.time()),
    }
    _write(USERS_FILE, users)
    token = create_session(username)
    return {"ok": True, "username": username, "token": token, "watchlist": users[username]["watchlist"], "telegram": telegram_state(users[username])}

def login_user(username: str, password: str) -> Dict[str, Any]:
    username = str(username or "").strip().lower()
    users = _read(USERS_FILE)
    u = users.get(username)
    if not u or _hash(password, u.get("salt","")) != u.get("password_hash"):
        return {"ok": False, "error": "invalid login"}
    token = create_session(username)
    return {"ok": True, "username": username, "token": token, "watchlist": u.get("watchlist", DEFAULT_WATCHLIST[:]), "telegram": telegram_state(u)}

def get_username(token: str) -> Optional[str]:
    if not token: return None
    sessions = _read(SESSIONS_FILE)
    s = sessions.get(token)
    return s.get("username") if s else None

def get_user(token: str) -> Optional[Dict[str, Any]]:
    username = get_username(token)
    if not username: return None
    return _read(USERS_FILE).get(username)

def logout_user(token: str) -> Dict[str, Any]:
    sessions = _read(SESSIONS_FILE)
    if token in sessions:
        sessions.pop(token, None)
        _write(SESSIONS_FILE, sessions)
    return {"ok": True}

def telegram_state(u: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "chat_id": u.get("telegram_chat_id",""),
        "enabled": bool(u.get("telegram_enabled", False)),
        "min_confidence": int(u.get("telegram_min_confidence", 65) or 65),
        "only_pro_trade": bool(u.get("telegram_only_pro_trade", True)),
    }

def get_profile(token: str) -> Dict[str, Any]:
    u = get_user(token)
    if not u: return {"ok": False, "error": "not authenticated"}
    return {"ok": True, "username": u["username"], "watchlist": u.get("watchlist", DEFAULT_WATCHLIST[:]), "telegram": telegram_state(u)}

def save_watchlist(token: str, symbols) -> Dict[str, Any]:
    username = get_username(token)
    if not username: return {"ok": False, "error": "not authenticated"}
    users = _read(USERS_FILE)
    clean = []
    for s in symbols or []:
        x = normalize_symbol(s)
        if x and x not in clean:
            clean.append(x)
    users[username]["watchlist"] = clean[:100]
    users[username]["updated_at"] = int(time.time())
    _write(USERS_FILE, users)
    return {"ok": True, "username": username, "watchlist": users[username]["watchlist"]}

def save_telegram(token: str, chat_id: str, enabled: bool, min_confidence: int = 65, only_pro_trade: bool = True) -> Dict[str, Any]:
    username = get_username(token)
    if not username: return {"ok": False, "error": "not authenticated"}
    users = _read(USERS_FILE)
    users[username]["telegram_chat_id"] = str(chat_id or "").strip()
    users[username]["telegram_enabled"] = bool(enabled)
    users[username]["telegram_min_confidence"] = max(0, min(100, int(min_confidence or 65)))
    users[username]["telegram_only_pro_trade"] = bool(only_pro_trade)
    users[username]["updated_at"] = int(time.time())
    _write(USERS_FILE, users)
    return {"ok": True, "username": username, "telegram": telegram_state(users[username])}

def all_users() -> Dict[str, Any]:
    return _read(USERS_FILE)
