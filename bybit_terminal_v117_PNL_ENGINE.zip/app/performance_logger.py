
import json, time, os

LOG_FILE = os.path.join("logs", "performance.jsonl")
os.makedirs("logs", exist_ok=True)

def log_signal(decision, report):
    entry = {
        "ts": time.time(),
        "decision": decision,
        "features": {
            "phase": report.get("phase",{}),
            "pattern": report.get("pattern",{}),
            "orderflow": report.get("orderflow",{}),
        },
        "result": None
    }
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
