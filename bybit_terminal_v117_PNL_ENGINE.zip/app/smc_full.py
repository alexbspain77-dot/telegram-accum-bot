"""
smc_full.py — полный набор SMC инструментов v8

Новое по сравнению с v7:
  - Order Blocks (последняя противоположная свеча перед импульсом)
  - Breaker Blocks (OB который был пробит → меняет полярность)
  - Equal Highs / Equal Lows (кластеры ликвидности)
  - Mitigation Zones (зоны где цена уже реагировала)
  - Session Ranges (Asia / London / NY high/low)
"""
from __future__ import annotations
import datetime
from typing import Any, Dict, List, Optional

# ── Session definitions (UTC hours) ──────────────────────────────
SESSION_DEF = {
    "ASIA":   (0,  8),
    "LONDON": (7,  16),
    "NY":     (13, 22),
}


# ── Order Blocks ──────────────────────────────────────────────────
def detect_order_blocks(candles: List[Dict[str, Any]],
                        lookback: int = 50) -> List[Dict[str, Any]]:
    """
    Order Block = последняя медвежья свеча перед бычьим импульсом (бычий OB)
                  или последняя бычья свеча перед медвежьим импульсом (медвежий OB).

    Критерии импульса: следующая свеча закрывается выше/ниже OB более чем на 0.5 ATR.
    """
    if len(candles) < 4:
        return []

    ranges = [float(c["high"]) - float(c["low"]) for c in candles[-30:]]
    atr = sum(ranges) / len(ranges) if ranges else 0.001
    threshold = atr * 0.5

    blocks: List[Dict[str, Any]] = []
    start = max(1, len(candles) - lookback - 2)

    for i in range(start, len(candles) - 2):
        c0 = candles[i]
        c1 = candles[i + 1]
        c2 = candles[i + 2] if i + 2 < len(candles) else None
        o0, c_0 = float(c0["open"]), float(c0["close"])
        o1, c_1 = float(c1["open"]), float(c1["close"])

        # Бычий OB: медвежья c0 → бычий c1 с импульсом вверх
        if c_0 < o0 and c_1 > o1 and (c_1 - o0) > threshold:
            low  = min(float(c0["low"]),  float(c0["open"]), float(c0["close"]))
            high = max(float(c0["high"]), float(c0["open"]), float(c0["close"]))
            # Проверяем — не пробит ли OB ещё
            future = candles[i + 2:]
            mitigated = any(float(fc["low"]) <= (low + high) / 2 for fc in future)
            blocks.append({
                "type":      "BULLISH_OB",
                "low":       round(low, 8),
                "high":      round(high, 8),
                "mid":       round((low + high) / 2, 8),
                "time":      c0["time"],
                "idx":       i,
                "mitigated": mitigated,
            })

        # Медвежий OB: бычья c0 → медвежий c1 с импульсом вниз
        if c_0 > o0 and c_1 < o1 and (o0 - c_1) > threshold:
            low  = min(float(c0["low"]),  float(c0["open"]), float(c0["close"]))
            high = max(float(c0["high"]), float(c0["open"]), float(c0["close"]))
            future = candles[i + 2:]
            mitigated = any(float(fc["high"]) >= (low + high) / 2 for fc in future)
            blocks.append({
                "type":      "BEARISH_OB",
                "low":       round(low, 8),
                "high":      round(high, 8),
                "mid":       round((low + high) / 2, 8),
                "time":      c0["time"],
                "idx":       i,
                "mitigated": mitigated,
            })

    return blocks[-16:]


# ── Breaker Blocks ────────────────────────────────────────────────
def detect_breaker_blocks(candles: List[Dict[str, Any]],
                          order_blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Breaker Block = Order Block который был пробит.
    После пробоя меняет полярность:
      бычий OB пробитый вниз → становится медвежьим Breaker
      медвежий OB пробитый вверх → становится бычьим Breaker
    """
    if not candles or not order_blocks:
        return []

    current = float(candles[-1]["close"])
    breakers: List[Dict[str, Any]] = []

    for ob in order_blocks:
        if ob.get("mitigated"):
            # OB уже пробит — смотрим в каком направлении
            if ob["type"] == "BULLISH_OB" and current < ob["low"]:
                breakers.append({
                    "type":      "BEARISH_BREAKER",
                    "low":       ob["low"],
                    "high":      ob["high"],
                    "mid":       ob["mid"],
                    "time":      ob["time"],
                    "origin_ob": ob["type"],
                })
            elif ob["type"] == "BEARISH_OB" and current > ob["high"]:
                breakers.append({
                    "type":      "BULLISH_BREAKER",
                    "low":       ob["low"],
                    "high":      ob["high"],
                    "mid":       ob["mid"],
                    "time":      ob["time"],
                    "origin_ob": ob["type"],
                })

    return breakers[-8:]


# ── Equal Highs / Equal Lows ──────────────────────────────────────
def detect_equal_levels(candles: List[Dict[str, Any]],
                        swings: List[Dict[str, Any]],
                        tolerance_pct: float = 0.002) -> Dict[str, Any]:
    """
    Equal Highs (EQH): два или более swing high в пределах tolerance_pct друг от друга.
    Equal Lows  (EQL): аналогично для swing lows.

    EQH/EQL = ликвидность, которую маркет-мейкер будет охотиться.
    """
    highs = sorted([s for s in swings if s["kind"] == "H"], key=lambda x: x["idx"])
    lows  = sorted([s for s in swings if s["kind"] == "L"], key=lambda x: x["idx"])

    def cluster(pts, kind):
        result = []
        used = set()
        for i, p in enumerate(pts):
            if i in used:
                continue
            group = [p]
            for j in range(i + 1, len(pts)):
                if j in used:
                    continue
                if abs(float(pts[j]["price"]) - float(p["price"])) / float(p["price"]) <= tolerance_pct:
                    group.append(pts[j])
                    used.add(j)
            if len(group) >= 2:
                price = sum(float(x["price"]) for x in group) / len(group)
                result.append({
                    "type":    kind,
                    "price":   round(price, 8),
                    "touches": len(group),
                    "last_idx": group[-1]["idx"],
                    "time":    group[-1]["time"],
                    "strength": min(100, len(group) * 30),
                })
        return result

    eqh = cluster(highs, "EQH")
    eql = cluster(lows,  "EQL")

    return {
        "equal_highs": sorted(eqh, key=lambda x: x["last_idx"], reverse=True)[:6],
        "equal_lows":  sorted(eql, key=lambda x: x["last_idx"], reverse=True)[:6],
    }


# ── Mitigation Zones ──────────────────────────────────────────────
def detect_mitigation_zones(candles: List[Dict[str, Any]],
                             order_blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Mitigation Zone = зона где цена уже реагировала на OB но не пробила его.
    Повторный визит = потенциальная точка входа.
    """
    zones = []
    for ob in order_blocks:
        if ob.get("mitigated"):
            continue
        # Проверяем — были ли уже реакции от этого OB
        reactions = 0
        for c in candles[ob["idx"]:]:
            lo, hi = float(c["low"]), float(c["high"])
            if ob["low"] <= lo <= ob["high"] or ob["low"] <= hi <= ob["high"]:
                reactions += 1
        if reactions >= 1:
            zones.append({
                **ob,
                "reactions": reactions,
                "zone_type": "MITIGATION",
            })
    return zones[-8:]


# ── Session Ranges ────────────────────────────────────────────────
def get_session_ranges(candles: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Для каждой сессии (Asia/London/NY) находит High/Low за последние 24ч.
    Session highs/lows = ликвидность, которую часто сметают при открытии следующей сессии.
    """
    now_utc = datetime.datetime.utcnow()
    today   = now_utc.date()

    sessions: Dict[str, Dict] = {
        "ASIA":   {"high": None, "low": None, "candles": 0},
        "LONDON": {"high": None, "low": None, "candles": 0},
        "NY":     {"high": None, "low": None, "candles": 0},
    }

    for c in candles[-200:]:
        ts = c["time"]
        if ts > 1e10:
            ts = ts / 1000
        dt = datetime.datetime.utcfromtimestamp(ts)
        if dt.date() < today - datetime.timedelta(days=1):
            continue

        h = dt.hour
        for name, (start, end) in SESSION_DEF.items():
            if start <= h < end:
                s = sessions[name]
                hi = float(c["high"])
                lo = float(c["low"])
                s["high"]   = max(s["high"], hi) if s["high"] else hi
                s["low"]    = min(s["low"],  lo) if s["low"]  else lo
                s["candles"] += 1
                break

    result = {}
    for name, data in sessions.items():
        if data["high"] and data["low"]:
            result[name] = {
                "high":    round(data["high"], 8),
                "low":     round(data["low"],  8),
                "range":   round(data["high"] - data["low"], 8),
                "candles": data["candles"],
                # Ликвидность над/под сессионными уровнями
                "liquidity_above": round(data["high"], 8),
                "liquidity_below": round(data["low"],  8),
            }

    return result


# ── Полный SMC отчёт ──────────────────────────────────────────────
def full_smc_report(candles: List[Dict[str, Any]],
                    swings:  List[Dict[str, Any]]) -> Dict[str, Any]:
    """Запускает все SMC детекторы и возвращает единый отчёт."""
    obs      = detect_order_blocks(candles)
    breakers = detect_breaker_blocks(candles, obs)
    eq_lvls  = detect_equal_levels(candles, swings)
    mit_zones= detect_mitigation_zones(candles, obs)
    sessions = get_session_ranges(candles)

    # Активные (не пробитые) OB рядом с ценой
    price = float(candles[-1]["close"]) if candles else 0
    active_obs = [ob for ob in obs if not ob.get("mitigated")]
    nearby_obs = sorted(active_obs, key=lambda ob: abs(ob["mid"] - price))[:4]

    return {
        "order_blocks":      obs[-12:],
        "active_obs":        nearby_obs,
        "breaker_blocks":    breakers,
        "equal_levels":      eq_lvls,
        "mitigation_zones":  mit_zones,
        "session_ranges":    sessions,
    }
