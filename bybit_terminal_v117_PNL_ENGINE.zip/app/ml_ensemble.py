
import numpy as np
from .ml_engine_v4 import predict_proba

def ensemble_predict(report):
    p1 = predict_proba(report)
    # fallback simple heuristic
    base = report.get("scenario", {}).get("confidence", 50) / 100

    if p1 is None:
        return base

    # ensemble: ML + heuristic
    return float((p1 * 0.7) + (base * 0.3))
