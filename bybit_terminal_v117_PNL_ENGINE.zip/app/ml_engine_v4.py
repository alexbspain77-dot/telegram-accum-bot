import os
import numpy as np

try:
    import joblib
except:
    joblib = None

MODEL_PATH = os.path.join(os.path.dirname(__file__), "ml_model.pkl")
_model = None

def load_model():
    global _model
    if _model is None and joblib and os.path.exists(MODEL_PATH):
        try:
            _model = joblib.load(MODEL_PATH)
        except:
            _model = None
    return _model

def encode_features(report):
    return [
        report.get("phase", {}).get("strength", 0) / 100,
        report.get("orderflow", {}).get("institutional_score", 50) / 100,
        report.get("risk", {}).get("rr1", 1),
    ]

def predict_proba(report):
    try:
        model = load_model()
        if model is None:
            return None
        X = np.array([encode_features(report)])
        return float(model.predict_proba(X)[0][1])
    except:
        return None
