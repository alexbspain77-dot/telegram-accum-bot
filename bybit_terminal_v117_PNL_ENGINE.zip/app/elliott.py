from typing import List, Dict, Any
from .smc import find_swings


def find_pivots(candles: List[Dict[str, Any]], left: int = 7, right: int = 7):
    # High/low pivots, not close pivots. Larger default lookback reduces noise.
    return find_swings(candles, left=left, right=right)[-14:]


def _len(a, b) -> float:
    return abs(float(b["price"]) - float(a["price"]))


def _valid_impulse(p: List[Dict[str, Any]], up: bool) -> Dict[str, Any]:
    prices = [float(x["price"]) for x in p]
    w1 = _len(p[0], p[1])
    w2 = _len(p[1], p[2])
    w3 = _len(p[2], p[3])
    w4 = _len(p[3], p[4])
    w5 = _len(p[4], p[5])
    if min(w1, w2, w3, w4, w5) <= 0:
        return {"ok": False, "reason": "zero wave length"}
    # Elliott rules: wave 2 cannot retrace beyond wave 1 start.
    if up and prices[2] <= prices[0]:
        return {"ok": False, "reason": "wave 2 overlaps start of wave 1"}
    if (not up) and prices[2] >= prices[0]:
        return {"ok": False, "reason": "wave 2 overlaps start of wave 1"}
    # Wave 3 cannot be shortest among motive waves.
    if w3 < min(w1, w5):
        return {"ok": False, "reason": "wave 3 shortest"}
    # Wave 4 should not overlap wave 1 price territory in classic impulse.
    if up and prices[4] <= prices[1]:
        return {"ok": False, "reason": "wave 4 overlaps wave 1"}
    if (not up) and prices[4] >= prices[1]:
        return {"ok": False, "reason": "wave 4 overlaps wave 1"}

    extended = ""
    if w3 >= max(w1, w5) * 1.55:
        extended = "extended wave 3"
    elif w5 >= max(w1, w3) * 1.55:
        extended = "extended wave 5"
    elif w1 >= max(w3, w5) * 1.55:
        extended = "extended wave 1"
    return {"ok": True, "note": extended or "valid impulse rules", "lengths": {"w1": w1, "w3": w3, "w5": w5}}


def detect_elliott(candles: List[Dict[str, Any]]):
    pivots = find_pivots(candles)
    if len(pivots) < 4:
        return {"type": "NONE", "points": [], "labels": [], "note": "not enough pivots"}

    # Try impulse from last 6 alternating swing points: start + 1..5.
    if len(pivots) >= 6:
        for p in [pivots[-6:], pivots[-7:-1] if len(pivots) >= 7 else pivots[-6:]]:
            if len(p) != 6:
                continue
            kinds = ''.join(x["kind"] for x in p)
            prices = [float(x["price"]) for x in p]
            up = kinds in ("LHLHLH",) and prices[0] < prices[1] and prices[2] < prices[3] and prices[4] < prices[5]
            down = kinds in ("HLHLHL",) and prices[0] > prices[1] and prices[2] > prices[3] and prices[4] > prices[5]
            if up or down:
                check = _valid_impulse(p, up)
                if check["ok"]:
                    return {"type": "IMPULSE_LONG" if up else "IMPULSE_SHORT", "points": p[1:], "labels": ["1","2","3","4","5"], "note": check["note"], "meta": check.get("lengths", {})}

    # ABC correction from last 4 pivots: start A B C.
    p = pivots[-4:]
    kinds = ''.join(x["kind"] for x in p)
    prices = [float(x["price"]) for x in p]
    abc_down = kinds == "HLHL" and prices[0] > prices[1] and prices[2] > prices[3]  # correction down
    abc_up = kinds == "LHLH" and prices[0] < prices[1] and prices[2] < prices[3]    # correction up
    if abc_down or abc_up:
        a = _len(p[0], p[1]); c = _len(p[2], p[3])
        note = "abc correction candidate"
        if c >= a * 1.55:
            note = "extended C wave"
        return {"type": "ABC_SHORT" if abc_down else "ABC_LONG", "points": p[1:], "labels": ["A","B","C"], "note": note, "meta": {"A": a, "C": c}}

    return {"type": "NONE", "points": pivots[-5:], "labels": [], "note": "no valid Elliott pattern"}
