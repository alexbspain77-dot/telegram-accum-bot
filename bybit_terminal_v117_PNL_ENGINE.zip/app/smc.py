from typing import List, Dict, Any, Optional


def find_swings(candles: List[Dict[str, Any]], left: int = 5, right: int = 5) -> List[Dict[str, Any]]:
    swings: List[Dict[str, Any]] = []
    if len(candles) < left + right + 1:
        return swings
    for i in range(left, len(candles) - right):
        h = float(candles[i]["high"])
        l = float(candles[i]["low"])
        left_part = candles[i-left:i]
        right_part = candles[i+1:i+right+1]
        if h > max(float(c["high"]) for c in left_part) and h >= max(float(c["high"]) for c in right_part):
            swings.append({"idx": i, "time": candles[i]["time"], "price": h, "kind": "H"})
        if l < min(float(c["low"]) for c in left_part) and l <= min(float(c["low"]) for c in right_part):
            swings.append({"idx": i, "time": candles[i]["time"], "price": l, "kind": "L"})
    swings.sort(key=lambda x: x["idx"])

    cleaned: List[Dict[str, Any]] = []
    for p in swings:
        if not cleaned or cleaned[-1]["kind"] != p["kind"]:
            cleaned.append(p)
        else:
            last = cleaned[-1]
            if (p["kind"] == "H" and p["price"] > last["price"]) or (p["kind"] == "L" and p["price"] < last["price"]):
                cleaned[-1] = p
    return cleaned


def market_structure(candles: List[Dict[str, Any]], swings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    swings = swings if swings is not None else find_swings(candles)
    highs = [s for s in swings if s["kind"] == "H"]
    lows = [s for s in swings if s["kind"] == "L"]
    if len(highs) < 2 or len(lows) < 2:
        return {"structure": "NEUTRAL", "detail": "not enough swings", "last_high": highs[-1] if highs else None, "last_low": lows[-1] if lows else None}
    hh = highs[-1]["price"] > highs[-2]["price"]
    hl = lows[-1]["price"] > lows[-2]["price"]
    lh = highs[-1]["price"] < highs[-2]["price"]
    ll = lows[-1]["price"] < lows[-2]["price"]
    if hh and hl:
        structure = "LONG"; detail = "HH/HL"
    elif lh and ll:
        structure = "SHORT"; detail = "LH/LL"
    else:
        structure = "NEUTRAL"; detail = "mixed swings"
    return {"structure": structure, "detail": detail, "last_high": highs[-1], "last_low": lows[-1], "swings": swings[-20:]}


def detect_bos_choch(candles: List[Dict[str, Any]], swings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    swings = swings if swings is not None else find_swings(candles)
    ms = market_structure(candles, swings)
    if not candles or not ms.get("last_high") or not ms.get("last_low"):
        return {"event": "NONE", "direction": "NEUTRAL", "markers": []}
    last_close = float(candles[-1]["close"])
    last_time = candles[-1]["time"]
    last_high = ms["last_high"]["price"]
    last_low = ms["last_low"]["price"]
    markers = []
    event = "NONE"; direction = "NEUTRAL"
    if last_close > last_high:
        direction = "LONG"
        event = "BOS" if ms["structure"] == "LONG" else "CHoCH"
        markers.append({"time": last_time, "position": "aboveBar", "color": "#22c55e", "shape": "arrowUp", "text": f"{event}↑"})
    elif last_close < last_low:
        direction = "SHORT"
        event = "BOS" if ms["structure"] == "SHORT" else "CHoCH"
        markers.append({"time": last_time, "position": "belowBar", "color": "#ef4444", "shape": "arrowDown", "text": f"{event}↓"})
    return {"event": event, "direction": direction, "markers": markers, "structure_detail": ms["detail"]}


def detect_fvg(candles: List[Dict[str, Any]], lookback: int = 80) -> List[Dict[str, Any]]:
    """Detect simple 3-candle fair value gaps.

    Bullish FVG: current low > high two candles back.
    Bearish FVG: current high < low two candles back.
    """
    zones: List[Dict[str, Any]] = []
    start = max(2, len(candles) - lookback)
    for i in range(start, len(candles)):
        c0 = candles[i - 2]
        c2 = candles[i]
        if float(c2["low"]) > float(c0["high"]):
            zones.append({"type": "BULLISH_FVG", "time": c2["time"], "low": float(c0["high"]), "high": float(c2["low"]), "mid": (float(c0["high"]) + float(c2["low"])) / 2})
        elif float(c2["high"]) < float(c0["low"]):
            zones.append({"type": "BEARISH_FVG", "time": c2["time"], "low": float(c2["high"]), "high": float(c0["low"]), "mid": (float(c2["high"]) + float(c0["low"])) / 2})
    return zones[-10:]


def swing_stop_targets(candles: List[Dict[str, Any]], direction: str, entry: float, swings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, float]:
    swings = swings if swings is not None else find_swings(candles)
    lows = [s for s in swings if s["kind"] == "L"]
    highs = [s for s in swings if s["kind"] == "H"]
    if not candles:
        risk = entry * 0.006
        return {"stop": entry - risk if direction == "LONG" else entry + risk, "tp1": entry + risk*1.5 if direction == "LONG" else entry - risk*1.5, "tp2": entry + risk*2.5 if direction == "LONG" else entry - risk*2.5}
    recent_range = max(float(c["high"]) for c in candles[-20:]) - min(float(c["low"]) for c in candles[-20:])
    buffer = max(entry * 0.0015, recent_range * 0.08)
    if direction == "LONG":
        swing = lows[-1]["price"] if lows else min(float(c["low"]) for c in candles[-20:])
        stop = min(swing - buffer, entry - entry * 0.002)
        risk = max(entry - stop, entry * 0.002)
        return {"stop": stop, "tp1": entry + risk * 1.5, "tp2": entry + risk * 2.5}
    if direction == "SHORT":
        swing = highs[-1]["price"] if highs else max(float(c["high"]) for c in candles[-20:])
        stop = max(swing + buffer, entry + entry * 0.002)
        risk = max(stop - entry, entry * 0.002)
        return {"stop": stop, "tp1": entry - risk * 1.5, "tp2": entry - risk * 2.5}
    return {"stop": None, "tp1": None, "tp2": None}
