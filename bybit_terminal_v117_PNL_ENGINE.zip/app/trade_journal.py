"""
trade_journal.py v8.6 — persistent storage fix

Проблема: trades.json терял данные после перезапуска потому что:
1. Путь вычислялся относительно __file__ — работает только если запуск из папки проекта
2. Нет атомарной записи — при краше в момент записи файл мог повредиться

Исправления:
1. Путь вычисляется через main.py директорию (PROJECT_ROOT)
2. Атомарная запись через tmp-файл → rename
3. Резервная копия перед каждой записью
4. Поддержка обоих форматов полей (side/direction, entry/entry_price и т.д.)
"""
from __future__ import annotations
import os, json, uuid, shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Определяем путь надёжно ──────────────────────────────────────
# Ищем папку data рядом с корнем проекта (где main.py)
def _find_data_dir() -> Path:
    # Попробуем несколько вариантов
    candidates = [
        Path(__file__).resolve().parent.parent / "data",   # app/../data
        Path(os.getcwd()) / "data",                         # cwd/data
        Path(os.environ.get("BYBIT_DATA_DIR", "")) if os.environ.get("BYBIT_DATA_DIR") else None,
    ]
    for p in candidates:
        if p is not None:
            try:
                p.mkdir(parents=True, exist_ok=True)
                # Проверяем что можем записать
                test = p / ".write_test"
                test.write_text("ok"); test.unlink()
                return p
            except Exception:
                continue
    # Абсолютный fallback
    fb = Path.home() / ".bybit_terminal" / "data"
    fb.mkdir(parents=True, exist_ok=True)
    return fb

DATA_DIR = _find_data_dir()
FILE     = DATA_DIR / "trades.json"
BACKUP   = DATA_DIR / "trades.backup.json"

print(f"[trade_journal] data dir: {DATA_DIR}")

def _now_ts() -> int:
    return int(datetime.utcnow().timestamp())

def _read() -> List[Dict[str, Any]]:
    # Читаем основной файл, при ошибке — backup
    for path in [FILE, BACKUP]:
        try:
            if not path.exists(): continue
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list): return data
        except Exception as e:
            print(f"[trade_journal] read error {path}: {e}")
    return []

def _write(items: List[Dict[str, Any]]):
    """Атомарная запись: пишем во временный файл, потом переименовываем."""
    try:
        # Бэкап текущего файла
        if FILE.exists():
            shutil.copy2(FILE, BACKUP)
        # Атомарная запись
        tmp = DATA_DIR / "trades.tmp.json"
        tmp.write_text(json.dumps(items, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        tmp.replace(FILE)
    except Exception as e:
        print(f"[trade_journal] write error: {e}")
        # Fallback: прямая запись
        try:
            FILE.write_text(json.dumps(items, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        except Exception as e2:
            print(f"[trade_journal] fallback write error: {e2}")

# Алиас для обратной совместимости
def _load() -> List[Dict[str, Any]]:
    return _read()

def open_trade(payload: Dict[str, Any], snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    trades = _read()

    # Принимаем оба варианта имён полей
    symbol    = str(payload.get("symbol") or "").upper()
    direction = str(payload.get("direction") or payload.get("side") or "LONG").upper()
    size_usd  = float(payload.get("size_usd") or payload.get("amount") or payload.get("size") or 0)
    entry     = float(payload.get("entry_price") or payload.get("entry") or 0)
    stop_p    = float(payload.get("stop") or payload.get("stop_loss") or 0)
    tp1       = float(payload.get("tp1") or payload.get("take_profit") or 0)
    note      = str(payload.get("note") or payload.get("comment") or payload.get("reason") or "")
    tf        = str(payload.get("tf") or "15")

    snap       = snapshot or {}
    setup      = str(snap.get("scenario", {}).get("setup") or payload.get("setup") or "MANUAL")
    early      = bool(snap.get("early_signal", {}).get("mode") == "EARLY")
    confidence = snap.get("scenario", {}).get("confidence")

    # RR
    rr1 = None
    if entry and stop_p and tp1 and abs(entry - stop_p) > 0:
        rr1 = round(abs(tp1 - entry) / abs(entry - stop_p), 2)

    trade: Dict[str, Any] = {
        "id":          str(uuid.uuid4())[:8],
        "symbol":      symbol,
        "direction":   direction,
        "size_usd":    size_usd,
        "entry_price": entry,
        "stop":        stop_p,
        "tp1":         tp1,
        "rr1":         rr1,
        "note":        note,
        "tf":          tf,
        "setup":       setup,
        "early":       early,
        "status":      "OPEN",
        "pnl_usd":     None,
        "result":      None,
        "close_price": None,
        "opened_at":   _now_ts(),
        "closed_at":   None,
        "snapshot": {
            "confidence": confidence,
            "session":    snap.get("session"),
            "mtf_bias":   snap.get("mtf", {}).get("bias"),
            "structure":  snap.get("smc", {}).get("structure", {}).get("detail"),
        },
    }
    trades.append(trade)
    _write(trades)
    print(f"[trade_journal] opened trade {trade['id']} {symbol} {direction} @ {entry}")
    return trade

def close_trade(trade_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    trades = _read()
    for t in trades:
        if str(t.get("id")) == str(trade_id):
            close_price = float(
                payload.get("close_price") or payload.get("exit_price") or
                payload.get("exit") or 0
            )
            entry     = float(t.get("entry_price") or t.get("entry") or 0)
            size_usd  = float(t.get("size_usd") or t.get("amount") or 0)
            direction = str(t.get("direction") or t.get("side") or "LONG").upper()

            pnl_usd = None
            if entry and close_price and size_usd:
                pnl_pct = (close_price - entry) / entry
                if direction == "SHORT":
                    pnl_pct = -pnl_pct
                pnl_usd = round(pnl_pct * size_usd, 4)

            result = payload.get("result")
            if result is None and pnl_usd is not None:
                result = "WIN" if pnl_usd > 0 else "LOSS"

            t.update({
                "status":      "CLOSED",
                "close_price": close_price,
                "pnl_usd":     pnl_usd,
                "result":      result,
                "closed_at":   _now_ts(),
                "close_note":  str(payload.get("note") or payload.get("comment") or ""),
            })
            _write(trades)
            print(f"[trade_journal] closed {trade_id} pnl=${pnl_usd} result={result}")
            return t
    raise ValueError(f"trade {trade_id} not found")

def stats() -> Dict[str, Any]:
    items  = _read()
    closed = [t for t in items if t.get("status") == "CLOSED"]
    wins   = [t for t in closed if t.get("result") == "WIN"]
    total_pnl = sum(float(t.get("pnl_usd") or 0) for t in closed)
    return {
        "total":   len(items),
        "open":    len([t for t in items if t.get("status") == "OPEN"]),
        "closed":  len(closed),
        "wins":    len(wins),
        "losses":  len(closed) - len(wins),
        "winrate": round(len(wins) / len(closed) * 100, 1) if closed else 0,
        "pnl_usd": round(total_pnl, 2),
    }
