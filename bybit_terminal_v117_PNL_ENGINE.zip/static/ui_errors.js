/*
UI Error Dashboard v1
- Captures runtime errors, promise errors, fetch failures/latency
- Stores last 100 events in localStorage
- Exposes UIErrors.render()
*/
(function(){
  if(window.UIErrors) return;
  const KEY='bt_ui_errors_v1';
  const MAX=100;

  function now(){return new Date().toLocaleTimeString();}
  function load(){
    try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return []}
  }
  function save(list){
    try{localStorage.setItem(KEY, JSON.stringify((list||[]).slice(0,MAX)))}catch(e){}
  }
  function add(type, message, meta){
    const list=load();
    list.unshift({ts:now(), type:type||'error', message:String(message||''), meta:meta||{}});
    save(list);
    try{ renderBadge(); }catch(e){}
    try{ console.warn('[UIErrors]', type, message, meta||{}); }catch(e){}
  }
  function clear(){ save([]); renderBadge(); }
  function list(){ return load(); }

  function renderBadge(){
    const el=document.getElementById('uiErrBadge');
    if(!el) return;
    const n=load().length;
    el.textContent=n?String(n):'';
    el.style.display=n?'inline-flex':'none';
  }

  function render(containerId){
    const el=document.getElementById(containerId||'rightContent');
    if(!el) return;
    const rows=load();
    el.innerHTML = `
      <div class="sec">
        <div class="sec-t">ERROR DASHBOARD</div>
        <div class="kv"><span class="kv-l">Events</span><span class="kv-v">${rows.length}</span></div>
        <button class="theme-btn" onclick="UIErrors.clear();UIErrors.render('${containerId||'rightContent'}')">Clear</button>
      </div>
      <div class="sec">
        <div class="sec-t">Recent errors</div>
        ${rows.length?rows.map(e=>`
          <div style="border-bottom:1px solid var(--border);padding:6px 0">
            <div style="font-size:10px;color:${e.type==='fetch'?'var(--amber)':'var(--red)'};font-weight:800">${e.ts} · ${e.type}</div>
            <div style="font-size:10px;color:var(--text);word-break:break-word">${escapeHtml(e.message)}</div>
            ${e.meta&&Object.keys(e.meta).length?`<pre style="white-space:pre-wrap;font-size:9px;color:var(--muted);margin:4px 0 0">${escapeHtml(JSON.stringify(e.meta,null,2)).slice(0,700)}</pre>`:''}
          </div>`).join(''):'<div style="font-size:10px;color:var(--muted)">No UI errors</div>'}
      </div>`;
  }

  function escapeHtml(s){
    return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  // Global capture
  window.addEventListener('error', e=>{
    add('runtime', e.message || (e.error&&e.error.message) || 'runtime error', {file:e.filename,line:e.lineno,col:e.colno});
  });
  window.addEventListener('unhandledrejection', e=>{
    add('promise', (e.reason&&e.reason.message)||e.reason||'unhandled promise');
  });

  // Patch fetch once
  if(!window.__uiErrorsFetchPatched){
    window.__uiErrorsFetchPatched=true;
    const origFetch=window.fetch.bind(window);
    window.fetch=async function(input, init){
      const url=String(input&&input.url||input);
      const t0=performance.now();
      try{
        const res=await origFetch(input, init);
        const ms=Math.round(performance.now()-t0);
        if(!res.ok) add('fetch', `HTTP ${res.status}: ${url}`, {latency_ms:ms});
        else if(ms>5000) add('latency', `Slow API: ${url}`, {latency_ms:ms});
        return res;
      }catch(e){
        add('fetch', `${url}: ${e.message||e}`, {});
        throw e;
      }
    };
  }

  window.UIErrors={add,clear,list,render,renderBadge};
  document.addEventListener('DOMContentLoaded', renderBadge);
})();
