/*
Cloud Account + Watchlist + Telegram v1
- Login/register with server profile
- Cloud watchlist sync
- Telegram signal settings
*/
(function(){
  if(window.CloudAccount) return;
  const TOKEN_KEY='bt_token';
  const USER_KEY='bt_username';

  function token(){ return localStorage.getItem(TOKEN_KEY)||''; }
  function setToken(t){ if(t) localStorage.setItem(TOKEN_KEY,t); }
  function clear(){ localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); }

  async function api(path, opts){
    opts=opts||{};
    const headers=Object.assign({'Content-Type':'application/json'}, opts.headers||{});
    const t=token(); if(t) headers['X-Auth-Token']=t;
    const r=await fetch(path,Object.assign({},opts,{headers}));
    return await r.json();
  }

  function localWatchlist(){
    try{
      const a=JSON.parse(localStorage.getItem('wl')||'[]');
      if(Array.isArray(a)&&a.length)return a;
      const b=JSON.parse(localStorage.getItem('watchlist')||'[]');
      return Array.isArray(b)?b:[];
    }catch(e){return []}
  }
  function saveLocalWatchlist(wl){
    wl=Array.isArray(wl)?wl:[];
    localStorage.setItem('wl',JSON.stringify(wl));
    localStorage.setItem('watchlist',JSON.stringify(wl));
    try{ if(window.TerminalState) TerminalState.patch({watchlist:wl}); }catch(e){}
  }

  async function me(){
    try{
      const d=await api('/api/account/me');
      if(d.ok){
        localStorage.setItem(USER_KEY,d.username);
        if(Array.isArray(d.watchlist)) saveLocalWatchlist(d.watchlist);
      }
      return d;
    }catch(e){return {ok:false,error:e.message}}
  }

  async function register(username,password,telegram_chat_id,telegram_enabled){
    const d=await api('/api/account/register',{method:'POST',body:JSON.stringify({username,password,telegram_chat_id,telegram_enabled})});
    if(d.ok){setToken(d.token);localStorage.setItem(USER_KEY,d.username);if(Array.isArray(d.watchlist))saveLocalWatchlist(d.watchlist);}
    return d;
  }
  async function login(username,password){
    const d=await api('/api/account/login',{method:'POST',body:JSON.stringify({username,password})});
    if(d.ok){setToken(d.token);localStorage.setItem(USER_KEY,d.username);if(Array.isArray(d.watchlist))saveLocalWatchlist(d.watchlist);}
    return d;
  }
  async function logout(){
    try{await api('/api/account/logout',{method:'POST'});}catch(e){}
    clear();
  }
  async function loadWatchlist(){
    if(!token())return {ok:false,local:true,watchlist:localWatchlist()};
    const d=await api('/api/watchlist');
    if(d.ok&&Array.isArray(d.watchlist))saveLocalWatchlist(d.watchlist);
    return d;
  }
  async function saveWatchlist(wl){
    saveLocalWatchlist(wl);
    if(!token())return {ok:false,local:true,watchlist:wl};
    return await api('/api/watchlist',{method:'POST',body:JSON.stringify({watchlist:wl})});
  }
  async function saveTelegram(settings){
    return await api('/api/telegram/settings',{method:'POST',body:JSON.stringify(settings||{})});
  }
  async function testTelegram(){
    return await api('/api/telegram/test',{method:'POST'});
  }
  async function sendSignal(symbol, signal){
    return await api('/api/telegram/send_signal',{method:'POST',body:JSON.stringify({symbol,signal})});
  }
  function username(){return localStorage.getItem(USER_KEY)||''}

  window.CloudAccount={token,username,me,register,login,logout,loadWatchlist,saveWatchlist,saveTelegram,testTelegram,sendSignal,localWatchlist,saveLocalWatchlist};
})();
