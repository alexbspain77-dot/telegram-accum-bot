/*
Stable UI Core v1
- global JS error boundary
- safeFetch with timeout
- safeRun wrappers
- status overlay
- prevents one render bug from freezing the terminal
*/
(function(){
  if(window.StableUI) return;

  const state = {
    errors: [],
    lastError: null,
    maxErrors: 20
  };

  function ensureOverlay(){
    let box = document.getElementById('stableUiOverlay');
    if(box) return box;
    box = document.createElement('div');
    box.id = 'stableUiOverlay';
    box.style.cssText = [
      'position:fixed',
      'left:10px',
      'bottom:10px',
      'z-index:999999',
      'max-width:520px',
      'display:none',
      'background:rgba(15,23,42,.92)',
      'color:#e8f0ff',
      'border:1px solid rgba(239,68,68,.35)',
      'border-radius:10px',
      'padding:8px 10px',
      'font:12px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif',
      'box-shadow:0 12px 40px rgba(0,0,0,.35)'
    ].join(';');
    if(!document.body) return box;
    document.body.appendChild(box);
    return box;
  }

  function showError(label, err){
    const msg = (err && (err.message || err.toString())) || String(err || 'Unknown error');
    state.lastError = {label, msg, ts: new Date().toLocaleTimeString()};
    state.errors.unshift(state.lastError);
    state.errors = state.errors.slice(0, state.maxErrors);

    try{
      const box = ensureOverlay();
      box.style.display = 'block';
      box.innerHTML = `
        <div style="display:flex;gap:8px;align-items:center;justify-content:space-between">
          <b style="color:#f87171">UI warning</b>
          <button onclick="document.getElementById('stableUiOverlay').style.display='none'"
            style="background:transparent;color:#94a3b8;border:0;cursor:pointer">×</button>
        </div>
        <div style="margin-top:4px;color:#cbd5e1">${escapeHtml(label)}: ${escapeHtml(msg)}</div>
      `;
      clearTimeout(box.__hideTimer);
      box.__hideTimer = setTimeout(()=>{ try{box.style.display='none'}catch(e){} }, 7000);
    }catch(e){}
    try{ console.error('[StableUI]', label, err); }catch(e){}
  }

  function escapeHtml(s){
    return String(s||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  async function safeFetch(url, opts){
    opts = opts || {};
    const timeout = opts.timeout || 12000;
    const ctrl = new AbortController();
    const timer = setTimeout(()=>ctrl.abort(), timeout);
    try{
      const res = await fetch(url, Object.assign({}, opts, {signal: ctrl.signal}));
      clearTimeout(timer);
      if(!res.ok) throw new Error('HTTP '+res.status+' '+url);
      return await res.json();
    }catch(e){
      clearTimeout(timer);
      const isAbort = e && (e.name === 'AbortError' || String(e.message||e).toLowerCase().includes('abort'));
      if(!isAbort) showError('fetch failed', e);
      throw e;
    }
  }

  function safeRun(label, fn, fallback){
    try{
      return fn();
    }catch(e){
      showError(label, e);
      return typeof fallback === 'function' ? fallback(e) : fallback;
    }
  }

  async function safeAsync(label, fn, fallback){
    try{
      return await fn();
    }catch(e){
      showError(label, e);
      return typeof fallback === 'function' ? fallback(e) : fallback;
    }
  }

  function setText(id, text){
    const el = document.getElementById(id);
    if(el) el.textContent = text;
  }

  function setHTML(id, html){
    const el = document.getElementById(id);
    if(el) el.innerHTML = html;
  }

  function safeSymbol(symbol){
    symbol = String(symbol || 'BTCUSDT').toUpperCase().replace(/[\/\-\s]/g,'');
    return symbol.endsWith('USDT') ? symbol : symbol + 'USDT';
  }

  window.StableUI = {
    state,
    showError,
    safeFetch,
    safeRun,
    safeAsync,
    setText,
    setHTML,
    safeSymbol
  };

  window.addEventListener('error', function(e){
    showError('runtime', e.error || e.message);
  });
  window.addEventListener('unhandledrejection', function(e){
    showError('promise', e.reason || 'Unhandled promise rejection');
  });

  document.addEventListener('DOMContentLoaded', function(){
    ensureOverlay();
  });
})();
