/*
Terminal State Manager v1
Single source of truth across Dashboard / Chart / Journal windows.
- localStorage persistence
- BroadcastChannel sync
- unified UI router helpers
*/
(function(){
  const KEY = 'bybit_terminal_state_v1';
  const DEFAULT_STATE = {
    symbol: 'BTCUSDT',
    tf: '15',
    view: 'dashboard',
    theme: 'dark',
    activeTab: 'structure',
    watchlist: ['BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','BNBUSDT'],
    updatedAt: Date.now()
  };

  function safeParse(raw){
    try { return JSON.parse(raw || '{}'); } catch(e){ return {}; }
  }
  function load(){
    return Object.assign({}, DEFAULT_STATE, safeParse(localStorage.getItem(KEY)));
  }
  function save(next){
    const s = Object.assign({}, load(), next || {}, {updatedAt: Date.now()});
    localStorage.setItem(KEY, JSON.stringify(s));
    try { window.__terminalBC && window.__terminalBC.postMessage({type:'state', state:s}); } catch(e){}
    return s;
  }

  window.TerminalState = {
    key: KEY,
    get: load,
    set: save,
    patch: save,
    getSymbol(){ return load().symbol || 'BTCUSDT'; },
    getTf(){ return String(load().tf || '15'); },
    setSymbol(symbol){
      symbol = String(symbol || 'BTCUSDT').toUpperCase().replace(/[\/-]/g,'');
      if(!symbol.endsWith('USDT')) symbol += 'USDT';
      return save({symbol});
    },
    setTf(tf){ return save({tf:String(tf || '15')}); },
    setTheme(theme){
      theme = theme === 'light' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', theme);
      return save({theme});
    },
    applyTheme(){
      const s = load();
      document.documentElement.setAttribute('data-theme', s.theme || 'dark');
    },
    onChange(fn){
      window.addEventListener('terminal-state-change', e => fn(e.detail));
    }
  };

  try {
    window.__terminalBC = new BroadcastChannel('bybit_terminal_state');
    window.__terminalBC.onmessage = (e)=>{
      if(!e || !e.data || e.data.type !== 'state') return;
      localStorage.setItem(KEY, JSON.stringify(e.data.state));
      window.dispatchEvent(new CustomEvent('terminal-state-change', {detail:e.data.state}));
    };
  } catch(e){}

  window.openTerminalChart = function(symbol, tf){
    const s = TerminalState.setSymbol(symbol || TerminalState.getSymbol());
    TerminalState.setTf(tf || s.tf || TerminalState.getTf());
    window.open(`/ui?view=chart&symbol=${encodeURIComponent(s.symbol)}&tf=${encodeURIComponent(tf || s.tf || '15')}`, '_blank', 'width=1450,height=920');
  };
  window.openTerminalJournal = function(){
    TerminalState.patch({view:'journal'});
    window.open('/ui?view=journal', '_blank', 'width=1250,height=850');
  };
  window.openTerminalNews = function(){
    TerminalState.patch({view:'news'});
    window.open('/ui?view=news', '_blank', 'width=1250,height=850');
  };

  TerminalState.applyTheme();
})();
