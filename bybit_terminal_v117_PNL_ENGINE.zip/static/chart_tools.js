/*
Chart Tools v1 — lightweight drawing tools for Bybit Terminal
Tools:
- cursor
- horizontal line
- trend line
- box / zone
- clear
Drawings are stored per symbol in localStorage.
*/
(function(){
  if(window.ChartTools) return;

  const LS_KEY = 'bybit_chart_tools_v1';

  const state = {
    chart: null,
    series: null,
    container: null,
    canvas: null,
    ctx: null,
    toolbar: null,
    mode: 'cursor',
    drawings: [],
    draft: null,
    getSymbol: ()=>'BTCUSDT',
    raf: null,
  };

  function readAll(){
    try{return JSON.parse(localStorage.getItem(LS_KEY)||'{}')}catch(e){return {}}
  }
  function writeAll(all){
    localStorage.setItem(LS_KEY, JSON.stringify(all||{}));
  }
  function symbolKey(){
    try{return String(state.getSymbol()||'BTCUSDT').toUpperCase()}catch(e){return 'BTCUSDT'}
  }
  function load(){
    const all=readAll();
    state.drawings = Array.isArray(all[symbolKey()]) ? all[symbolKey()] : [];
    state.draft = null;
    requestDraw();
  }
  function save(){
    const all=readAll();
    all[symbolKey()] = state.drawings;
    writeAll(all);
  }
  function setMode(mode){
    state.mode = mode || 'cursor';
    if(state.toolbar){
      state.toolbar.querySelectorAll('[data-tool]').forEach(b=>b.classList.toggle('active', b.dataset.tool===state.mode));
    }
    if(state.canvas){
      state.canvas.style.pointerEvents = state.mode === 'cursor' ? 'none' : 'auto';
      state.canvas.style.cursor = state.mode === 'cursor' ? 'default' : 'crosshair';
    }
    state.draft=null;
    requestDraw();
  }
  function ensureCanvas(){
    const c=state.container;
    if(!c) return;
    c.style.position='relative';
    let canvas=c.querySelector('#chartToolsCanvas');
    if(!canvas){
      canvas=document.createElement('canvas');
      canvas.id='chartToolsCanvas';
      canvas.style.cssText='position:absolute;inset:0;z-index:8;pointer-events:none;';
      c.appendChild(canvas);
    }
    state.canvas=canvas;
    state.ctx=canvas.getContext('2d');
    resizeCanvas();
  }
  function resizeCanvas(){
    if(!state.container||!state.canvas)return;
    const rect=state.container.getBoundingClientRect();
    const dpr=window.devicePixelRatio||1;
    const w=Math.max(1, Math.floor(rect.width));
    const h=Math.max(1, Math.floor(rect.height));
    if(state.canvas.width!==Math.floor(w*dpr)||state.canvas.height!==Math.floor(h*dpr)){
      state.canvas.width=Math.floor(w*dpr);
      state.canvas.height=Math.floor(h*dpr);
      state.canvas.style.width=w+'px';
      state.canvas.style.height=h+'px';
      state.ctx.setTransform(dpr,0,0,dpr,0,0);
    }
  }
  function makeToolbar(){
    if(!state.container) return;
    const wrap=state.container.parentElement || state.container;
    if(wrap.querySelector('#chartToolsBar')) return;
    const bar=document.createElement('div');
    bar.id='chartToolsBar';
    bar.className='chart-tools-bar';
    bar.innerHTML=`
      <button data-tool="cursor" title="Cursor">↖</button>
      <button data-tool="hline" title="Horizontal line">─</button>
      <button data-tool="line" title="Trend line">╱</button>
      <button data-tool="box" title="Box / zone">▭</button>
      <button data-tool="clear" title="Clear drawings">🗑</button>
    `;
    wrap.appendChild(bar);
    state.toolbar=bar;
    bar.querySelectorAll('[data-tool]').forEach(btn=>{
      btn.onclick=(e)=>{
        e.preventDefault(); e.stopPropagation();
        const tool=btn.dataset.tool;
        if(tool==='clear'){
          if(confirm('Удалить все разметки для '+symbolKey()+'?')){
            state.drawings=[]; state.draft=null; save(); requestDraw();
          }
          return;
        }
        setMode(tool);
      };
    });
    setMode('cursor');
  }
  function getPoint(ev){
    const rect=state.canvas.getBoundingClientRect();
    const x=ev.clientX-rect.left, y=ev.clientY-rect.top;
    let time=null, price=null;
    try{time=state.chart.timeScale().coordinateToTime(x)}catch(e){}
    try{price=state.series.coordinateToPrice(y)}catch(e){}
    if(time==null||price==null||!Number.isFinite(Number(price))) return null;
    // Lightweight can return BusinessDay; keep as object if needed
    return {time, price:Number(price), x, y};
  }
  function onPointerDown(ev){
    if(state.mode==='cursor')return;
    const p=getPoint(ev);
    if(!p)return;
    ev.preventDefault(); ev.stopPropagation();

    if(state.mode==='hline'){
      state.drawings.push({type:'hline', price:p.price, created:Date.now()});
      save(); requestDraw(); return;
    }

    if(!state.draft){
      state.draft={type:state.mode, p1:{time:p.time, price:p.price}, p2:null};
    }else{
      state.draft.p2={time:p.time, price:p.price};
      state.drawings.push(state.draft);
      state.draft=null;
      save(); requestDraw();
    }
  }
  function onPointerMove(ev){
    if(!state.draft)return;
    const p=getPoint(ev);
    if(!p)return;
    state.draft.p2={time:p.time, price:p.price};
    requestDraw();
  }
  function coord(pt){
    if(!pt)return null;
    let x=null,y=null;
    try{x=state.chart.timeScale().timeToCoordinate(pt.time)}catch(e){}
    try{y=state.series.priceToCoordinate(pt.price)}catch(e){}
    if(x==null||y==null)return null;
    return {x,y};
  }
  function drawText(ctx,text,x,y,color){
    ctx.save();
    ctx.font='10px -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif';
    const w=ctx.measureText(text).width+8;
    ctx.fillStyle='rgba(6,15,30,.78)';
    ctx.strokeStyle=color;
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.roundRect(x,y-14,w,16,5);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle=color;
    ctx.fillText(text,x+4,y-3);
    ctx.restore();
  }
  function drawOne(d, draft=false){
    const ctx=state.ctx;
    if(!ctx)return;
    ctx.save();
    ctx.lineWidth=draft?1:1.6;
    ctx.setLineDash(draft?[4,4]:[]);
    ctx.strokeStyle=draft?'rgba(96,165,250,.7)':'rgba(96,165,250,.95)';
    ctx.fillStyle='rgba(96,165,250,.12)';

    if(d.type==='hline'){
      const y=state.series.priceToCoordinate(d.price);
      if(y==null)return ctx.restore();
      ctx.beginPath();
      ctx.moveTo(0,y); ctx.lineTo(state.canvas.clientWidth,y); ctx.stroke();
      drawText(ctx,'LEVEL '+Number(d.price).toFixed(4),8,y-4,ctx.strokeStyle);
    }else if(d.type==='line'&&d.p1&&d.p2){
      const a=coord(d.p1), b=coord(d.p2);
      if(!a||!b)return ctx.restore();
      ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
      drawText(ctx,'TREND',Math.min(a.x,b.x)+4,Math.min(a.y,b.y)-4,ctx.strokeStyle);
    }else if(d.type==='box'&&d.p1&&d.p2){
      const a=coord(d.p1), b=coord(d.p2);
      if(!a||!b)return ctx.restore();
      const x=Math.min(a.x,b.x), y=Math.min(a.y,b.y), w=Math.abs(a.x-b.x), h=Math.abs(a.y-b.y);
      ctx.fillRect(x,y,w,h);
      ctx.strokeRect(x,y,w,h);
      drawText(ctx,'ZONE',x+4,y+14,ctx.strokeStyle);
    }
    ctx.restore();
  }
  function draw(){
    resizeCanvas();
    const ctx=state.ctx;
    if(!ctx||!state.canvas)return;
    ctx.clearRect(0,0,state.canvas.clientWidth,state.canvas.clientHeight);
    (state.drawings||[]).forEach(d=>drawOne(d,false));
    if(state.draft) drawOne(state.draft,true);
  }
  function requestDraw(){
    if(state.raf) cancelAnimationFrame(state.raf);
    state.raf=requestAnimationFrame(draw);
  }
  function init(opts){
    opts=opts||{};
    state.chart=opts.chart;
    state.series=opts.series || opts.candles;
    state.container=opts.container || document.getElementById('chart');
    state.getSymbol=opts.getSymbol || state.getSymbol;
    if(!state.chart||!state.series||!state.container) return;

    ensureCanvas();
    makeToolbar();
    load();

    state.canvas.addEventListener('pointerdown', onPointerDown);
    state.canvas.addEventListener('pointermove', onPointerMove);
    window.addEventListener('resize', requestDraw);
    try{state.chart.timeScale().subscribeVisibleTimeRangeChange(requestDraw)}catch(e){}
    try{state.chart.subscribeCrosshairMove(requestDraw)}catch(e){}
  }

  window.ChartTools={init,load,save,setMode,requestDraw,clear:()=>{state.drawings=[];save();requestDraw();}};
})();
