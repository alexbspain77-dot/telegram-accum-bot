/*
Theme Engine PRO v1
- One theme source for all windows
- Applies CSS theme + lightweight-charts theme
- Syncs across tabs/windows via storage event
*/
(function(){
  if(window.ThemeEngine) return;

  const KEY='bt_theme';
  const THEMES={
    dark:{
      bg:'#060f1e', panel:'#0b1628', text:'#e8f0ff', muted:'#7a90b8',
      grid:'rgba(255,255,255,0.055)', border:'rgba(255,255,255,0.12)',
      candleUp:'#26a69a', candleDown:'#ef5350',
      areaDark:'rgba(96,165,250,0.12)'
    },
    light:{
      bg:'#f8fafc', panel:'#ffffff', text:'#0f172a', muted:'#64748b',
      grid:'rgba(15,23,42,0.08)', border:'rgba(15,23,42,0.14)',
      candleUp:'#16a34a', candleDown:'#dc2626',
      areaDark:'rgba(37,99,235,0.08)'
    }
  };

  let charts=[];

  function current(){
    return localStorage.getItem(KEY) || localStorage.getItem('theme') || document.documentElement.getAttribute('data-theme') || 'dark';
  }
  function palette(theme){
    return THEMES[theme] || THEMES.dark;
  }
  function applyDom(theme){
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(KEY, theme);
    localStorage.setItem('theme', theme);
  }
  function chartOptions(theme){
    const p=palette(theme);
    return {
      layout:{background:{type:'solid',color:p.bg},textColor:p.text},
      grid:{vertLines:{color:p.grid},horzLines:{color:p.grid}},
      rightPriceScale:{borderColor:p.border},
      timeScale:{borderColor:p.border},
      crosshair:{mode:1}
    };
  }
  function seriesOptions(theme){
    const p=palette(theme);
    return {upColor:p.candleUp,downColor:p.candleDown,borderVisible:false,wickUpColor:p.candleUp,wickDownColor:p.candleDown};
  }
  function applyChartObj(obj, theme){
    if(!obj) return;
    const t=theme||current();
    try{ obj.chart && obj.chart.applyOptions(chartOptions(t)); }catch(e){}
    try{ obj.rsiChart && obj.rsiChart.applyOptions(chartOptions(t)); }catch(e){}
    try{ obj.candles && obj.candles.applyOptions(seriesOptions(t)); }catch(e){}
    try{ obj.onApply && obj.onApply(t, palette(t)); }catch(e){}
  }
  function apply(theme){
    theme=theme||current();
    applyDom(theme);
    charts.forEach(c=>applyChartObj(c,theme));
  }
  function toggle(){
    apply(current()==='dark'?'light':'dark');
  }
  function register(obj){
    charts.push(obj);
    applyChartObj(obj,current());
    return obj;
  }
  window.addEventListener('storage', e=>{
    if(e.key===KEY || e.key==='theme') apply(current());
  });

  window.ThemeEngine={current,palette,apply,toggle,register,chartOptions,seriesOptions};
  document.addEventListener('DOMContentLoaded',()=>apply(current()));
})();
