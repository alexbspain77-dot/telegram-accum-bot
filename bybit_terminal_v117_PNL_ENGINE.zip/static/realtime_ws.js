/*
Dashboard WebSocket Realtime v1
- Bybit public ticker WebSocket for watchlist symbols
- Updates watchlist/card prices without reloading dashboard
- Backoff reconnect, no fetch overlap
*/
(function(){
  if(window.RealtimeWS) return;

  const WS_URL='wss://stream.bybit.com/v5/public/linear';
  let ws=null;
  let activeSymbols=[];
  let reconnectTimer=null;
  let reconnectDelay=2000;
  let connected=false;
  const prices={};

  function norm(s){
    s=String(s||'').toUpperCase().replace(/[\/\-\s]/g,'');
    return s.endsWith('USDT')?s:s+'USDT';
  }
  function uniq(arr){
    const out=[];
    (arr||[]).forEach(s=>{s=norm(s); if(s && !out.includes(s))out.push(s);});
    return out.slice(0,30);
  }
  function status(txt, ok){
    const el=document.getElementById('wsStatus');
    if(el){
      el.textContent=txt;
      el.style.color=ok?'var(--green)':'var(--amber)';
    }
  }
  function close(){
    try{ if(ws) ws.close(); }catch(e){}
    ws=null; connected=false;
  }
  function subscribe(){
    if(!ws || ws.readyState!==1 || !activeSymbols.length) return;
    const args=activeSymbols.map(s=>`tickers.${s}`);
    ws.send(JSON.stringify({op:'subscribe',args}));
  }
  function start(symbols){
    activeSymbols=uniq(symbols);
    close();
    if(!activeSymbols.length) return;

    try{
      ws=new WebSocket(WS_URL);
      status('WS connecting', false);

      ws.onopen=()=>{
        connected=true;
        reconnectDelay=2000;
        status('WS live', true);
        subscribe();
      };

      ws.onmessage=(ev)=>{
        try{
          const msg=JSON.parse(ev.data);
          if(!msg || !msg.topic || !msg.topic.startsWith('tickers.')) return;
          const d=msg.data||{};
          const symbol=d.symbol||msg.topic.split('.')[1];
          const last=Number(d.lastPrice||d.last_price||d.markPrice||0);
          const chg=Number(d.price24hPcnt!=null ? d.price24hPcnt*100 : (d.change24h||0));
          if(!symbol || !last) return;
          prices[symbol]={price:last, change24h:chg, ts:Date.now()};
          applyPrice(symbol,last,chg);
        }catch(e){
          if(window.UIErrors) UIErrors.add('ws-message', e.message||e);
        }
      };

      ws.onclose=()=>{
        connected=false;
        status('WS reconnect', false);
        clearTimeout(reconnectTimer);
        reconnectTimer=setTimeout(()=>start(activeSymbols), reconnectDelay);
        reconnectDelay=Math.min(15000, reconnectDelay*1.4);
      };

      ws.onerror=(e)=>{
        status('WS error', false);
        if(window.UIErrors) UIErrors.add('websocket','Bybit websocket error');
        try{ws.close();}catch(_){}
      };
    }catch(e){
      if(window.UIErrors) UIErrors.add('websocket', e.message||e);
    }
  }
  function refresh(symbols){
    const next=uniq(symbols);
    if(JSON.stringify(next)!==JSON.stringify(activeSymbols)){
      start(next);
    }
  }
  function applyPrice(symbol, price, change){
    // Patch in-memory signals
    try{
      if(window.allSignals){
        window.allSignals.forEach(s=>{
          if(s.symbol===symbol){
            s.price=price;
            if(Number.isFinite(change)) s.change24h=change;
          }
        });
      }
    }catch(e){}

    // Lightweight DOM update for watchlist and cards
    try{
      document.querySelectorAll(`[data-symbol="${symbol}"]`).forEach(el=>{
        const p=el.querySelector('[data-price]');
        if(p) p.textContent='$'+Number(price).toLocaleString('en',{maximumFractionDigits:4});
        const c=el.querySelector('[data-change]');
        if(c && Number.isFinite(change)){
          c.textContent=(change>=0?'+':'')+change.toFixed(4)+'%';
          c.classList.toggle('up',change>=0);
          c.classList.toggle('down',change<0);
        }
      });
    }catch(e){}
  }
  function get(symbol){return prices[norm(symbol)]||null;}

  window.RealtimeWS={start,refresh,close,get,prices:()=>prices,status:()=>({connected,activeSymbols})};
})();
