# EARLY Reversal Score

Adds early reversal mode:
- sell-side sweep + structure up + momentum/orderflow => EARLY LONG
- buy-side sweep + structure down + momentum/orderflow => EARLY SHORT

Confirmed scenarios are not overwritten. Only NO_TRADE/weak setups can be upgraded to EARLY_REVERSAL.
