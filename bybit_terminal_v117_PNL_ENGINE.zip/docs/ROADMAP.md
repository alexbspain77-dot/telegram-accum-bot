# v7.1 Institutional Core Upgrade Roadmap

## Done in v7.1
- [x] Added `app/core/liquidity_engine.py`
  - swing-based liquidity pools
  - equal highs/equal lows clusters
  - sweep + rejection logic, not just level breach
- [x] Added `app/core/smc_engine.py`
  - institutional swings using high/low
  - BOS / CHoCH events
  - FVG with mitigation flag
  - premium / discount zone
- [x] Added `app/core/orderflow_engine.py`
  - explicit CVD proxy
  - orderbook imbalance classification
  - divergence/confirmation quality
- [x] Added `app/core/risk_engine.py`
  - structural stop behind swing high/low
  - liquidity-target TP1/TP2 where available
  - RR1/RR2
- [x] Added `app/core/scenario_engine.py`
  - sweep → CHoCH reversal scenarios
  - MTF continuation fallback
  - MTF/orderflow alignment scoring
  - trap risk labeling
- [x] Added `app/core/backtest_engine.py`
  - minimal forward evaluation scaffold
- [x] Added `/api/institutional/<symbol>`
- [x] Added UI panel: “Institutional View v7.1”

## Claude weak points status
- [x] EMA: already fixed in v6.1 with SMA seed
- [x] RSI: already fixed in v6.1 with Wilder O(n)
- [x] Elliott: not used as primary institutional engine; kept as optional layer
- [x] Stop/TP: upgraded to structural swing + liquidity targets
- [x] MTF: uses real 4H + 1D candles
- [x] Flow score: renamed/handled as proxy and combined with orderbook imbalance
- [x] BOS / CHoCH / FVG / SMC: added and exposed in institutional panel

## Next
- [ ] Draw institutional liquidity levels on chart as toggle layer
- [ ] Draw BOS/CHoCH/FVG directly from v7.1 core, not legacy SMC only
- [ ] Add real liquidation clusters
- [ ] Add session ranges: Asia / London / NY
- [ ] Add replay/backtest UI
- [ ] Add journal of scenarios and outcomes

## v7.6 Feedback Loop
- [x] Manual trade journal from chart UI
- [x] Store scenario snapshot at entry
- [x] Close trade with exit, reason and PnL
- [x] Learning engine factor analysis
- [x] Conservative confidence adjustment from closed trade history
- [ ] Advanced model training with larger dataset
- [ ] Export journal CSV
- [ ] Equity curve / R-multiple analytics UI
