# v8.1 Decision Engine

Added:
- hard NO_TRADE gate by default;
- momentum conflict filter;
- impulse exhaustion / late-entry filter;
- order block context integration;
- Elliott alignment/conflict integration;
- FVG proximity still supported;
- chart receives `elliott_points` for drawing wave line.

Decision priority:
1. liquidity sweep / BOS / CHoCH trigger;
2. direction from trap > fresh structure event > structure+MTF;
3. MTF/orderflow/PD/FVG scoring;
4. v8.1 filters: momentum, exhaustion, OB, Elliott;
5. blockers force NO_TRADE.
