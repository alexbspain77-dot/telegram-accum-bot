# Test Log

## v7 clean rebuild
- Removed old `.signals.analyze_symbol` pipeline from dashboard.
- Dashboard cards now come from `institutional_report()` only.
- Chart uses `/api/v7/chart/<symbol>` only.
- Old `/api/chart` and `/api/signals` are aliases but return v7-only payloads.
- `py_compile` passed for all Python files.

Check in browser:
- `/api/v7/chart/TAOUSDT?tf=15` must include `engine: v7_institutional_only`.
- UI must show `V7 SCENARIO`, `Confidence`, and reasons.
- Old `TREND LONG · score` subtitle should not appear.
