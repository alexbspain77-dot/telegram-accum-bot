# Orderflow PRO

Added real Bybit public data:
- recent trades pressure (buy/sell notional)
- large trades > $100k
- open interest current/trend/change
- funding rate/bias
- composite flow bias

Dashboard FLOW tab now reads orderflow fields directly.
