# Bybit Institutional Terminal v7.5 Full Terminal

## Запуск

```bash
cd bybit_v7_5_full_terminal
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

По умолчанию сервер стартует на `PORT=5050`. Если порт занят, автоматически возьмёт следующий свободный порт и покажет ссылку в терминале.

## Что включено

- V7 institutional engine only, без старого `signals.py`.
- Liquidity pools, sweeps/grabs.
- BOS / CHoCH.
- FVG zones.
- Premium / Discount.
- Elliott impulse / ABC + влияние на scenario.
- EMA 9/21/55, RSI Wilder.
- MTF 4H + 1D.
- Orderbook imbalance + CVD proxy.
- Session context Asia / London / NY.
- Telegram monitor/notify, если заполнены `TELEGRAM_TOKEN` и `TELEGRAM_CHAT_ID`.
- Signal journal: `/api/v7/journal`.
- TradingView-like chart with layers.

## API

- `/api/v7/signals?tf=60&q=BTC&limit=30`
- `/api/v7/chart/BTCUSDT?tf=60`
- `/api/v7/institutional/BTCUSDT?tf=60`
- `/api/v7/journal?limit=100`

## v7.6 Trade Journal + Learning Engine

Added feedback loop:

- Open manual trades directly from the coin chart panel.
- Save: symbol, direction, size USDT, entry, stop, note, timestamp.
- Every opened trade stores a full `scenario_snapshot` of the model state.
- Close trade with exit price and reason.
- PnL is calculated automatically.
- `learning_engine.py` analyses closed trades and updates factor confidence adjustments.
- Fresh scenarios receive a conservative learned adjustment shown in the panel.

API:

- `GET /api/v7/trades`
- `POST /api/v7/trades/open`
- `POST /api/v7/trades/<trade_id>/close`
- `GET /api/v7/learning`
- `POST /api/v7/learning/recompute`

Stored data:

- `data/manual_trades.json`
- `data/learned_weights.json`
