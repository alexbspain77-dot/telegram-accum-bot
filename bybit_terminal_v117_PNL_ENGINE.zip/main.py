import os
from dotenv import load_dotenv
load_dotenv()

from app.server import create_app
app = create_app()

if __name__ == '__main__':
    token    = os.getenv('TELEGRAM_TOKEN', '')
    symbols  = [s.strip() for s in os.getenv('MONITOR_SYMBOLS','BTCUSDT,ETHUSDT,SOLUSDT').split(',') if s.strip()]
    interval = int(os.getenv('MONITOR_INTERVAL', '60'))

    if token:
        try:
            from app.telegram import start_monitor
            start_monitor(symbols, interval=interval)
            print(f"[Telegram] мониторинг запущен: {symbols}")
        except Exception as e:
            print(f"[Telegram] ошибка запуска: {e}")
    else:
        print("[Telegram] TOKEN не задан — уведомления отключены")

    port = int(os.getenv('PORT', 8080))
    print(f"\n{'='*50}")
    print(f"  Bybit Terminal v8.6")
    print(f"  http://localhost:{port}")
    print(f"  Журнал: http://localhost:{port}/journal")
    print(f"{'='*50}\n")
    app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)
